package com.mobiletips.dokankhata

object AppConfig {
    const val VERSION = "1.1"
    /** Web client id of the Firebase project (same project as Hajira Khata). */
    /** This Gmail is the admin: always the owner of its own shop, no approval needed. */
    const val ADMIN_EMAIL = "mdrasel666699990@gmail.com"

    const val WEB_CLIENT_ID = "890475786016-12r7uimht5gr9nrmfo7itrq23fmm8ats.apps.googleusercontent.com"
}
