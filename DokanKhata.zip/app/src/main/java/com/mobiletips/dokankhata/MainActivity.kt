package com.mobiletips.dokankhata

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.mobiletips.dokankhata.data.Auth
import com.mobiletips.dokankhata.data.Net
import com.mobiletips.dokankhata.ui.App

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Net.init(applicationContext)
        Auth.init(applicationContext)
        setContent { App(this) }
    }
}
