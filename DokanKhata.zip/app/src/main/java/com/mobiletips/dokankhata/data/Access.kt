package com.mobiletips.dokankhata.data

import androidx.compose.runtime.mutableStateOf
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.mobiletips.dokankhata.AppConfig

/**
 * Who may use the app. Every Google account gets a members/{uid} record.
 * New accounts start as "pending"; the admin approves them from the web panel as
 * the owner of a new shop, or as staff of an existing shop.
 */
data class Member(
    val uid: String,
    val name: String,
    val email: String,
    val status: String,   // pending, active, blocked
    val role: String,     // owner, staff ("" while pending)
    val shopId: String,
    val expires: Long,    // 0 = no end date
    val note: String,
    val perms: Map<String, Boolean> = emptyMap(),
) {
    val expired get() = expires > 0 && expires < System.currentTimeMillis()
    val isOwner get() = role == "owner"
}

object Access {
    val member = mutableStateOf<Member?>(null)
    val loaded = mutableStateOf(false)
    private var reg: ListenerRegistration? = null
    private var uid: String? = null
    private val db get() = FirebaseFirestore.getInstance()

    val isOwner get() = member.value?.isOwner == true
    val isAdmin get() = member.value?.email.equals(AppConfig.ADMIN_EMAIL, true)

    /**
     * Feature switches set by the admin in the panel:
     * scan, photo, baki, profit, products, delete.
     * Missing switches fall back to the role: owners get all, staff get scan/photo/baki.
     */
    fun can(key: String): Boolean {
        val m = member.value ?: return false
        if (isAdmin) return true
        val byRole = if (m.isOwner) true else key in setOf("scan", "photo", "baki")
        if ((key == "products" || key == "delete") && !m.isOwner) return false  // the server only allows these to owners
        return m.perms[key] ?: byRole
    }

    fun start(u: FirebaseUser) {
        if (uid == u.uid && reg != null) return
        stop()
        uid = u.uid
        val ref = db.collection("members").document(u.uid)
        var touched = false
        reg = ref.addSnapshotListener { d, e ->
            if (e != null) { Store.error.value = e.message; return@addSnapshotListener }
            if (d == null) return@addSnapshotListener
            // wait until the server has the record, otherwise the shop's rules would still say "no"
            if (d.metadata.hasPendingWrites()) return@addSnapshotListener
            val isAdmin = u.email.equals(AppConfig.ADMIN_EMAIL, true)
            if (isAdmin && (!d.exists() || d.getString("status") != "active" || d.getString("shopId").isNullOrEmpty())) {
                // the admin's own account is always the active owner of their own shop
                ref.set(mapOf(
                    "name" to (u.displayName ?: ""), "email" to (u.email ?: ""), "photo" to (u.photoUrl?.toString() ?: ""),
                    "status" to "active", "role" to "owner", "shopId" to u.uid, "expires" to 0L,
                    "lastSeen" to System.currentTimeMillis(),
                ), SetOptions.merge())
                return@addSnapshotListener
            }
            if (!d.exists()) {
                // first time: ask the admin for permission
                ref.set(mapOf(
                    "name" to (u.displayName ?: ""), "email" to (u.email ?: ""), "photo" to (u.photoUrl?.toString() ?: ""),
                    "status" to "pending", "role" to "", "shopId" to "", "expires" to 0L, "note" to "",
                    "created" to System.currentTimeMillis(), "lastSeen" to System.currentTimeMillis(),
                ))
                return@addSnapshotListener
            }
            member.value = Member(
                uid = d.id,
                name = d.getString("name") ?: "",
                email = d.getString("email") ?: "",
                status = d.getString("status") ?: "pending",
                role = d.getString("role") ?: "",
                shopId = d.getString("shopId") ?: "",
                expires = (d.get("expires") as? Number)?.toLong() ?: 0L,
                note = d.getString("note") ?: "",
                perms = (d.get("perms") as? Map<*, *>)?.mapNotNull { (k, v) -> if (k is String && v is Boolean) k to v else null }?.toMap() ?: emptyMap(),
            )
            loaded.value = true
            if (!touched) {
                touched = true
                ref.set(mapOf("lastSeen" to System.currentTimeMillis(), "name" to (u.displayName ?: ""), "photo" to (u.photoUrl?.toString() ?: "")), SetOptions.merge())
            }
        }
    }

    fun stop() {
        reg?.remove(); reg = null; uid = null
        member.value = null; loaded.value = false
    }
}
