package com.mobiletips.dokankhata.data

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.mobiletips.dokankhata.AppConfig

/** Google sign-in. Each Gmail is one shop. */
object Auth {
    val user = mutableStateOf<FirebaseUser?>(null)
    val ready = mutableStateOf(false)

    fun init(ctx: Context) {
        ready.value = FirebaseApp.getApps(ctx).isNotEmpty()
        if (!ready.value) return
        // Firestore keeps a copy on the phone, so the shop keeps working without internet
        // and everything goes up by itself when the internet is back.
        val a = FirebaseAuth.getInstance()
        user.value = a.currentUser
        a.addAuthStateListener { user.value = it.currentUser }
    }

    suspend fun signIn(activity: Activity): String? {
        if (!ready.value) return "Firebase সেটআপ বাকি"
        return try {
            val option = GetSignInWithGoogleOption.Builder(AppConfig.WEB_CLIENT_ID).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val cred = CredentialManager.create(activity).getCredential(activity, request).credential
            if (cred !is CustomCredential || cred.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                return "গুগল লগইন হয়নি"
            }
            val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
            FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(token, null))
            null
        } catch (e: Exception) {
            e.message ?: "লগইন বাতিল হয়েছে"
        }
    }

    /** Asks Google which account is on this phone again (to reset a forgotten PIN). Gives back its email. */
    suspend fun confirmGoogle(activity: Activity): String? = try {
        val option = GetSignInWithGoogleOption.Builder(AppConfig.WEB_CLIENT_ID).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val cred = CredentialManager.create(activity).getCredential(activity, request).credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
            GoogleIdTokenCredential.createFrom(cred.data).id
        else null
    } catch (e: Exception) { null }

    suspend fun signOut(activity: Activity) {
        Store.stop()
        Access.stop()
        FirebaseAuth.getInstance().signOut()
        try { CredentialManager.create(activity).clearCredentialState(ClearCredentialStateRequest()) } catch (e: Exception) { }
    }
}

/** Watches the internet. The app works only while this is true. */
object Net {
    val online = mutableStateOf(true)
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return
        online.value = has(cm, cm.activeNetwork)
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { main.post { online.value = true } }
            override fun onLost(network: Network) { main.post { online.value = has(cm, cm.activeNetwork) } }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                val ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                main.post { online.value = ok }
            }
        })
    }

    private fun has(cm: ConnectivityManager, n: Network?): Boolean {
        if (n == null) return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
