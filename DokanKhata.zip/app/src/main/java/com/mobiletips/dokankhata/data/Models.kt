package com.mobiletips.dokankhata.data

import com.google.firebase.firestore.DocumentSnapshot

/** One product on the shelf. Prices of "pcs" products are per piece, of "kg" products per kilo. */
data class Product(
    val id: String = "",
    val name: String = "",
    val cat: String = "",
    val barcode: String = "",
    val unit: String = "pcs",      // "pcs" or "kg"
    val packSize: Int = 0,          // pieces in one packet (0 = no packet)
    val sell: Double = 0.0,         // sell price per piece / per kg
    val buy: Double = 0.0,          // buy price per piece / per kg
    val packSell: Double = 0.0,     // sell price of a whole packet
    val packBuy: Double = 0.0,      // buy price of a whole packet
    val stock: Double = 0.0,        // in pieces / kg
    val lowAt: Double = 0.0,        // warn when stock is this or less
    val photo: String = "",         // small JPEG, base64
    val sold: Double = 0.0,         // how much has been sold (for ordering)
    val embs: List<String> = emptyList(),  // "looks" of the product for photo recognition
    val created: Long = 0L,         // when it was first added
    val updated: Long = 0L,
) {
    val isKg get() = unit == "kg"
    val hasPack get() = packSize > 0 && !isKg
    val low get() = lowAt > 0 && stock <= lowAt
    /** What the QR sticker of a product without a barcode says. */
    val qrCode get() = "DK:$id"

    fun matches(code: String) = (barcode.isNotEmpty() && barcode == code) || code == qrCode

    fun toMap(): Map<String, Any> = mapOf(
        "name" to name, "cat" to cat, "barcode" to barcode, "unit" to unit,
        "packSize" to packSize, "sell" to sell, "buy" to buy, "packSell" to packSell, "packBuy" to packBuy,
        "stock" to stock, "lowAt" to lowAt, "photo" to photo, "sold" to sold, "embs" to embs,
        "created" to (if (created > 0) created else System.currentTimeMillis()),
        "updated" to System.currentTimeMillis()
    )

    companion object {
        fun from(d: DocumentSnapshot) = Product(
            id = d.id,
            name = d.getString("name") ?: "",
            cat = d.getString("cat") ?: "",
            barcode = d.getString("barcode") ?: "",
            unit = d.getString("unit") ?: "pcs",
            packSize = (d.getLong("packSize") ?: 0L).toInt(),
            sell = d.num("sell"), buy = d.num("buy"),
            packSell = d.num("packSell"), packBuy = d.num("packBuy"),
            stock = d.num("stock"), lowAt = d.num("lowAt"),
            photo = d.getString("photo") ?: "",
            sold = d.num("sold"),
            embs = (d.get("embs") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            created = d.getLong("created") ?: 0L,
            updated = d.getLong("updated") ?: 0L,
        )
    }
}

/** A line in the cart. mode: "pc", "pack", "kg" or "custom". */
data class CartLine(
    val key: String,
    val productId: String,
    val name: String,
    val mode: String,
    val qty: Double,
    val price: Double,       // per one qty
    val cost: Double,        // per one qty
    val stockPer: Double,    // how much stock one qty uses
) {
    val total get() = price * qty
    val costTotal get() = cost * qty
    val stockUsed get() = stockPer * qty
}

data class SaleItem(val pid: String, val name: String, val mode: String, val qty: Double, val price: Double, val cost: Double, val stock: Double) {
    val total get() = price * qty
}

data class Sale(
    val id: String,
    val time: Long,
    val items: List<SaleItem>,
    val total: Double,
    val profit: Double,
    val paid: Double,
    val due: Double,
    val customerId: String,
    val customerName: String,
    val byName: String = "",
) {
    companion object {
        fun from(d: DocumentSnapshot): Sale {
            @Suppress("UNCHECKED_CAST")
            val raw = d.get("items") as? List<Map<String, Any?>> ?: emptyList()
            val items = raw.map {
                SaleItem(
                    pid = it["pid"] as? String ?: "",
                    name = it["name"] as? String ?: "",
                    mode = it["mode"] as? String ?: "pc",
                    qty = (it["qty"] as? Number)?.toDouble() ?: 0.0,
                    price = (it["price"] as? Number)?.toDouble() ?: 0.0,
                    cost = (it["cost"] as? Number)?.toDouble() ?: 0.0,
                    stock = (it["stock"] as? Number)?.toDouble() ?: 0.0,
                )
            }
            return Sale(
                id = d.id, time = d.getLong("time") ?: 0L, items = items,
                total = d.num("total"), profit = d.num("profit"), paid = d.num("paid"), due = d.num("due"),
                customerId = d.getString("customerId") ?: "", customerName = d.getString("customerName") ?: "",
                byName = d.getString("byName") ?: "",
            )
        }
    }
}

data class Customer(val id: String, val name: String, val phone: String, val due: Double, val photo: String = "", val lastAt: Long = 0L) {
    companion object {
        fun from(d: DocumentSnapshot) = Customer(
            d.id, d.getString("name") ?: "", d.getString("phone") ?: "", d.num("due"), d.getString("photo") ?: "",
            d.getLong("lastAt") ?: d.getLong("created") ?: 0L
        )
    }
}

/** A payment back from a customer, or (kind = "due") baki written by hand without a sale. */
data class Payment(val id: String, val customerId: String, val amount: Double, val time: Long, val note: String, val kind: String = "pay") {
    val isDue get() = kind == "due"
    companion object {
        fun from(d: DocumentSnapshot) = Payment(d.id, d.getString("customerId") ?: "", d.num("amount"), d.getLong("time") ?: 0L, d.getString("note") ?: "", d.getString("kind") ?: "pay")
    }
}

internal fun DocumentSnapshot.num(k: String): Double = (get(k) as? Number)?.toDouble() ?: 0.0
