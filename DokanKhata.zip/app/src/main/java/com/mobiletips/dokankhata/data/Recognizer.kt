package com.mobiletips.dokankhata.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Base64
import androidx.compose.runtime.mutableStateOf
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Recognises products by how they look, inside the phone (no internet, no cost).
 * Each product keeps a few "looks" (small number lists made from its photos);
 * a camera picture is compared with all of them and the closest products are suggested.
 */
object Recognizer {
    val available = mutableStateOf(false)
    private var embedder: ImageEmbedder? = null
    private val cache = HashMap<String, List<FloatArray>>()

    fun init(ctx: Context) {
        Thread {
            try {
                val opts = ImageEmbedder.ImageEmbedderOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("embedder.tflite").build())
                    .setRunningMode(RunningMode.IMAGE)
                    .build()
                embedder = ImageEmbedder.createFromOptions(ctx.applicationContext, opts)
                available.value = true
            } catch (e: Throwable) {
                available.value = false
            }
        }.start()
    }

    /** Square middle part of the picture, turned the right way up. */
    fun prepare(src: Bitmap, rotation: Int): Bitmap {
        val side = minOf(src.width, src.height)
        val x = (src.width - side) / 2
        val y = (src.height - side) / 2
        val m = Matrix()
        if (rotation != 0) m.postRotate(rotation.toFloat())
        val s = 256f / side
        m.postScale(s, s)
        return Bitmap.createBitmap(src, x, y, side, side, m, true)
    }

    @Synchronized
    fun embed(bm: Bitmap): FloatArray? = try {
        val e = embedder ?: return null
        val v = e.embed(BitmapImageBuilder(bm).build()).embeddingResult().embeddings().firstOrNull()?.floatEmbedding()
        v?.let { normalize(it) }
    } catch (e: Throwable) { null }

    private fun normalize(v: FloatArray): FloatArray {
        var n = 0f
        for (x in v) n += x * x
        n = sqrt(n)
        if (n == 0f) return v
        return FloatArray(v.size) { v[it] / n }
    }

    fun encode(v: FloatArray): String {
        val b = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        v.forEach { b.putFloat(it) }
        return Base64.encodeToString(b.array(), Base64.NO_WRAP)
    }

    private fun decode(s: String): FloatArray? = try {
        val b = ByteBuffer.wrap(Base64.decode(s, Base64.DEFAULT)).order(ByteOrder.LITTLE_ENDIAN)
        FloatArray(b.remaining() / 4) { b.float }
    } catch (e: Exception) { null }

    private fun looks(p: Product): List<FloatArray> {
        val key = p.id + ":" + p.embs.size + ":" + (p.embs.firstOrNull()?.hashCode() ?: 0)
        return synchronized(cache) { cache.getOrPut(key) { p.embs.mapNotNull { decode(it) } } }
    }

    private fun dot(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** The products that look most like [v], best first, with a 0..1 likeness. */
    fun match(v: FloatArray, products: List<Product>, min: Float = 0.6f): List<Pair<Product, Float>> =
        products.mapNotNull { p ->
            val best = looks(p).maxOfOrNull { dot(v, it) } ?: return@mapNotNull null
            if (best >= min) p to best else null
        }.sortedByDescending { it.second }.take(3)
}
