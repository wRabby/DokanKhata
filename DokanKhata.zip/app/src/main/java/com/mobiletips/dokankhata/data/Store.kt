package com.mobiletips.dokankhata.data

import androidx.compose.runtime.mutableStateOf
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/**
 * Everything lives online in Firestore under shops/{uid}/...
 * The lists below follow the cloud live, so every screen is always up to date.
 */
object Store {
    val products = mutableStateOf<List<Product>>(emptyList())
    val customers = mutableStateOf<List<Customer>>(emptyList())
    val sales = mutableStateOf<List<Sale>>(emptyList())        // last ~60 days
    val payments = mutableStateOf<List<Payment>>(emptyList())
    val shopName = mutableStateOf("")
    val loaded = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)

    private val regs = mutableListOf<ListenerRegistration>()
    private var uid: String? = null
    private val db get() = FirebaseFirestore.getInstance()
    private fun shop(): DocumentReference = db.collection("shops").document(uid ?: "none")

    fun start(u: String) {
        if (uid == u && regs.isNotEmpty()) return
        stop()
        uid = u
        val onErr: (Exception?) -> Unit = { e -> if (e != null) error.value = e.message }
        regs += shop().collection("products").addSnapshotListener { s, e ->
            onErr(e)
            if (s != null) {
                products.value = s.documents.map { Product.from(it) }.sortedWith(compareByDescending<Product> { it.sold }.thenBy { it.name })
                loaded.value = true
            }
        }
        regs += shop().collection("customers").addSnapshotListener { s, e ->
            onErr(e)
            if (s != null) customers.value = s.documents.map { Customer.from(it) }.sortedWith(compareByDescending<Customer> { it.due }.thenBy { it.name })
        }
        val since = System.currentTimeMillis() - 62L * 86_400_000L
        regs += shop().collection("sales").whereGreaterThan("time", since)
            .orderBy("time", Query.Direction.DESCENDING)
            .addSnapshotListener { s, e ->
                onErr(e)
                if (s != null) sales.value = s.documents.map { Sale.from(it) }
            }
        regs += shop().collection("payments").orderBy("time", Query.Direction.DESCENDING).limit(500)
            .addSnapshotListener { s, e ->
                onErr(e)
                if (s != null) payments.value = s.documents.map { Payment.from(it) }
            }
        regs += shop().addSnapshotListener { d, _ -> shopName.value = d?.getString("name") ?: "" }
    }

    fun stop() {
        regs.forEach { it.remove() }
        regs.clear()
        uid = null
        products.value = emptyList(); customers.value = emptyList(); sales.value = emptyList(); payments.value = emptyList()
        loaded.value = false
    }

    fun productByCode(code: String): Product? = products.value.firstOrNull { it.matches(code.trim()) }

    fun saveProduct(p: Product, done: (Boolean) -> Unit = {}) {
        val col = shop().collection("products")
        val ref = if (p.id.isEmpty()) col.document() else col.document(p.id)
        ref.set(p.toMap())
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { error.value = it.message; done(false) }
    }

    fun deleteProduct(p: Product) {
        if (p.id.isNotEmpty()) shop().collection("products").document(p.id).delete()
    }

    fun setShopName(name: String) {
        shop().set(mapOf("name" to name), SetOptions.merge())
    }

    /** Creates a customer and gives back the new id. */
    fun addCustomer(name: String, phone: String): String {
        val ref = shop().collection("customers").document()
        ref.set(mapOf("name" to name, "phone" to phone, "due" to 0.0, "created" to System.currentTimeMillis()))
        return ref.id
    }

    fun updateCustomer(c: Customer, name: String, phone: String) {
        shop().collection("customers").document(c.id).set(mapOf("name" to name, "phone" to phone), SetOptions.merge())
    }

    fun deleteCustomer(c: Customer) {
        shop().collection("customers").document(c.id).delete()
    }

    /** Saves a sale: lowers the stock, and puts any unpaid part on the customer's baki. */
    fun checkout(lines: List<CartLine>, paid: Double, customer: Customer?, done: (Boolean) -> Unit) {
        val total = lines.sumOf { it.total }
        val profit = lines.filter { it.productId.isNotEmpty() }.sumOf { it.total - it.costTotal }
        val due = (total - paid).coerceAtLeast(0.0)
        val batch = db.batch()
        val saleRef = shop().collection("sales").document()
        batch.set(saleRef, mapOf(
            "time" to System.currentTimeMillis(),
            "items" to lines.map {
                mapOf("pid" to it.productId, "name" to it.name, "mode" to it.mode, "qty" to it.qty,
                    "price" to it.price, "cost" to it.cost, "stock" to it.stockUsed)
            },
            "total" to total, "profit" to profit, "paid" to (total - due), "due" to due,
            "customerId" to (customer?.id ?: ""), "customerName" to (customer?.name ?: ""),
            "by" to (Access.member.value?.uid ?: ""), "byName" to (Access.member.value?.name ?: ""),
        ))
        lines.filter { it.productId.isNotEmpty() }.groupBy { it.productId }.forEach { (pid, ls) ->
            val used = ls.sumOf { it.stockUsed }
            batch.update(shop().collection("products").document(pid), mapOf(
                "stock" to FieldValue.increment(-used),
                "sold" to FieldValue.increment(used),
            ))
        }
        if (customer != null && due > 0) {
            batch.update(shop().collection("customers").document(customer.id), "due", FieldValue.increment(due))
        }
        batch.commit()
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { error.value = it.message; done(false) }
    }

    /** Removes a sale and puts the stock and baki back as they were. */
    fun deleteSale(s: Sale) {
        val batch = db.batch()
        batch.delete(shop().collection("sales").document(s.id))
        s.items.filter { it.pid.isNotEmpty() && products.value.any { p -> p.id == it.pid } }.groupBy { it.pid }.forEach { (pid, its) ->
            val used = its.sumOf { it.stock }
            batch.update(shop().collection("products").document(pid), mapOf(
                "stock" to FieldValue.increment(used),
                "sold" to FieldValue.increment(-used),
            ))
        }
        if (s.customerId.isNotEmpty() && s.due > 0 && customers.value.any { it.id == s.customerId }) {
            batch.update(shop().collection("customers").document(s.customerId), "due", FieldValue.increment(-s.due))
        }
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    /** Customer pays back some of the baki. */
    fun addPayment(c: Customer, amount: Double, note: String) {
        val batch = db.batch()
        batch.set(shop().collection("payments").document(), mapOf(
            "customerId" to c.id, "amount" to amount, "time" to System.currentTimeMillis(), "note" to note
        ))
        batch.update(shop().collection("customers").document(c.id), "due", FieldValue.increment(-amount))
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    fun deletePayment(p: Payment) {
        val batch = db.batch()
        batch.delete(shop().collection("payments").document(p.id))
        if (customers.value.any { it.id == p.customerId }) {
            batch.update(shop().collection("customers").document(p.customerId), "due", FieldValue.increment(p.amount))
        }
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    /** Adds stock (new goods came in). */
    fun addStock(p: Product, amount: Double) {
        shop().collection("products").document(p.id).update("stock", FieldValue.increment(amount))
    }
}
