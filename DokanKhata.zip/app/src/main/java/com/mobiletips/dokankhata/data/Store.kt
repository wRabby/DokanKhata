package com.mobiletips.dokankhata.data

import androidx.compose.runtime.mutableStateOf
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/**
 * Everything lives online in Firestore under shops/{uid}/...
 * The lists below follow the cloud live, so every screen is always up to date.
 */
object Store {
    val products = mutableStateOf<List<Product>>(emptyList())
    val customers = mutableStateOf<List<Customer>>(emptyList())
    val sales = mutableStateOf<List<Sale>>(emptyList())        // last ~60 days
    val payments = mutableStateOf<List<Payment>>(emptyList())
    val shopName = mutableStateOf("")
    /** Hash of the shop's 4-digit PIN ("" = no PIN). */
    val pinHash = mutableStateOf("")
    var shopId: String? = null
        private set
    /** Sales and payments saved on the phone but not yet in the cloud (offline). */
    val pending = mutableStateOf(0)
    private var pendSales = 0
    private var pendPays = 0
    val loaded = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)

    private val regs = mutableListOf<ListenerRegistration>()
    private var uid: String? = null
    private val db get() = FirebaseFirestore.getInstance()
    private fun shop(): DocumentReference = db.collection("shops").document(uid ?: "none")

    fun start(u: String) {
        if (uid == u && regs.isNotEmpty()) return
        stop()
        uid = u
        val onErr: (Exception?) -> Unit = { e -> if (e != null) retry(u, e) }
        regs += shop().collection("products").addSnapshotListener { s, e ->
            onErr(e)
            if (s != null) {
                products.value = s.documents.map { Product.from(it) }.sortedWith(compareByDescending<Product> { it.sold }.thenBy { it.name })
                loaded.value = true
                retries = 0
            }
        }
        regs += shop().collection("customers").addSnapshotListener { s, e ->
            onErr(e)
            if (s != null) customers.value = s.documents.map { Customer.from(it) }.sortedWith(compareByDescending<Customer> { it.due }.thenBy { it.name })
        }
        val since = System.currentTimeMillis() - 62L * 86_400_000L
        regs += shop().collection("sales").whereGreaterThan("time", since)
            .orderBy("time", Query.Direction.DESCENDING)
            .addSnapshotListener(MetadataChanges.INCLUDE) { s, e ->
                onErr(e)
                if (s != null) {
                    sales.value = s.documents.map { Sale.from(it) }
                    pendSales = s.documents.count { it.metadata.hasPendingWrites() }
                    pending.value = pendSales + pendPays
                }
            }
        regs += shop().collection("payments").orderBy("time", Query.Direction.DESCENDING).limit(500)
            .addSnapshotListener(MetadataChanges.INCLUDE) { s, e ->
                onErr(e)
                if (s != null) {
                    payments.value = s.documents.map { Payment.from(it) }
                    pendPays = s.documents.count { it.metadata.hasPendingWrites() }
                    pending.value = pendSales + pendPays
                }
            }
        regs += shop().addSnapshotListener { d, _ ->
            shopName.value = d?.getString("name") ?: ""
            pinHash.value = d?.getString("pinHash") ?: ""
        }
        shopId = u
    }

    private var retries = 0
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    /** Right after approval the rules may need a moment; try again quietly a few times. */
    private fun retry(shopId: String, e: Exception) {
        if (uid != shopId) return
        if (retries >= 5) { error.value = e.message; return }
        retries++
        regs.forEach { it.remove() }; regs.clear()
        main.postDelayed({ if (uid == shopId) { uid = null; start(shopId) } }, 2000L * retries)
    }

    fun stop() {
        regs.forEach { it.remove() }
        regs.clear()
        uid = null
        shopId = null
        products.value = emptyList(); customers.value = emptyList(); sales.value = emptyList(); payments.value = emptyList()
        loaded.value = false
    }

    fun productByCode(code: String): Product? = products.value.firstOrNull { it.matches(code.trim()) }

    fun saveProduct(p: Product, done: (Boolean) -> Unit = {}) {
        val col = shop().collection("products")
        val ref = if (p.id.isEmpty()) col.document() else col.document(p.id)
        // works offline too: saved on the phone at once, sent to the cloud when online
        ref.set(p.toMap()).addOnFailureListener { error.value = it.message }
        done(true)
    }

    fun deleteProduct(p: Product) {
        if (p.id.isNotEmpty()) shop().collection("products").document(p.id).delete()
    }

    fun setShopName(name: String) {
        shop().set(mapOf("name" to name), SetOptions.merge())
    }

    /** Creates a customer and gives back the new id. */
    fun addCustomer(name: String, phone: String, photo: String = ""): String {
        val ref = shop().collection("customers").document()
        ref.set(mapOf("name" to name, "phone" to phone, "photo" to photo, "due" to 0.0, "created" to System.currentTimeMillis()))
        return ref.id
    }

    fun updateCustomer(c: Customer, name: String, phone: String, photo: String) {
        shop().collection("customers").document(c.id).set(mapOf("name" to name, "phone" to phone, "photo" to photo), SetOptions.merge())
    }

    /** Every sale (all time) put on one customer's baki. */
    fun customerSales(id: String, cb: (List<Sale>) -> Unit): ListenerRegistration =
        shop().collection("sales").whereEqualTo("customerId", id).addSnapshotListener { s, _ ->
            if (s != null) cb(s.documents.map { Sale.from(it) })
        }

    /** Every payment (all time) of one customer. */
    fun customerPayments(id: String, cb: (List<Payment>) -> Unit): ListenerRegistration =
        shop().collection("payments").whereEqualTo("customerId", id).addSnapshotListener { s, _ ->
            if (s != null) cb(s.documents.map { Payment.from(it) })
        }

    fun deleteCustomer(c: Customer) {
        shop().collection("customers").document(c.id).delete()
    }

    /** Saves a sale: lowers the stock, and puts any unpaid part on the customer's baki. */
    fun checkout(lines: List<CartLine>, paid: Double, customer: Customer?, done: (Boolean) -> Unit) {
        val total = lines.sumOf { it.total }
        val profit = lines.filter { it.productId.isNotEmpty() }.sumOf { it.total - it.costTotal }
        val due = (total - paid).coerceAtLeast(0.0)
        val batch = db.batch()
        val saleRef = shop().collection("sales").document()
        batch.set(saleRef, mapOf(
            "time" to System.currentTimeMillis(),
            "items" to lines.map {
                mapOf("pid" to it.productId, "name" to it.name, "mode" to it.mode, "qty" to it.qty,
                    "price" to it.price, "cost" to it.cost, "stock" to it.stockUsed)
            },
            "total" to total, "profit" to profit, "paid" to (total - due), "due" to due,
            "customerId" to (customer?.id ?: ""), "customerName" to (customer?.name ?: ""),
            "by" to (Access.member.value?.uid ?: ""), "byName" to (Access.member.value?.name ?: ""),
        ))
        lines.filter { it.productId.isNotEmpty() }.groupBy { it.productId }.forEach { (pid, ls) ->
            val used = ls.sumOf { it.stockUsed }
            batch.update(shop().collection("products").document(pid), mapOf(
                "stock" to FieldValue.increment(-used),
                "sold" to FieldValue.increment(used),
            ))
        }
        if (customer != null && due > 0) {
            batch.update(shop().collection("customers").document(customer.id), mapOf(
                "due" to FieldValue.increment(due), "lastAt" to System.currentTimeMillis()
            ))
        }
        // saved on the phone at once (also offline); goes to the cloud when online
        batch.commit().addOnFailureListener { error.value = it.message }
        done(true)
    }

    /** Removes a sale and puts the stock and baki back as they were. */
    fun deleteSale(s: Sale) {
        val batch = db.batch()
        batch.delete(shop().collection("sales").document(s.id))
        s.items.filter { it.pid.isNotEmpty() && products.value.any { p -> p.id == it.pid } }.groupBy { it.pid }.forEach { (pid, its) ->
            val used = its.sumOf { it.stock }
            batch.update(shop().collection("products").document(pid), mapOf(
                "stock" to FieldValue.increment(used),
                "sold" to FieldValue.increment(-used),
            ))
        }
        if (s.customerId.isNotEmpty() && s.due > 0 && customers.value.any { it.id == s.customerId }) {
            batch.update(shop().collection("customers").document(s.customerId), "due", FieldValue.increment(-s.due))
        }
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    /** Customer pays back (kind "pay"), or baki written by hand (kind "due"). Works offline too. */
    fun addPayment(c: Customer, amount: Double, note: String, kind: String = "pay", time: Long = System.currentTimeMillis()) {
        val batch = db.batch()
        batch.set(shop().collection("payments").document(), mapOf(
            "customerId" to c.id, "amount" to amount, "time" to time, "note" to note, "kind" to kind
        ))
        val delta = if (kind == "due") amount else -amount
        batch.update(shop().collection("customers").document(c.id), mapOf(
            "due" to FieldValue.increment(delta), "lastAt" to System.currentTimeMillis()
        ))
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    fun deletePayment(p: Payment) {
        val batch = db.batch()
        batch.delete(shop().collection("payments").document(p.id))
        if (customers.value.any { it.id == p.customerId }) {
            val back = if (p.isDue) -p.amount else p.amount
            batch.update(shop().collection("customers").document(p.customerId), "due", FieldValue.increment(back))
        }
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    /** Change the amount / note of a payment or hand-written baki (kept at the same time). */
    fun editPayment(p: Payment, amount: Double, note: String) {
        val batch = db.batch()
        batch.delete(shop().collection("payments").document(p.id))
        batch.set(shop().collection("payments").document(), mapOf(
            "customerId" to p.customerId, "amount" to amount, "time" to p.time, "note" to note, "kind" to p.kind
        ))
        val diff = amount - p.amount
        val delta = if (p.isDue) diff else -diff
        if (customers.value.any { it.id == p.customerId }) {
            batch.update(shop().collection("customers").document(p.customerId), "due", FieldValue.increment(delta))
        }
        batch.commit().addOnFailureListener { error.value = it.message }
    }

    /** Saves the shop PIN as a one-way hash ("" removes it). */
    fun setPin(pin: String) {
        val id = shopId ?: return
        val h = if (pin.isEmpty()) "" else pinHashOf(id, pin)
        shop().set(mapOf("pinHash" to h), SetOptions.merge())
    }

    fun pinOk(pin: String): Boolean {
        val id = shopId ?: return false
        return pinHash.value.isNotEmpty() && pinHashOf(id, pin) == pinHash.value
    }

    private fun pinHashOf(id: String, pin: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest("dk:$id:$pin".toByteArray()).joinToString("") { "%02x".format(it) }
    }

    /** Deletes every product, sale, customer and payment of this shop. */
    fun clearAll(done: () -> Unit) {
        val cols = listOf("products", "sales", "customers", "payments")
        var left = cols.size
        cols.forEach { name ->
            shop().collection(name).get().addOnSuccessListener { q ->
                q.documents.chunked(400).forEach { part ->
                    val b = db.batch()
                    part.forEach { b.delete(it.reference) }
                    b.commit()
                }
                left--
                if (left == 0) done()
            }.addOnFailureListener { error.value = it.message; left--; if (left == 0) done() }
        }
    }

    /** Adds stock (new goods came in). */
    fun addStock(p: Product, amount: Double) {
        shop().collection("products").document(p.id).update("stock", FieldValue.increment(amount))
    }
}
