package com.mobiletips.dokankhata.ui

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Auth
import com.mobiletips.dokankhata.data.Net
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.launch

/** Screens that open on top of the tabs. */
sealed class Page {
    data class EditProduct(val product: Product?, val barcode: String = "") : Page()
    data class CustomerPage(val id: String) : Page()
    data object History : Page()
    data object QrCards : Page()
}

object Nav {
    val tab = mutableStateOf(0)
    val page = mutableStateOf<Page?>(null)
    fun open(p: Page) { page.value = p }
    fun close() { page.value = null }
}

@Composable
fun App(activity: ComponentActivity) {
    MaterialTheme(colorScheme = lightColorScheme(primary = C.brand, secondary = C.brandDark, background = C.bg, surface = Color.White)) {
        Surface(color = C.bg, modifier = Modifier.fillMaxSize()) {
            val ready by Auth.ready
            val user by Auth.user
            val online by Net.online
            val err by Store.error
            val ctx = LocalContext.current
            LaunchedEffect(err) {
                err?.let { Toast.makeText(ctx, "সমস্যা: $it", Toast.LENGTH_LONG).show(); Store.error.value = null }
            }
            Box(Modifier.fillMaxSize()) {
                val u = user
                when {
                    !ready -> SetupScreen()
                    u == null -> LoginScreen(activity)
                    else -> {
                        LaunchedEffect(u.uid) { Access.start(u) }
                        Gate(activity)
                    }
                }
                if (!online) OfflineScreen()
            }
        }
    }
}

@Composable
private fun MainScreen(activity: ComponentActivity) {
    val page by Nav.page
    var tab by Nav.tab
    val loaded by Store.loaded
    val p = page
    if (p != null) {
        BackHandler { Nav.close() }
        when (p) {
            is Page.EditProduct -> ProductEditor(p.product, p.barcode)
            is Page.CustomerPage -> CustomerScreen(p.id)
            Page.History -> HistoryScreen()
            Page.QrCards -> QrScreen()
        }
        return
    }
    BackHandler(enabled = tab != 0) { tab = 0 }
    val items = listOf(
        Triple("হোম", Icons.Filled.Home, 0),
        Triple("বিক্রি", Icons.Filled.ShoppingCart, 1),
        Triple("পণ্য", Icons.Filled.List, 2),
        Triple("বাকি", Icons.Filled.Person, 3),
        Triple("আরও", Icons.Filled.Settings, 4),
    )
    Scaffold(
        containerColor = C.bg,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEach { (label, icon, i) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, null) }, label = { Text(label, fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, indicatorColor = C.brand, selectedTextColor = C.brand)
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
            if (!loaded) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = C.brand) }
            } else when (tab) {
                0 -> HomeScreen()
                1 -> SellScreen()
                2 -> ProductsScreen()
                3 -> BakiScreen()
                else -> MoreScreen(activity)
            }
        }
    }
}

@Composable
private fun LoginScreen(activity: ComponentActivity) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxSize().background(C.head).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(110.dp).clip(RoundedCornerShape(30.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Text("🏪", fontSize = 58.sp)
        }
        Gap(h = 22.dp)
        Text("দোকান খাতা", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("DOKAN KHATA", color = Color(0xFFFDE68A), fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Gap(h = 14.dp)
        Text("বিক্রি, স্টক আর বাকির হিসাব — স্ক্যান করলেই হিসাব", color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, fontSize = 16.sp)
        Gap(h = 40.dp)
        Button(
            onClick = {
                busy = true; msg = null
                scope.launch { msg = Auth.signIn(activity); busy = false }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = C.text),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = C.brand, strokeWidth = 2.dp)
            else Text("G   গুগল দিয়ে লগইন করুন", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        msg?.let { Gap(h = 12.dp); Text(it, color = Color(0xFFFDE68A), textAlign = TextAlign.Center) }
        Gap(h = 18.dp)
        Text("আপনার দোকানের সব হিসাব আপনার গুগল অ্যাকাউন্টে নিরাপদে থাকবে।", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SetupScreen() {
    Column(Modifier.fillMaxSize().background(C.head).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("⚙️", fontSize = 50.sp)
        Gap(h = 12.dp)
        Text("সেটআপ বাকি আছে", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Gap(h = 8.dp)
        Text("google-services.json ফাইলটা এখনো যোগ করা হয়নি। ফাইলটা দিয়ে আবার বিল্ড করুন।", color = Color.White, textAlign = TextAlign.Center)
    }
}

@Composable
private fun OfflineScreen() {
    Column(
        Modifier.fillMaxSize().background(Color(0xF20F172A))
            .clickable(remember { MutableInteractionSource() }, null) { }
            .padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("📶", fontSize = 54.sp)
        Gap(h = 14.dp)
        Text("ইন্টারনেট সংযোগ নেই", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Gap(h = 8.dp)
        Text("দোকান খাতা শুধু ইন্টারনেটে চলে। ওয়াই-ফাই বা মোবাইল ডেটা চালু করুন — চালু হলেই অ্যাপ নিজে থেকে খুলে যাবে।",
            color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center, fontSize = 15.sp)
    }
}

/** Opens the shop only for approved, active members. */
@Composable
private fun Gate(activity: ComponentActivity) {
    val m by Access.member
    val loaded by Access.loaded
    val scope = rememberCoroutineScope()
    val mm = m
    when {
        !loaded || mm == null -> Box(Modifier.fillMaxSize().background(C.head), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
        mm.status == "blocked" -> InfoScreen("⛔", "অ্যাকাউন্ট বন্ধ", "আপনার এই অ্যাকাউন্টটি অ্যাডমিন বন্ধ রেখেছেন। চালু করতে অ্যাডমিনের সাথে যোগাযোগ করুন।", mm.email) {
            scope.launch { Auth.signOut(activity) }
        }
        mm.status != "active" || mm.shopId.isEmpty() -> InfoScreen("⏳", "অনুমতির অপেক্ষায়", "আপনার অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে। অনুমতি দিলেই অ্যাপ নিজে থেকে খুলে যাবে — অ্যাপ বন্ধ করার দরকার নেই।", mm.email) {
            scope.launch { Auth.signOut(activity) }
        }
        mm.expired -> InfoScreen("📅", "মেয়াদ শেষ", "আপনার ব্যবহারের মেয়াদ ${dateBn(mm.expires)} তারিখে শেষ হয়েছে। মেয়াদ বাড়াতে অ্যাডমিনের সাথে যোগাযোগ করুন।", mm.email) {
            scope.launch { Auth.signOut(activity) }
        }
        else -> {
            DisposableEffect(mm.shopId) {
                Store.start(mm.shopId)
                onDispose { Store.stop() }
            }
            MainScreen(activity)
        }
    }
}

@Composable
private fun InfoScreen(icon: String, title: String, text: String, email: String, onLogout: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(C.head).padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, fontSize = 60.sp)
        Gap(h = 16.dp)
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Gap(h = 10.dp)
        Text(text, color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, fontSize = 16.sp)
        Gap(h = 18.dp)
        Text(email, color = Color(0xFFFDE68A), fontSize = 14.sp)
        Gap(h = 30.dp)
        Text("অন্য অ্যাকাউন্টে ঢুকুন", color = Color.White, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f))
                .clickable(onClick = onLogout).padding(horizontal = 20.dp, vertical = 12.dp))
    }
}
