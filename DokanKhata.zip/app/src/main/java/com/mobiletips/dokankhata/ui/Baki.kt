package com.mobiletips.dokankhata.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Payment
import com.mobiletips.dokankhata.data.Sale
import com.mobiletips.dokankhata.data.Store
import java.util.Calendar

/** "5 minutes ago" style. */
fun agoText(t: Long): String {
    if (t <= 0) return ""
    val m = (System.currentTimeMillis() - t) / 60_000
    return when {
        m < 1 -> L("এইমাত্র", "just now")
        m < 60 -> bn("$m") + L(" মিনিট আগে", " min ago")
        m < 60 * 24 -> bn("${m / 60}") + L(" ঘণ্টা আগে", " hours ago")
        else -> bn("${m / (60 * 24)}") + L(" দিন আগে", " days ago")
    }
}

@Composable
fun BakiScreen() {
    val ctx = LocalContext.current
    val customers by Store.customers
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Customer?>(null) }
    var viewPhoto by remember { mutableStateOf<Customer?>(null) }
    var q by remember { mutableStateOf("") }
    val totalDue = customers.sumOf { it.due.coerceAtLeast(0.0) }
    val totalAdv = customers.sumOf { (-it.due).coerceAtLeast(0.0) }
    val shown = customers.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.phone.contains(q.trim()) }
        .sortedByDescending { it.lastAt }

    Column(Modifier.fillMaxSize()) {
        Header(L("বাকির খাতা", "Baki book"), bn("${customers.count { it.due > 0.001 }}") + L(" জনের কাছে বাকি", " people owe money"))
        Row(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(vertical = 12.dp)) {
            Stat(L("কাস্টমার", "Customers"), bn("${customers.size}"), C.text, Modifier.weight(1f))
            Stat(L("মোট বাকি", "Total due"), tk(totalDue), C.red, Modifier.weight(1f))
            Stat(L("মোট অগ্রিম", "Advance"), tk(totalAdv), C.green, Modifier.weight(1f))
        }
        OutlinedTextField(
            q, { q = it }, placeholder = { Text(L("নাম বা মোবাইল দিয়ে খুঁজুন…", "Search name or mobile…")) },
            leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
            trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Filled.Close, L("মুছুন", "Clear")) } },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp)
        )
        if (customers.isEmpty()) {
            Text(L("এখনো কোনো কাস্টমার নেই। নিচের বাটনে চাপ দিয়ে যোগ করুন।", "No customers yet. Add one with the button below."),
                color = C.sub, modifier = Modifier.padding(20.dp))
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.id }) { c ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White)) {
                    Row(
                        Modifier.fillMaxWidth().clickable { Nav.open(Page.CustomerPage(c.id)) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.clickable { if (c.photo.isNotEmpty()) viewPhoto = c else Nav.open(Page.CustomerPage(c.id)) }) {
                            Thumb(c.photo, c.name, 54.dp, 27.dp)
                        }
                        Gap(w = 12.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (c.phone.isNotBlank()) Text(bn(c.phone), color = C.sub, fontSize = 13.sp)
                            Text(agoText(c.lastAt), color = C.sub, fontSize = 12.sp)
                        }
                        DueBox(c.due)
                    }
                    Row(Modifier.fillMaxWidth().background(C.bg.copy(alpha = 0.6f)).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (c.phone.isNotBlank()) TextButton({
                            try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}"))) } catch (e: Exception) { }
                        }) { Text("📞 " + L("কল", "Call"), color = C.green) }
                        TextButton({ Guard.ask(L("${c.name}-এর তথ্য বদলাবেন?", "Edit ${c.name}?"), danger = false) { editing = c } }) {
                            Text("✏️ " + L("এডিট", "Edit"), color = C.text)
                        }
                        Box(Modifier.weight(1f))
                        if (Access.can("delete")) TextButton({
                            Guard.ask(if (c.due > 0.001) L("${c.name}-এর এখনো ${tk(c.due)} বাকি! মুছবেন?", "${c.name} still owes ${tk(c.due)}! Delete?")
                                else L("${c.name}-কে মুছবেন?", "Delete ${c.name}?")) { Store.deleteCustomer(c) }
                        }) { Text("🗑 " + L("মুছুন", "Delete"), color = C.red) }
                    }
                }
            }
            item { Gap(h = 76.dp) }
        }
        Button(
            { adding = true }, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = C.brand),
            modifier = Modifier.fillMaxWidth().padding(12.dp).height(52.dp)
        ) { Text(L("＋ নতুন কাস্টমার যোগ করুন", "＋ Add new customer"), fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
    if (adding) CustomerDialog(null, "", { adding = false }) { n, ph, photo -> Store.addCustomer(n, ph, photo); adding = false }
    editing?.let { c -> CustomerDialog(c, "", { editing = null }) { n, ph, photo -> Store.updateCustomer(c, n, ph, photo); editing = null } }
    viewPhoto?.let { c -> PhotoViewer(c.photo, c.name) { viewPhoto = null } }
}

@Composable
private fun Stat(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = C.sub, fontSize = 12.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
    }
}

@Composable
private fun DueBox(due: Double) {
    val owes = due > 0.001
    val adv = due < -0.001
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).background(if (owes) C.redSoft else C.brandSoft).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(if (owes) L("মোট বাকি", "Total due") else if (adv) L("অগ্রিম", "Advance") else L("পরিশোধ", "Paid"), fontSize = 11.sp, color = if (owes) C.red else C.green)
        Text(if (owes || adv) tk(kotlin.math.abs(due)) else "✓", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (owes) C.red else C.green)
    }
}

/** Add or change a customer: name, mobile and (optional) photo. */
@Composable
fun CustomerDialog(c: Customer?, startName: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf(c?.name ?: startName) }
    var phone by remember { mutableStateOf(c?.phone ?: "") }
    var photo by remember { mutableStateOf(c?.photo ?: "") }
    val taker = rememberPhotoTaker { bm -> photo = Img.encode(bm, 480) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c == null) L("নতুন কাস্টমার", "New customer") else L("কাস্টমার বদলান", "Edit customer")) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Thumb(photo, name.ifBlank { "+" }, 70.dp, 35.dp)
                    Gap(w = 10.dp)
                    Column {
                        TextButton(taker.camera) { Text(L("📷 ছবি তুলুন", "📷 Take photo")) }
                        TextButton(taker.gallery) { Text(L("🖼 গ্যালারি", "🖼 Gallery")) }
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text(L("নাম", "Name")) }, singleLine = true)
                Gap(h = 6.dp)
                OutlinedTextField(phone, { phone = it }, label = { Text(L("মোবাইল নম্বর (ঐচ্ছিক)", "Mobile (optional)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
        },
        confirmButton = { Button({ onSave(name.trim(), phone.trim(), photo) }, enabled = name.isNotBlank()) { Text(L("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** One line of a customer's history. */
private class Entry(val time: Long, val sale: Sale?, val pay: Payment?, val plus: Double, val minus: Double, var balance: Double = 0.0)

/** One customer's baki book: dues, payments, running total, filters, edit / delete. */
@Composable
fun CustomerScreen(id: String) {
    val ctx = LocalContext.current
    val customers by Store.customers
    val c = customers.firstOrNull { it.id == id }
    if (c == null) { LaunchedEffect(id) { Nav.close() }; return }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var pays by remember { mutableStateOf<List<Payment>>(emptyList()) }
    DisposableEffect(id) {
        val a = Store.customerSales(id) { sales = it }
        val b = Store.customerPayments(id) { pays = it }
        onDispose { a.remove(); b.remove() }
    }
    var entryKind by remember { mutableStateOf<String?>(null) }      // "due" or "pay"
    var editEntry by remember { mutableStateOf<Payment?>(null) }
    var editCustomer by remember { mutableStateOf(false) }
    var viewPhoto by remember { mutableStateOf(false) }
    var range by remember { mutableStateOf("all") }
    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    val canBaki = Access.can("baki")
    val canDel = Access.can("delete")

    val all = remember(sales, pays) {
        val list = sales.filter { it.due > 0.001 }.map { Entry(it.time, it, null, it.due, 0.0) } +
            pays.map { p -> if (p.isDue) Entry(p.time, null, p, p.amount, 0.0) else Entry(p.time, null, p, 0.0, p.amount) }
        var bal = 0.0
        list.sortedBy { it.time }.onEach { bal += it.plus - it.minus; it.balance = bal }.reversed()
    }
    val (start, end) = rangeOf(range, from, to)
    val rows = all.filter { it.time in start until end }
    val sumDue = rows.sumOf { it.plus }
    val sumPay = rows.sumOf { it.minus }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(c.name, if (c.phone.isNotBlank()) bn(c.phone) else "") {
            if (c.phone.isNotBlank()) IconButton({
                try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}"))) } catch (e: Exception) { }
            }) { Icon(Icons.Filled.Call, L("ফোন করুন", "Call"), tint = Color.White) }
            IconButton({ Guard.ask(L("${c.name}-এর তথ্য বদলাবেন?", "Edit ${c.name}?"), danger = false) { editCustomer = true } }) {
                Icon(Icons.Filled.Edit, L("বদলান", "Edit"), tint = Color.White)
            }
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, L("পেছনে", "Back"), tint = Color.White) }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clickable { if (c.photo.isNotEmpty()) viewPhoto = true }) { Thumb(c.photo, c.name, 60.dp, 30.dp) }
                    Gap(w = 12.dp)
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(L("শেষ লেনদেন: ", "Last entry: ") + agoText(c.lastAt), color = C.sub, fontSize = 12.sp)
                    }
                    DueBox(c.due)
                }
                if (canBaki) Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button({ entryKind = "due" }, Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text(L("＋ বাকি লিখুন", "＋ Add due"), fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                    Button({ entryKind = "pay" }, Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))) { Text(L("＋ টাকা পেলাম", "＋ Got payment"), fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                }
                Row(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(vertical = 12.dp)) {
                    Stat(L("মোট বাকি", "Total due"), tk(sumDue), C.red, Modifier.weight(1f))
                    Stat(L("মোট জমা", "Total paid"), tk(sumPay), Color(0xFF2563EB), Modifier.weight(1f))
                    Stat(L("বাকি রইল", "Remaining"), tk(if (range == "all") c.due else sumDue - sumPay), C.red, Modifier.weight(1f))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("day" to L("আজ", "Day"), "month" to L("এই মাস", "Month"), "year" to L("এই বছর", "Year"),
                        "all" to L("সব সময়", "All time"), "custom" to L("নিজের তারিখ", "Custom")).forEach { (k, l) ->
                        Chip(l, range == k, C.red) { range = k }
                    }
                }
                if (range == "custom") Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(from, { from = it }, label = { Text(L("থেকে (দিন/মাস/বছর)", "From (d/m/y)")) }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(to, { to = it }, label = { Text(L("পর্যন্ত", "To")) }, singleLine = true, modifier = Modifier.weight(1f))
                }
                if (rows.isEmpty()) Text(L("এই সময়ে কোনো লেনদেন নেই।", "Nothing in this period."), color = C.sub, modifier = Modifier.padding(16.dp))
            }
            items(rows, key = { (it.sale?.id ?: it.pay?.id ?: "") + it.time }) { r -> EntryCard(r, canDel) { editEntry = it } }
            item { Gap(h = 24.dp) }
        }
    }

    entryKind?.let { k ->
        EntryDialog(k, c, null, { entryKind = null }) { amt, note ->
            Store.addPayment(c, amt, note, k)
            if (k == "due") Voice.say("${c.name}-এর নামে ${sayNum(amt)} টাকা বাকি লেখা হলো, মোট বাকি ${sayNum(c.due + amt)} টাকা",
                "${sayNum(amt)} taka due added for ${c.name}. Total ${sayNum(c.due + amt)} taka")
            else Voice.say("${c.name} ${sayNum(amt)} টাকা জমা দিলেন, বাকি রইল ${sayNum(c.due - amt)} টাকা",
                "${c.name} paid ${sayNum(amt)} taka. ${sayNum(c.due - amt)} taka left")
            entryKind = null
        }
    }
    editEntry?.let { p ->
        EntryDialog(p.kind, c, p, { editEntry = null }) { amt, note -> Store.editPayment(p, amt, note); editEntry = null }
    }
    if (editCustomer) CustomerDialog(c, "", { editCustomer = false }) { n, ph, photo -> Store.updateCustomer(c, n, ph, photo); editCustomer = false }
    if (viewPhoto) PhotoViewer(c.photo, c.name) { viewPhoto = false }
}

@Composable
private fun EntryCard(r: Entry, canDel: Boolean, onEdit: (Payment) -> Unit) {
    val isDue = r.plus > 0
    val color = if (isDue) C.red else Color(0xFF2563EB)
    Row(Modifier.padding(horizontal = 12.dp).fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 18.dp).size(12.dp).clip(CircleShape).background(color))
        Gap(w = 10.dp)
        Column(
            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Color.White).border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(14.dp)).padding(12.dp)
                .semantics(mergeDescendants = true) {
                    contentDescription = (if (isDue) L("বাকি ", "Due ") + tk(r.plus) else L("জমা ", "Paid ") + tk(r.minus)) + ", " + dateBn(r.time) + ", " + L("মোট বাকি ", "total due ") + tk(r.balance)
                }
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(if (isDue) L("বাকি: ", "Due: ") + tk(r.plus) else L("জমা: ", "Paid: ") + tk(r.minus), color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(dateBn(r.time) + ", " + timeBn(r.time), color = C.sub, fontSize = 12.sp)
                }
                Column(
                    Modifier.clip(RoundedCornerShape(10.dp)).background(C.redSoft.copy(alpha = 0.6f)).padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(L("মোট বাকি", "Total due"), fontSize = 11.sp, color = C.red)
                    Text(tk(r.balance), fontWeight = FontWeight.Bold, color = C.red)
                }
            }
            val s = r.sale
            if (s != null) Text("🛒 " + s.items.joinToString(", ") { it.name + " " + qtyText(it.mode, it.qty) }, fontSize = 13.sp, color = C.text, modifier = Modifier.padding(top = 6.dp))
            val p = r.pay
            if (p != null && p.note.isNotBlank()) Text("📝 " + p.note, fontSize = 13.sp, color = C.text, modifier = Modifier.padding(top = 6.dp))
            if (canDel) Row(Modifier.padding(top = 4.dp)) {
                if (p != null) TextButton({ Guard.ask(L("এই লেখাটা বদলাবেন?", "Edit this entry?"), danger = false) { onEdit(p) } }) {
                    Text("✏️ " + L("এডিট", "Edit"), color = C.text)
                }
                TextButton({
                    Guard.ask(L("এই লেখাটা মুছবেন?", "Delete this entry?")) {
                        if (p != null) Store.deletePayment(p) else if (s != null) Store.deleteSale(s)
                    }
                }) { Text("🗑 " + L("মুছুন", "Delete"), color = C.red) }
            }
        }
    }
}

/** Write a due (baki) or a payment; date and time are taken from now automatically. */
@Composable
private fun EntryDialog(kind: String, c: Customer, old: Payment?, onDismiss: () -> Unit, onSave: (Double, String) -> Unit) {
    var amt by remember { mutableStateOf(old?.let { numPlain(it.amount) } ?: "") }
    var note by remember { mutableStateOf(old?.note ?: "") }
    val due = kind == "due"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (due) L("বাকি লিখুন — ", "Add due — ") + c.name else L("টাকা পেলাম — ", "Got payment — ") + c.name) },
        text = {
            Column {
                OutlinedTextField(amt, { amt = it }, label = { Text(L("কত টাকা", "Amount")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (!due && old == null && c.due > 0) Text(L("পুরো বাকি: ", "Full due: ") + tk(c.due), color = C.brand, fontSize = 13.sp,
                    modifier = Modifier.clickable { amt = numPlain(c.due) }.padding(vertical = 8.dp))
                OutlinedTextField(note, { note = it }, label = { Text(if (due) L("কী নিল / নোট (ঐচ্ছিক)", "What / note (optional)") else L("নোট (ঐচ্ছিক)", "Note (optional)")) }, singleLine = true)
                Text("🕒 " + dateBn(old?.time ?: System.currentTimeMillis()) + ", " + timeBn(old?.time ?: System.currentTimeMillis()),
                    color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = {
            val a = parseNum(amt) ?: 0.0
            Button({ if (a > 0) onSave(a, note.trim()) }, enabled = a > 0,
                colors = ButtonDefaults.buttonColors(containerColor = if (due) C.red else Color(0xFF2563EB))) { Text(L("সেভ", "Save")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** Start and end (ms) of the chosen period. Custom dates are typed as d/m/y. */
private fun rangeOf(k: String, from: String, to: String): Pair<Long, Long> {
    val now = System.currentTimeMillis()
    val c = Calendar.getInstance()
    fun startOfDay(cal: Calendar) { cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0) }
    return when (k) {
        "day" -> { startOfDay(c); c.timeInMillis to Long.MAX_VALUE }
        "month" -> { startOfDay(c); c.set(Calendar.DAY_OF_MONTH, 1); c.timeInMillis to Long.MAX_VALUE }
        "year" -> { startOfDay(c); c.set(Calendar.DAY_OF_YEAR, 1); c.timeInMillis to Long.MAX_VALUE }
        "custom" -> {
            val a = parseDate(from) ?: 0L
            val b = parseDate(to)?.plus(86_400_000L) ?: Long.MAX_VALUE
            a to b
        }
        else -> 0L to Long.MAX_VALUE
    }.let { if (it.second < it.first) it.first to now else it }
}

private fun parseDate(s: String): Long? {
    val p = s.trim().map { ch -> val i = "০১২৩৪৫৬৭৮৯".indexOf(ch); if (i >= 0) ('0' + i) else ch }.joinToString("")
        .split('/', '-', '.', ' ').filter { it.isNotBlank() }.mapNotNull { it.toIntOrNull() }
    if (p.size != 3) return null
    val y = if (p[2] < 100) 2000 + p[2] else p[2]
    return Calendar.getInstance().apply { set(y, p[1] - 1, p[0], 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
}

fun numPlain(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v)
