package com.mobiletips.dokankhata.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Payment
import com.mobiletips.dokankhata.data.Sale
import com.mobiletips.dokankhata.data.Store

@Composable
fun BakiScreen() {
    val customers by Store.customers
    var adding by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val totalDue = customers.sumOf { it.due.coerceAtLeast(0.0) }
    val shown = customers.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.phone.contains(q.trim()) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header(L("বাকির খাতা", "Baki book"), bn("${customers.count { it.due > 0.001 }}") + L(" জনের কাছে বাকি", " people owe money"))
            Column(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp)) {
                Text(L("মোট পাওনা", "Total to collect"), color = C.sub, fontSize = 13.sp)
                Text(tk(totalDue), color = C.red, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedTextField(
                q, { q = it }, placeholder = { Text(L("নাম বা মোবাইল দিয়ে খুঁজুন…", "Search name or mobile…")) },
                leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
                trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Filled.Close, L("মুছুন", "Clear")) } },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 8.dp)
            )
            if (customers.isEmpty()) {
                Text(L("এখনো কোনো কাস্টমার নেই। বিক্রির সময় 'কাস্টমার বাছুন' থেকে বা নিচের বাটনে চাপ দিলে যোগ হবে।",
                    "No customers yet. Add one from 'Choose customer' while selling, or with the button below."),
                    color = C.sub, modifier = Modifier.padding(20.dp))
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White)
                            .clickable { Nav.open(Page.CustomerPage(c.id)) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(c.photo, c.name, 46.dp, 23.dp)
                        Gap(w = 12.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            if (c.phone.isNotBlank()) Text(bn(c.phone), color = C.sub, fontSize = 13.sp)
                        }
                        Text(if (c.due > 0.001) tk(c.due) else L("পরিশোধ ✓", "Paid ✓"), color = if (c.due > 0.001) C.red else C.green, fontWeight = FontWeight.Bold)
                    }
                }
                item { Gap(h = 80.dp) }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { adding = true }, containerColor = C.brand, contentColor = Color.White,
            icon = { Icon(Icons.Filled.Add, null) }, text = { Text(L("নতুন কাস্টমার", "New customer"), fontWeight = FontWeight.Bold) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
    if (adding) CustomerDialog(null, "", { adding = false }) { n, ph, photo -> Store.addCustomer(n, ph, photo); adding = false }
}

/** Add or change a customer: name, mobile and (optional) photo. */
@Composable
fun CustomerDialog(c: Customer?, startName: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(c?.name ?: startName) }
    var phone by remember { mutableStateOf(c?.phone ?: "") }
    var photo by remember { mutableStateOf(c?.photo ?: "") }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bm: Bitmap? ->
        if (bm != null) photo = Img.encode(bm, 240)
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) try {
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = 4 })?.let { photo = Img.encode(it, 240) }
            }
        } catch (e: Exception) { }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c == null) L("নতুন কাস্টমার", "New customer") else L("কাস্টমার বদলান", "Edit customer")) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Thumb(photo, name.ifBlank { "+" }, 64.dp, 32.dp)
                    Gap(w = 10.dp)
                    Column {
                        TextButton({ camera.launch(null) }) { Text(L("📷 ছবি তুলুন", "📷 Take photo")) }
                        TextButton({ gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text(L("🖼 গ্যালারি", "🖼 Gallery")) }
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text(L("নাম", "Name")) }, singleLine = true)
                Gap(h = 6.dp)
                OutlinedTextField(phone, { phone = it }, label = { Text(L("মোবাইল নম্বর (ঐচ্ছিক)", "Mobile (optional)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
        },
        confirmButton = { Button({ onSave(name.trim(), phone.trim(), photo) }, enabled = name.isNotBlank()) { Text(L("সেভ", "Save")) } },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** One customer's baki: everything taken and paid back, with the running balance. */
@Composable
fun CustomerScreen(id: String) {
    val ctx = LocalContext.current
    val customers by Store.customers
    val c = customers.firstOrNull { it.id == id }
    if (c == null) { LaunchedEffect(id) { Nav.close() }; return }
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var pays by remember { mutableStateOf<List<Payment>>(emptyList()) }
    DisposableEffect(id) {
        val a = Store.customerSales(id) { sales = it }
        val b = Store.customerPayments(id) { pays = it }
        onDispose { a.remove(); b.remove() }
    }
    var pay by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var askDel by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }

    // oldest first to count the balance, then show newest first
    data class Row2(val time: Long, val sale: Sale?, val pay: Payment?, val balance: Double)
    val rows = remember(sales, pays) {
        val ev = (sales.filter { it.due > 0.001 }.map { it.time to (it as Any) } + pays.map { it.time to (it as Any) }).sortedBy { it.first }
        var bal = 0.0
        ev.map { (t, x) ->
            if (x is Sale) { bal += x.due; Row2(t, x, null, bal) } else { val p = x as Payment; bal -= p.amount; Row2(t, null, p, bal) }
        }.reversed()
    }
    val canBaki = Access.can("baki")
    val canDel = Access.can("delete")

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(c.name, if (c.phone.isNotBlank()) bn(c.phone) else "") {
            if (c.phone.isNotBlank()) IconButton({
                try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}"))) } catch (e: Exception) { }
            }) { Icon(Icons.Filled.Call, L("ফোন করুন", "Call"), tint = Color.White) }
            IconButton({ edit = true }) { Icon(Icons.Filled.Edit, L("বদলান", "Edit"), tint = Color.White) }
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, L("পেছনে", "Back"), tint = Color.White) }
        }
        Row(
            Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Thumb(c.photo, c.name, 56.dp, 28.dp)
            Gap(w = 12.dp)
            Column(Modifier.weight(1f)) {
                Text(L("মোট বাকি", "Total baki"), color = C.sub, fontSize = 13.sp)
                Text(tk(c.due.coerceAtLeast(0.0)), color = if (c.due > 0.001) C.red else C.green, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            if (canBaki) Button({ pay = true }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.green)) {
                Text(L("৳ টাকা জমা", "৳ Payment"), fontWeight = FontWeight.Bold)
            }
        }
        Text(L("ইতিহাস", "History"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (rows.isEmpty()) item { Text(L("এখনো কোনো লেনদেন নেই।", "No entries yet."), color = C.sub, modifier = Modifier.padding(8.dp)) }
            items(rows, key = { it.sale?.id ?: it.pay?.id ?: it.time.toString() }) { r ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (r.sale != null) "🛒" else "💵", fontSize = 22.sp)
                    Gap(w = 10.dp)
                    Column(Modifier.weight(1f)) {
                        val s = r.sale
                        val p = r.pay
                        if (s != null) {
                            Text(s.items.joinToString(", ") { it.name + " " + qtyText(it.mode, it.qty) }, fontWeight = FontWeight.Bold, maxLines = 3, fontSize = 14.sp)
                            Text(L("মোট ", "Total ") + tk(s.total) + L(" · দিয়েছে ", " · paid ") + tk(s.paid), color = C.sub, fontSize = 12.sp)
                        } else if (p != null) {
                            Text(L("টাকা জমা দিয়েছে", "Paid back"), fontWeight = FontWeight.Bold, color = C.green, fontSize = 14.sp)
                            if (p.note.isNotBlank()) Text(p.note, color = C.sub, fontSize = 12.sp)
                        }
                        Text(dateBn(r.time) + " · " + timeBn(r.time), color = C.sub, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        if (r.sale != null) Text("+" + tk(r.sale.due), color = C.red, fontWeight = FontWeight.Bold)
                        if (r.pay != null) Text("−" + tk(r.pay.amount), color = C.green, fontWeight = FontWeight.Bold)
                        Text(L("বাকি ", "Bal ") + tk(r.balance), color = C.sub, fontSize = 11.sp)
                    }
                    if (r.pay != null && canDel) IconButton({ delPay = r.pay }) { Icon(Icons.Filled.Delete, L("জমা মুছুন", "Delete payment"), tint = C.sub) }
                }
            }
            item {
                if (canDel) TextButton({ askDel = true }) { Text(L("🗑 কাস্টমার মুছে ফেলুন", "🗑 Delete customer"), color = C.red) }
                Gap(h = 20.dp)
            }
        }
    }

    if (pay) {
        var amt by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pay = false },
            title = { Text(c.name + L(" টাকা দিল", " paid")) },
            text = {
                Column {
                    OutlinedTextField(amt, { amt = it }, label = { Text(L("কত টাকা", "How much")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Text(L("পুরো বাকি: ", "Full baki: ") + tk(c.due), color = C.brand, fontSize = 13.sp,
                        modifier = Modifier.clickable { amt = numPlain(c.due) }.padding(vertical = 8.dp))
                    OutlinedTextField(note, { note = it }, label = { Text(L("নোট (ঐচ্ছিক)", "Note (optional)")) }, singleLine = true)
                }
            },
            confirmButton = {
                Button({
                    val a = parseNum(amt) ?: 0.0
                    if (a > 0) {
                        Store.addPayment(c, a, note.trim())
                        val left = (c.due - a).coerceAtLeast(0.0)
                        Voice.say("${c.name} ${sayNum(a)} টাকা জমা দিলেন, বাকি রইল ${sayNum(left)} টাকা",
                            "${c.name} paid ${sayNum(a)} taka. ${sayNum(left)} taka left")
                    }
                    pay = false
                }, enabled = (parseNum(amt) ?: 0.0) > 0) { Text(L("জমা করুন", "Save payment")) }
            },
            dismissButton = { TextButton({ pay = false }) { Text(L("বাতিল", "Cancel")) } }
        )
    }
    if (edit) CustomerDialog(c, "", { edit = false }) { n, ph, photo -> Store.updateCustomer(c, n, ph, photo); edit = false }
    if (askDel) AlertDialog(
        onDismissRequest = { askDel = false },
        title = { Text(L("কাস্টমার মুছবেন?", "Delete customer?")) },
        text = { Text(if (c.due > 0.001) L("এখনো ", "Still ") + tk(c.due) + L(" বাকি আছে! মুছলে এই বাকির হিসাব আর দেখা যাবে না।", " is owed! Deleting hides this baki.")
            else c.name + L(" তালিকা থেকে মুছে যাবে।", " will be removed from the list.")) },
        confirmButton = { Button({ Store.deleteCustomer(c); askDel = false; Nav.close() }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text(L("মুছুন", "Delete")) } },
        dismissButton = { TextButton({ askDel = false }) { Text(L("না", "No")) } }
    )
    delPay?.let { p ->
        AlertDialog(
            onDismissRequest = { delPay = null },
            title = { Text(L("জমা মুছবেন?", "Delete payment?")) },
            text = { Text(tk(p.amount) + L(" জমাটা মুছলে বাকি আবার ", " — deleting it adds ") + tk(p.amount) + L(" বেড়ে যাবে।", " back to the baki.")) },
            confirmButton = { Button({ Store.deletePayment(p); delPay = null }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text(L("মুছুন", "Delete")) } },
            dismissButton = { TextButton({ delPay = null }) { Text(L("না", "No")) } }
        )
    }
}

fun numPlain(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v)
