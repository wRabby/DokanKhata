package com.mobiletips.dokankhata.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Payment
import com.mobiletips.dokankhata.data.Sale
import com.mobiletips.dokankhata.data.Store

@Composable
fun BakiScreen() {
    val customers by Store.customers
    var adding by remember { mutableStateOf(false) }
    val totalDue = customers.sumOf { it.due.coerceAtLeast(0.0) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("বাকির খাতা", bn("${customers.count { it.due > 0.001 }}") + " জনের কাছে বাকি")
            Column(
                Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp)
            ) {
                Text("মোট পাওনা", color = C.sub, fontSize = 13.sp)
                Text(tk(totalDue), color = C.red, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            if (customers.isEmpty()) {
                Text("এখনো কোনো কাস্টমার নেই। বিক্রির সময় 'বাকি' দিলে বা নিচের বাটনে চাপ দিলে যোগ হবে।",
                    color = C.sub, modifier = Modifier.padding(20.dp))
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(customers, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White)
                            .clickable { Nav.open(Page.CustomerPage(c.id)) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.name)
                        Gap(w = 12.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            if (c.phone.isNotBlank()) Text(bn(c.phone), color = C.sub, fontSize = 13.sp)
                        }
                        Text(if (c.due > 0.001) tk(c.due) else "পরিশোধ ✓", color = if (c.due > 0.001) C.red else C.green, fontWeight = FontWeight.Bold)
                    }
                }
                item { Gap(h = 80.dp) }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { adding = true }, containerColor = C.brand, contentColor = Color.White,
            icon = { Icon(Icons.Filled.Add, null) }, text = { Text("নতুন কাস্টমার", fontWeight = FontWeight.Bold) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
    if (adding) CustomerDialog(null, { adding = false }) { n, ph -> Store.addCustomer(n, ph); adding = false }
}

@Composable
private fun Avatar(name: String) {
    Box(Modifier.size(44.dp).clip(CircleShape).background(C.brandSoft), contentAlignment = Alignment.Center) {
        Text(name.take(1), fontWeight = FontWeight.Bold, color = C.brandDark, fontSize = 18.sp)
    }
}

@Composable
private fun CustomerDialog(c: Customer?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf(c?.name ?: "") }
    var phone by remember { mutableStateOf(c?.phone ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (c == null) "নতুন কাস্টমার" else "কাস্টমার বদলান") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("নাম") }, singleLine = true)
                Gap(h = 6.dp)
                OutlinedTextField(phone, { phone = it }, label = { Text("মোবাইল নম্বর (ঐচ্ছিক)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
        },
        confirmButton = { Button({ onSave(name.trim(), phone.trim()) }, enabled = name.isNotBlank()) { Text("সেভ") } },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    )
}

/** One customer's baki: what they took and what they paid back. */
@Composable
fun CustomerScreen(id: String) {
    val ctx = LocalContext.current
    val customers by Store.customers
    val sales by Store.sales
    val payments by Store.payments
    val c = customers.firstOrNull { it.id == id }
    if (c == null) { LaunchedEffect(id) { Nav.close() }; return }
    var pay by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(false) }
    var askDel by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    val rows: List<Pair<Long, Any>> = (sales.filter { it.customerId == id }.map { it.time to it as Any } +
        payments.filter { it.customerId == id }.map { it.time to it as Any }).sortedByDescending { it.first }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(c.name, if (c.phone.isNotBlank()) bn(c.phone) else "") {
            if (c.phone.isNotBlank()) IconButton({
                try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}"))) } catch (e: Exception) { }
            }) { Icon(Icons.Filled.Call, null, tint = Color.White) }
            IconButton({ edit = true }) { Icon(Icons.Filled.Edit, null, tint = Color.White) }
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
        }
        Row(
            Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("মোট বাকি", color = C.sub, fontSize = 13.sp)
                Text(tk(c.due.coerceAtLeast(0.0)), color = if (c.due > 0.001) C.red else C.green, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Button({ pay = true }, shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.green)) {
                Text("৳ টাকা জমা", fontWeight = FontWeight.Bold)
            }
        }
        Text("লেনদেন", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { (it.second as? Sale)?.id ?: (it.second as Payment).id }) { (t, r) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        if (r is Sale) {
                            Text(r.items.joinToString(", ") { it.name }, fontWeight = FontWeight.Bold, maxLines = 2, fontSize = 14.sp)
                            Text("মোট ${tk(r.total)} · দিয়েছে ${tk(r.paid)}", color = C.sub, fontSize = 12.sp)
                        } else if (r is Payment) {
                            Text("টাকা জমা দিয়েছে", fontWeight = FontWeight.Bold, color = C.green, fontSize = 14.sp)
                            if (r.note.isNotBlank()) Text(r.note, color = C.sub, fontSize = 12.sp)
                        }
                        Text(dateBn(t) + " · " + timeBn(t), color = C.sub, fontSize = 12.sp)
                    }
                    if (r is Sale) Text("+" + tk(r.due), color = C.red, fontWeight = FontWeight.Bold)
                    if (r is Payment) {
                        Text("−" + tk(r.amount), color = C.green, fontWeight = FontWeight.Bold)
                        if (Access.isOwner) IconButton({ delPay = r }) { Icon(Icons.Filled.Delete, null, tint = C.sub) }
                    }
                }
            }
            item {
                if (Access.isOwner) TextButton({ askDel = true }) { Text("🗑 কাস্টমার মুছে ফেলুন", color = C.red) }
                Gap(h = 20.dp)
            }
        }
    }

    if (pay) {
        var amt by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pay = false },
            title = { Text("${c.name} টাকা দিল") },
            text = {
                Column {
                    OutlinedTextField(amt, { amt = it }, label = { Text("কত টাকা") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Text("পুরো বাকি: ${tk(c.due)}", color = C.brand, fontSize = 13.sp,
                        modifier = Modifier.clickable { amt = numPlain(c.due) }.padding(vertical = 8.dp))
                    OutlinedTextField(note, { note = it }, label = { Text("নোট (ঐচ্ছিক)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button({
                    val a = parseNum(amt) ?: 0.0
                    if (a > 0) Store.addPayment(c, a, note.trim())
                    pay = false
                }, enabled = (parseNum(amt) ?: 0.0) > 0) { Text("জমা করুন") }
            },
            dismissButton = { TextButton({ pay = false }) { Text("বাতিল") } }
        )
    }
    if (edit) CustomerDialog(c, { edit = false }) { n, ph -> Store.updateCustomer(c, n, ph); edit = false }
    if (askDel) AlertDialog(
        onDismissRequest = { askDel = false },
        title = { Text("কাস্টমার মুছবেন?") },
        text = { Text(if (c.due > 0.001) "এখনো ${tk(c.due)} বাকি আছে! মুছলে এই বাকির হিসাব আর দেখা যাবে না।" else "${c.name} তালিকা থেকে মুছে যাবে।") },
        confirmButton = { Button({ Store.deleteCustomer(c); askDel = false; Nav.close() }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text("মুছুন") } },
        dismissButton = { TextButton({ askDel = false }) { Text("না") } }
    )
    delPay?.let { p ->
        AlertDialog(
            onDismissRequest = { delPay = null },
            title = { Text("জমা মুছবেন?") },
            text = { Text("${tk(p.amount)} জমাটা মুছলে বাকি আবার ${tk(p.amount)} বেড়ে যাবে।") },
            confirmButton = { Button({ Store.deletePayment(p); delPay = null }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text("মুছুন") } },
            dismissButton = { TextButton({ delPay = null }) { Text("না") } }
        )
    }
}

fun numPlain(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v)
