package com.mobiletips.dokankhata.ui

import androidx.compose.foundation.layout.fillMaxSize

import androidx.compose.foundation.layout.aspectRatio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

object C {
    val brand = Color(0xFF0D9488)
    val brandDark = Color(0xFF115E59)
    val brandSoft = Color(0xFFCCFBF1)
    val bg = Color(0xFFF1F5F9)
    val card = Color.White
    val text = Color(0xFF0F172A)
    val sub = Color(0xFF64748B)
    val line = Color(0xFFE2E8F0)
    val red = Color(0xFFDC2626)
    val redSoft = Color(0xFFFEE2E2)
    val green = Color(0xFF047857)
    val amber = Color(0xFFF59E0B)
    val amberSoft = Color(0xFFFEF3C7)
    val head = Brush.linearGradient(listOf(Color(0xFF0D9488), Color(0xFF059669)))
}

private const val BN = "০১২৩৪৫৬৭৮৯"

/** Turns English digits into Bangla digits. */
fun bn(s: String): String = if (Lang.isEn) s else buildString { s.forEach { append(if (it in '0'..'9') BN[it - '0'] else it) } }

/** 1234.5 -> "১,২৩৪.৫" */
fun num(v: Double): String {
    val r = (v * 100).roundToLong() / 100.0
    val whole = r.toLong()
    val frac = abs(r - whole)
    val w = String.format(Locale.US, "%,d", whole)
    val f = if (frac < 0.005) "" else String.format(Locale.US, "%.2f", frac).substring(1).trimEnd('0').trimEnd('.')
    return bn(w + f)
}

fun tk(v: Double) = "৳" + num(v)

/** Reads a number typed with English or Bangla digits. */
fun parseNum(s: String): Double? {
    val e = s.trim().map { c -> val i = BN.indexOf(c); if (i >= 0) ('0' + i) else c }.joinToString("").replace(",", "")
    return e.toDoubleOrNull()
}

private val enMonths = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
private val enDays = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
private val enShort = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
private val bnMonths = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
private val bnDays = listOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

fun dateBn(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    return bn("${c.get(Calendar.DAY_OF_MONTH)} ") + (if (Lang.isEn) enMonths else bnMonths)[c.get(Calendar.MONTH)] + bn(" ${c.get(Calendar.YEAR)}")
}

private val bnShort = listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি")

fun dayShortBn(t: Long): String = (if (Lang.isEn) enShort else bnShort)[Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.DAY_OF_WEEK) - 1]

fun dayNameBn(t: Long): String = (if (Lang.isEn) enDays else bnDays)[Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.DAY_OF_WEEK) - 1]

fun timeBn(t: Long): String = bn(SimpleDateFormat("h:mm", Locale.US).format(Date(t))) +
    (if (Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.AM_PM) == Calendar.AM) L(" সকাল", " AM") else L(" বিকাল", " PM"))

fun dayStart(t: Long = System.currentTimeMillis()): Long = Calendar.getInstance().apply {
    timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

/** Small photos stored as base64 JPEG. */
object Img {
    private val cache = LruCache<Int, ImageBitmap>(200)

    fun decode(b64: String): ImageBitmap? {
        if (b64.isEmpty()) return null
        val key = b64.hashCode()
        cache.get(key)?.let { return it }
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()?.also { cache.put(key, it) }
        } catch (e: Exception) { null }
    }

    fun encode(bm: Bitmap, max: Int = 320): String {
        val s = max.toFloat() / maxOf(bm.width, bm.height)
        val small = if (s < 1f) Bitmap.createScaledBitmap(bm, (bm.width * s).toInt().coerceAtLeast(1), (bm.height * s).toInt().coerceAtLeast(1), true) else bm
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 72, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}

private val tileColors = listOf(0xFFCCFBF1, 0xFFFEF3C7, 0xFFE0E7FF, 0xFFFCE7F3, 0xFFDCFCE7, 0xFFFFEDD5, 0xFFE0F2FE)

/** Product photo, or the first letter on a soft colour when there is no photo. */
@Composable
fun Thumb(photo: String, name: String, size: Dp, corner: Dp = 14.dp, modifier: Modifier = Modifier) {
    val bmp = remember(photo) { Img.decode(photo) }
    Box(
        modifier.size(size).clip(RoundedCornerShape(corner))
            .background(Color(tileColors[abs(name.hashCode()) % tileColors.size])),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp, name, Modifier.size(size), contentScale = ContentScale.Crop)
        else Text(name.take(1).ifEmpty { "?" }, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.Bold, color = C.brandDark)
    }
}

/** Product photo that fills its box (square), with the first letter when there is no photo. */
@Composable
fun BigPhoto(photo: String, name: String, modifier: Modifier = Modifier) {
    val bmp = remember(photo) { Img.decode(photo) }
    Box(
        modifier.fillMaxWidth().aspectRatio(1f).background(Color(tileColors[abs(name.hashCode()) % tileColors.size])),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) Image(bmp, name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(name.take(1).ifEmpty { "?" }, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = C.brandDark)
    }
}

/** Green header used on every main screen. */
@Composable
fun Header(title: String, sub: String = "", right: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(C.head).statusBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 1)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = right)
    }
}

@Composable
fun Pill(text: String, bg: Color, fg: Color) {
    Text(text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 7.dp, vertical = 2.dp))
}

@Composable
fun Gap(w: Dp = 0.dp, h: Dp = 0.dp) = Spacer(Modifier.width(w).height(h))

/** How a sale item reads: "২ পিস", "১ প্যাকেট", "৫০০ গ্রাম". */
fun qtyText(mode: String, qty: Double): String = when (mode) {
    "pack" -> num(qty) + L(" প্যাকেট", " pack")
    "kg" -> if (qty < 1) num(qty * 1000) + L(" গ্রাম", " g") else num(qty) + L(" কেজি", " kg")
    "custom" -> num(qty) + L("টি", "")
    else -> num(qty) + L(" পিস", " pc")
}
