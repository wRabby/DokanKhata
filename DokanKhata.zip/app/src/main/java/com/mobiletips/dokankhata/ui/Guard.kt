package com.mobiletips.dokankhata.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.mobiletips.dokankhata.data.Auth
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.launch

/**
 * Every edit / delete goes through here: first the shop PIN (if one is set),
 * then "Are you sure? Yes / No". Only "Yes" runs the action.
 */
object Guard {
    class Req(val title: String, val danger: Boolean, val action: () -> Unit)
    val req = mutableStateOf<Req?>(null)

    fun ask(title: String, danger: Boolean = true, action: () -> Unit) { req.value = Req(title, danger, action) }
}

@Composable
fun GuardHost() {
    val r = Guard.req.value ?: return
    var pinOk by remember(r) { mutableStateOf(Store.pinHash.value.isEmpty()) }
    if (!pinOk) {
        PinAsk(r.title, onCancel = { Guard.req.value = null }) { pinOk = true }
        return
    }
    AlertDialog(
        onDismissRequest = { Guard.req.value = null },
        title = { Text(L("নিশ্চিত?", "Are you sure?")) },
        text = { Text(r.title, fontSize = 16.sp) },
        confirmButton = {
            Button({ Guard.req.value = null; r.action() },
                colors = ButtonDefaults.buttonColors(containerColor = if (r.danger) C.red else C.brand)) { Text(L("হ্যাঁ", "Yes"), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton({ Guard.req.value = null }) { Text(L("না", "No")) } }
    )
}

@Composable
private fun PinAsk(title: String, onCancel: () -> Unit, onOk: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(L("🔒 পিন দিন", "🔒 Enter PIN")) },
        text = {
            Column {
                Text(title, fontSize = 14.sp, color = C.sub)
                OutlinedTextField(
                    pin, { v -> pin = v.filter { it.isDigit() }.take(4); wrong = false; if (pin.length == 4 && Store.pinOk(pin)) onOk() },
                    label = { Text(L("৪ সংখ্যার পিন", "4-digit PIN")) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = wrong,
                    modifier = Modifier.padding(top = 8.dp).focusRequester(focus)
                )
                if (wrong) Text(L("ভুল পিন", "Wrong PIN"), color = C.red, fontSize = 13.sp)
            }
        },
        confirmButton = { Button({ if (Store.pinOk(pin)) onOk() else wrong = true }, enabled = pin.length == 4) { Text(L("ঠিক আছে", "OK")) } },
        dismissButton = { TextButton(onCancel) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** Set, change or remove the shop PIN. Forgot it? The owner confirms their Google account instead. */
@Composable
fun PinSetup(activity: Activity, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val hasPin = Store.pinHash.value.isNotEmpty()
    var old by remember { mutableStateOf("") }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var verified by remember { mutableStateOf(!hasPin) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (hasPin) L("🔒 পিন বদলান", "🔒 Change PIN") else L("🔒 পিন সেট করুন", "🔒 Set PIN")) },
        text = {
            Column {
                if (!verified) {
                    OutlinedTextField(old, { v -> old = v.filter { it.isDigit() }.take(4) }, label = { Text(L("এখনকার পিন", "Current PIN")) },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    TextButton({
                        scope.launch {
                            val email = Auth.confirmGoogle(activity)
                            if (email != null && email.equals(FirebaseAuth.getInstance().currentUser?.email, true)) { verified = true; err = null }
                            else err = L("গুগল অ্যাকাউন্ট মেলেনি", "Google account did not match")
                        }
                    }) { Text(L("পিন ভুলে গেছি — গুগল দিয়ে যাচাই", "Forgot PIN — confirm with Google")) }
                } else {
                    Text(L("নতুন ৪ সংখ্যার পিন দিন। এডিট আর মুছার সময় এটা লাগবে।", "Choose a 4-digit PIN. It is needed to edit or delete."), fontSize = 14.sp, color = C.sub)
                    OutlinedTextField(p1, { v -> p1 = v.filter { it.isDigit() }.take(4) }, label = { Text(L("নতুন পিন", "New PIN")) },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    OutlinedTextField(p2, { v -> p2 = v.filter { it.isDigit() }.take(4) }, label = { Text(L("আবার দিন", "Again")) },
                        singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    if (hasPin) TextButton({ Store.setPin(""); Toast.makeText(ctx, L("পিন তুলে দেওয়া হলো", "PIN removed"), Toast.LENGTH_SHORT).show(); onClose() }) {
                        Text(L("পিন তুলে দিন", "Remove PIN"), color = C.red)
                    }
                }
                err?.let { Text(it, color = C.red, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            Button({
                if (!verified) {
                    if (Store.pinOk(old)) { verified = true; err = null } else err = L("ভুল পিন", "Wrong PIN")
                } else if (p1.length != 4) err = L("৪ সংখ্যা দিন", "Use 4 digits")
                else if (p1 != p2) err = L("দুটো পিন মেলেনি", "The PINs do not match")
                else {
                    Store.setPin(p1)
                    Toast.makeText(ctx, L("পিন সেট হয়েছে ✓", "PIN set ✓"), Toast.LENGTH_SHORT).show()
                    onClose()
                }
            }) { Text(if (verified) L("সেভ", "Save") else L("পরের ধাপ", "Next")) }
        },
        dismissButton = { TextButton(onClose) { Text(L("বাতিল", "Cancel")) } }
    )
}
