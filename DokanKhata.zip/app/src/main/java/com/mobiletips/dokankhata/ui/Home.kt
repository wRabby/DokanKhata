package com.mobiletips.dokankhata.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Store

@Composable
fun HomeScreen() {
    val sales by Store.sales
    val customers by Store.customers
    val products by Store.products
    val shop by Store.shopName
    var range by remember { mutableStateOf(0) }   // 0 today, 1 this week (7 days), 2 this month (30 days)
    val now = System.currentTimeMillis()
    val today = dayStart(now)
    val from = when (range) { 0 -> today; 1 -> today - 6 * 86_400_000L; else -> today - 29 * 86_400_000L }
    val inRange = sales.filter { it.time >= from }
    val total = inRange.sumOf { it.total }
    val profit = inRange.sumOf { it.profit }
    val dueAll = customers.sumOf { it.due.coerceAtLeast(0.0) }
    val low = products.filter { it.low }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(shop.ifBlank { "দোকান খাতা" }, dayNameBn(now) + ", " + dateBn(now))
        Row(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("আজ", range == 0) { range = 0 }
            Chip("৭ দিন", range == 1) { range = 1 }
            Chip("৩০ দিন", range == 2) { range = 2 }
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Kpi("বিক্রি", tk(total), C.text, Modifier.weight(1f))
            if (Access.isOwner) Kpi("লাভ", tk(profit), C.green, Modifier.weight(1f))
            else Kpi("পণ্য", bn("${products.size}") + "টি", C.text, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Kpi("বাকি পাওনা", tk(dueAll), C.red, Modifier.weight(1f).clickable { Nav.tab.value = 3 })
            Kpi("বিক্রি হয়েছে", bn("${inRange.size}") + " বার", C.text, Modifier.weight(1f))
        }
        Button(
            { Nav.tab.value = 1 }, shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = C.brand),
            modifier = Modifier.fillMaxWidth().padding(12.dp).height(58.dp)
        ) { Text("📷  নতুন বিক্রি শুরু করুন", fontSize = 18.sp, fontWeight = FontWeight.Bold) }

        // last 7 days
        SectionTitle("গত ৭ দিনের বিক্রি")
        val days = (6 downTo 0).map { d ->
            val s = today - d * 86_400_000L
            s to sales.filter { it.time >= s && it.time < s + 86_400_000L }.sumOf { it.total }
        }
        val max = (days.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(1.0)
        Row(
            Modifier.padding(horizontal = 12.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White)
                .padding(12.dp).height(170.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom
        ) {
            days.forEach { (t, v) ->
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    if (v > 0) Text(short(v), fontSize = 10.sp, color = C.sub, maxLines = 1)
                    Box(
                        Modifier.fillMaxWidth().fillMaxHeight((v / max).toFloat().coerceIn(0.03f, 0.78f))
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp, bottomStart = 3.dp, bottomEnd = 3.dp))
                            .background(Brush.verticalGradient(listOf(Color(0xFF5EEAD4), C.brand)))
                    )
                    Text(dayShortBn(t), fontSize = 11.sp, color = if (t == today) C.brand else C.sub, maxLines = 1)
                }
            }
        }

        // best sellers in the chosen range
        val top = inRange.flatMap { it.items }.groupBy { it.name }
            .map { (n, its) -> Triple(n, its.sumOf { it.total }, its) }
            .sortedByDescending { it.second }.take(5)
        if (top.isNotEmpty()) {
            SectionTitle("সবচেয়ে বেশি বিক্রি")
            top.forEach { (n, v, its) ->
                val p = products.firstOrNull { it.name == n }
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(Color.White).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Thumb(p?.photo ?: "", n, 40.dp, 10.dp)
                    Gap(w = 10.dp)
                    Column(Modifier.weight(1f)) {
                        Text(n, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(its.groupBy { it.mode }.map { (m, l) -> qtyText(m, l.sumOf { it.qty }) }.joinToString(" + "), color = C.sub, fontSize = 12.sp)
                    }
                    Text(tk(v), fontWeight = FontWeight.Bold)
                }
            }
        }

        if (low.isNotEmpty()) {
            SectionTitle("⚠ স্টক কম — কিনতে হবে")
            low.take(8).forEach { p ->
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(C.redSoft).clickable { Nav.open(Page.EditProduct(p)) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Thumb(p.photo, p.name, 36.dp, 10.dp)
                    Gap(w = 10.dp)
                    Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("আছে " + stockText(p), color = C.red, fontSize = 13.sp)
                }
            }
        }
        if (sales.isEmpty() && products.isEmpty()) {
            Text("শুরু করতে 'পণ্য' ট্যাবে গিয়ে আপনার দোকানের পণ্য যোগ করুন। বারকোড থাকলে স্ক্যান করে নিন — তারপর বিক্রির সময় শুধু স্ক্যান!",
                color = C.sub, textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
        }
        Gap(h = 24.dp)
    }
}

@Composable
private fun Kpi(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp)) {
        Text(label, color = C.sub, fontSize = 13.sp)
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp))
}

private fun short(v: Double): String = if (v >= 1000) bn(String.format(java.util.Locale.US, "%.1f", v / 1000).removeSuffix(".0")) + "k" else bn("${v.toLong()}")
