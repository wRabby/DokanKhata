package com.mobiletips.dokankhata.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.mobiletips.dokankhata.AppConfig
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Auth
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Sale
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun MoreScreen(activity: ComponentActivity) {
    val shop by Store.shopName
    val user by Auth.user
    val scope = rememberCoroutineScope()
    var editName by remember { mutableStateOf(false) }
    var askOut by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("আরও", "সেটিংস ও অন্যান্য")
        Column(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp)) {
            Text("দোকানের নাম", color = C.sub, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(shop.ifBlank { "নাম দেওয়া হয়নি" }, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (Access.isOwner) TextButton({ editName = true }) { Text("বদলান") }
            }
            Text(user?.email ?: "", color = C.sub, fontSize = 13.sp)
            Text(if (Access.isOwner) "আপনি: দোকানের মালিক" else "আপনি: কর্মচারী", color = C.brand, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Access.member.value?.let { m -> if (m.expires > 0) Text("মেয়াদ: ${dateBn(m.expires)} পর্যন্ত", color = C.sub, fontSize = 13.sp) }
        }
        MenuRow("🧾", "বিক্রির ইতিহাস", "গত ৬০ দিনের সব বিক্রি, ভুল হলে মুছুন") { Nav.open(Page.History) }
        if (Access.isOwner) MenuRow("🔳", "QR স্টিকার প্রিন্ট", "বারকোড নেই এমন পণ্যের জন্য QR কার্ড") { Nav.open(Page.QrCards) }
        MenuRow("📒", "বাকির খাতা", "কার কাছে কত পাওনা") { Nav.tab.value = 3 }
        MenuRow("🚪", "লগআউট", "এই ফোন থেকে বের হন") { askOut = true }
        Text("দোকান খাতা · সংস্করণ ${bn(AppConfig.VERSION)}", color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(20.dp))
    }
    if (editName) {
        var n by remember { mutableStateOf(shop) }
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text("দোকানের নাম") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true, label = { Text("যেমন: রাসেল স্টোর") }) },
            confirmButton = { Button({ Store.setShopName(n.trim()); editName = false }) { Text("সেভ") } },
            dismissButton = { TextButton({ editName = false }) { Text("বাতিল") } }
        )
    }
    if (askOut) AlertDialog(
        onDismissRequest = { askOut = false },
        title = { Text("লগআউট করবেন?") },
        text = { Text("আপনার হিসাব অনলাইনে নিরাপদ থাকবে। আবার একই গুগল অ্যাকাউন্টে লগইন করলে সব ফিরে পাবেন।") },
        confirmButton = { Button({ askOut = false; scope.launch { Auth.signOut(activity) } }) { Text("লগআউট") } },
        dismissButton = { TextButton({ askOut = false }) { Text("না") } }
    )
}

@Composable
private fun MenuRow(icon: String, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 26.sp)
        Gap(w = 14.dp)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(sub, color = C.sub, fontSize = 12.sp)
        }
        Text("›", fontSize = 24.sp, color = C.sub)
    }
}

/** All sales of the last 60 days, newest first, grouped by day. */
@Composable
fun HistoryScreen() {
    val sales by Store.sales
    var del by remember { mutableStateOf<Sale?>(null) }
    val byDay = sales.groupBy { dayStart(it.time) }.toList().sortedByDescending { it.first }
    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header("বিক্রির ইতিহাস", "গত ৬০ দিন") { IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) } }
        if (sales.isEmpty()) Text("এখনো কোনো বিক্রি নেই।", color = C.sub, modifier = Modifier.padding(20.dp))
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            byDay.forEach { (day, list) ->
                item(key = "d$day") {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 6.dp)) {
                        Text(dayNameBn(day) + ", " + dateBn(day), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(tk(list.sumOf { it.total }), fontWeight = FontWeight.Bold, color = C.green)
                    }
                }
                items(list, key = { it.id }) { s ->
                    Row(
                        Modifier.padding(vertical = 3.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(s.items.joinToString(", ") { it.name + " " + qtyText(it.mode, it.qty) }, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(timeBn(s.time) + if (s.byName.isNotBlank()) " · ${s.byName}" else "", color = C.sub, fontSize = 12.sp)
                                if (s.due > 0.001) Pill("বাকি ${tk(s.due)} · ${s.customerName}", C.redSoft, C.red)
                            }
                        }
                        Text(tk(s.total), fontWeight = FontWeight.Bold)
                        if (Access.isOwner) IconButton({ del = s }) { Icon(Icons.Filled.Delete, null, tint = C.sub) }
                    }
                }
            }
            item { Gap(h = 30.dp) }
        }
    }
    del?.let { s ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("বিক্রি মুছবেন?") },
            text = { Text("${tk(s.total)} এর বিক্রিটা মুছে যাবে। পণ্যের স্টক আবার আগের মতো বাড়বে" + (if (s.due > 0) ", আর ${s.customerName}-এর বাকি থেকে ${tk(s.due)} কমবে।" else "।")) },
            confirmButton = { Button({ Store.deleteSale(s); del = null }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text("মুছুন") } },
            dismissButton = { TextButton({ del = null }) { Text("না") } }
        )
    }
}

/** Pick products and make a printable sheet of QR stickers (PDF). */
@Composable
fun QrScreen() {
    val ctx = LocalContext.current
    val products by Store.products
    val shop by Store.shopName
    val chosen = remember { mutableStateListOf<String>().apply { addAll(Store.products.value.filter { it.barcode.isBlank() }.map { it.id }) } }
    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header("QR স্টিকার", bn("${chosen.size}") + "টি পণ্য বাছাই করা") { IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) } }
        Text("যে পণ্যের গায়ে বারকোড নেই, সেগুলোর QR প্রিন্ট করে কাউন্টারে বা তাকে লাগিয়ে রাখুন। বিক্রির সময় QR-এ ক্যামেরা ধরলেই পণ্য যোগ হবে।",
            color = C.sub, fontSize = 13.sp, modifier = Modifier.padding(14.dp))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("বারকোড ছাড়া সব", false) { chosen.clear(); chosen.addAll(products.filter { it.barcode.isBlank() }.map { it.id }) }
            Chip("সব পণ্য", false) { chosen.clear(); chosen.addAll(products.map { it.id }) }
            Chip("কোনোটাই না", false) { chosen.clear() }
        }
        LazyColumn(Modifier.weight(1f).padding(12.dp)) {
            items(products.sortedBy { it.name }, key = { it.id }) { p ->
                val on = p.id in chosen
                Row(
                    Modifier.padding(vertical = 3.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White)
                        .clickable { if (on) chosen.remove(p.id) else chosen.add(p.id) }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(on, { if (it) chosen.add(p.id) else chosen.remove(p.id) })
                    Thumb(p.photo, p.name, 38.dp, 10.dp)
                    Gap(w = 10.dp)
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text(if (p.barcode.isBlank()) "বারকোড নেই" else "বারকোড আছে", color = C.sub, fontSize = 12.sp)
                    }
                    val qr = remember(p.id) { qrBitmap(p.qrCode, 120).asImageBitmap() }
                    Image(qr, null, Modifier.size(44.dp))
                }
            }
        }
        Button(
            {
                val list = products.filter { it.id in chosen }.sortedBy { it.name }
                if (list.isEmpty()) Toast.makeText(ctx, "কোনো পণ্য বাছাই করা হয়নি", Toast.LENGTH_SHORT).show()
                else sharePdf(ctx, makeQrPdf(ctx, list, shop))
            },
            shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = C.brand),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(54.dp)
        ) { Text("🖨 PDF বানিয়ে প্রিন্ট / শেয়ার", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }
}

fun qrBitmap(text: String, size: Int): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.MARGIN to 1))
    val px = IntArray(size * size)
    for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}

/** A4 pages, 3 × 4 stickers each: QR, name and price. */
private fun makeQrPdf(ctx: Context, list: List<Product>, shop: String): File {
    val doc = PdfDocument()
    val pw = 595; val ph = 842
    val cols = 3; val rows = 4
    val margin = 28f; val top = 70f
    val cw = (pw - 2 * margin) / cols
    val ch = (ph - top - margin) / rows
    val border = Paint().apply { style = Paint.Style.STROKE; color = 0xFFCBD5E1.toInt(); strokeWidth = 1f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(5f, 4f), 0f) }
    val title = Paint().apply { isAntiAlias = true; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; color = 0xFF0F172A.toInt() }
    val nameP = Paint().apply { isAntiAlias = true; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; color = 0xFF0F172A.toInt(); textAlign = Paint.Align.CENTER }
    val priceP = Paint().apply { isAntiAlias = true; textSize = 13f; color = 0xFF047857.toInt(); textAlign = Paint.Align.CENTER }
    val per = cols * rows
    list.chunked(per).forEachIndexed { pi, chunk ->
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pi + 1).create())
        val c = page.canvas
        c.drawText((shop.ifBlank { "দোকান খাতা" }) + " — QR স্টিকার (কেটে লাগান)", margin, 44f, title)
        chunk.forEachIndexed { i, p ->
            val x = margin + (i % cols) * cw
            val y = top + (i / cols) * ch
            c.drawRoundRect(RectF(x + 4, y + 4, x + cw - 4, y + ch - 4), 10f, 10f, border)
            val q = 118f
            val qr = qrBitmap(p.qrCode, 236)
            c.drawBitmap(qr, null, RectF(x + (cw - q) / 2, y + 16, x + (cw + q) / 2, y + 16 + q), null)
            val name = if (nameP.measureText(p.name) > cw - 16) p.name.take(16) + "…" else p.name
            c.drawText(name, x + cw / 2, y + 16 + q + 22, nameP)
            val price = if (p.isKg) "${tk(p.sell)}/কেজি" else tk(p.sell)
            c.drawText(price, x + cw / 2, y + 16 + q + 40, priceP)
        }
        doc.finishPage(page)
    }
    val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
    val f = File(dir, "qr-stickers.pdf")
    f.outputStream().use { doc.writeTo(it) }
    doc.close()
    return f
}

private fun sharePdf(ctx: Context, f: File) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "QR স্টিকার প্রিন্ট / শেয়ার"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "শেয়ার করা গেল না", Toast.LENGTH_SHORT).show()
    }
}
