package com.mobiletips.dokankhata.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.File

/** Opens the camera / gallery and gives back the photo turned the right way up. */
class PhotoTaker(val camera: () -> Unit, val gallery: () -> Unit)

@Composable
fun rememberPhotoTaker(onPhoto: (Bitmap) -> Unit): PhotoTaker {
    val ctx = LocalContext.current
    val file = remember { File(File(ctx.cacheDir, "photos").apply { mkdirs() }, "cam.jpg") }
    val uri = remember { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) loadUpright(ctx, uri)?.let(onPhoto)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) try { cam.launch(uri) } catch (e: Exception) { }
    }
    val gal = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u: Uri? ->
        if (u != null) loadUpright(ctx, u)?.let(onPhoto)
    }
    return remember {
        PhotoTaker(
            camera = {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    try { cam.launch(uri) } catch (e: Exception) { }
                } else ask.launch(Manifest.permission.CAMERA)
            },
            gallery = { gal.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        )
    }
}

/** Reads a photo at a sensible size and turns it the way the camera held it (EXIF). */
fun loadUpright(ctx: Context, uri: Uri, max: Int = 900): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= max) sample *= 2
    val bm = ctx.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    }
    val rot = ctx.contentResolver.openInputStream(uri)?.use {
        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
    } ?: 0f
    if (bm != null && rot != 0f) Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true) else bm
} catch (e: Exception) { null }

/** A photo filling the screen; tap anywhere to close. */
@Composable
fun PhotoViewer(photo: String, name: String, onClose: () -> Unit) {
    val bmp = remember(photo) { Img.decode(photo) }
    Dialog(onClose, DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)).clickable(onClick = onClose),
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) Image(bmp, name, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit)
            Text(name, color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopCenter).padding(24.dp))
            Text(L("বন্ধ করতে চাপ দিন", "Tap to close"), color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp))
        }
    }
}
