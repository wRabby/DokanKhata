package com.mobiletips.dokankhata.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityManager
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

/** App language: "bn" or "en". Every visible text goes through L(bangla, english). */
object Lang {
    val code = mutableStateOf("bn")
    val isEn get() = code.value == "en"

    fun init(ctx: Context) {
        code.value = ctx.getSharedPreferences("dk", Context.MODE_PRIVATE).getString("lang", "bn") ?: "bn"
    }

    fun set(ctx: Context, c: String) {
        code.value = c
        ctx.getSharedPreferences("dk", Context.MODE_PRIVATE).edit().putString("lang", c).apply()
    }
}

/** Picks the Bangla or English text by the chosen language. */
fun L(bn: String, en: String): String = if (Lang.code.value == "en") en else bn

/**
 * The app's own voice: says what was scanned, sold, put on baki or paid back.
 * Can be switched off in "More". Stays quiet while TalkBack is on, so the two never talk together.
 */
object Voice {
    val on = mutableStateOf(true)
    private var tts: TextToSpeech? = null
    private var ready = false
    private var appCtx: Context? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        on.value = ctx.getSharedPreferences("dk", Context.MODE_PRIVATE).getBoolean("voice", true)
        try {
            tts = TextToSpeech(ctx.applicationContext) { st ->
                ready = st == TextToSpeech.SUCCESS
                if (ready) { tts?.setSpeechRate(0.95f); tts?.setPitch(1.08f) }
            }
        } catch (e: Exception) { ready = false }
    }

    fun set(ctx: Context, v: Boolean) {
        on.value = v
        ctx.getSharedPreferences("dk", Context.MODE_PRIVATE).edit().putBoolean("voice", v).apply()
        if (v) say("ভয়েস চালু হলো", "Voice is on")
    }

    private fun talkBackOn(): Boolean = try {
        (appCtx?.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager)?.isTouchExplorationEnabled == true
    } catch (e: Exception) { false }

    /** Speaks in the app's language. Numbers are fine as plain digits; the voice reads them. */
    fun say(bn: String, en: String) {
        if (!on.value || !ready || talkBackOn()) return
        val t = tts ?: return
        try {
            if (Lang.isEn) {
                t.language = Locale.US
                t.speak(en, TextToSpeech.QUEUE_FLUSH, null, "dk")
            } else {
                var r = t.setLanguage(Locale("bn", "BD"))
                if (r < TextToSpeech.LANG_AVAILABLE) r = t.setLanguage(Locale("bn", "IN"))
                if (r < TextToSpeech.LANG_AVAILABLE) { t.language = Locale.US; t.speak(en, TextToSpeech.QUEUE_FLUSH, null, "dk"); return }
                pickFemale(t)
                t.speak(bn, TextToSpeech.QUEUE_FLUSH, null, "dk")
            }
        } catch (e: Exception) { }
    }

    private var picked = false
    private fun pickFemale(t: TextToSpeech) {
        if (picked) return
        picked = true
        try {
            val all = t.voices?.filter { it.locale.language == "bn" || it.locale.language == "ben" } ?: return
            fun score(v: android.speech.tts.Voice): Int {
                val n = v.name.lowercase()
                var s = 0
                if ("female" in n || "bnf" in n || "-ban-" in n || n.endsWith("-f")) s += 50
                if (("male" in n && "female" !in n) || "bnm" in n || n.endsWith("-m")) s -= 50
                if (v.locale.country.equals("BD", true)) s += 10
                if (!v.isNetworkConnectionRequired) s += 5
                return s
            }
            all.maxByOrNull { score(it) }?.let { t.voice = it }
        } catch (e: Exception) { }
    }
}

/** Plain-digit money for the voice: 90.0 -> "90", 12.5 -> "12.5" */
fun sayNum(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
