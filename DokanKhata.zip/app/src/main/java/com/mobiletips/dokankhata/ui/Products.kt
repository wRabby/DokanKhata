package com.mobiletips.dokankhata.ui

import android.graphics.Bitmap
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store

@Composable
fun ProductsScreen() {
    val products by Store.products
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var onlyLow by remember { mutableStateOf(false) }
    val myCats by Store.cats
    val cats = remember(products, myCats) { (myCats + products.map { it.cat }.filter { it.isNotBlank() }.sorted()).distinct() }
    var manageCats by remember { mutableStateOf(false) }
    val lowCount = products.count { it.low }
    val shown = products.filter {
        (cat.isEmpty() || it.cat == cat) && (!onlyLow || it.low) &&
            (query.isBlank() || it.name.contains(query.trim(), true))
    }.sortedBy { it.name }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header(L("আমার পণ্য", "My products"), bn("${products.size}") + L("টি পণ্য", " products") + if (lowCount > 0) " · " + bn("$lowCount") + L("টির স্টক কম", " low on stock") else "") {
                if (Access.isOwner) Text(
                    L("🗂 ক্যাটাগরি", "🗂 Categories"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.22f))
                        .clickable { manageCats = true }.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
            OutlinedTextField(
                query, { query = it }, placeholder = { Text(L("পণ্য খুঁজুন…", "Search products…")) },
                leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
                trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, L("মুছুন", "Clear")) } },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(L("সব", "All"), cat.isEmpty() && !onlyLow) { cat = ""; onlyLow = false }
                if (lowCount > 0) Chip(L("⚠ স্টক কম", "⚠ Low stock") + " (${bn("$lowCount")})", onlyLow, C.red) { onlyLow = !onlyLow }
                cats.forEach { c -> Chip(c, cat == c) { cat = if (cat == c) "" else c } }
            }
            Gap(h = 8.dp)
            if (products.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📦", fontSize = 50.sp)
                    Text(L("এখনো কোনো পণ্য নেই", "No products yet"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(L("নিচের বাটনে চাপ দিয়ে ছবি তুলে প্রথম পণ্য যোগ করুন।", "Add your first product with a photo using the button below."), color = C.sub)
                }
            }
            LazyVerticalGrid(
                GridCells.Fixed(3), Modifier.weight(1f).padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { p -> ProductCard(p) { Nav.open(Page.EditProduct(p)) } }
                item { Gap(h = 80.dp) }
            }
        }
        if (Access.can("products")) ExtendedFloatingActionButton(
            onClick = { Nav.open(Page.EditProduct(null)) },
            containerColor = C.brand, contentColor = Color.White,
            icon = { Icon(Icons.Filled.Add, null) }, text = { Text(L("নতুন পণ্য", "New product"), fontWeight = FontWeight.Bold) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
    if (manageCats) CategoryDialog { manageCats = false }
}

/** The owner makes his own categories: add, rename, delete, move up. */
@Composable
fun CategoryDialog(onClose: () -> Unit) {
    val cats by Store.cats
    val products by Store.products
    var newName by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameTo by remember { mutableStateOf("") }
    // categories written on products before (not yet in the list) are taken in once
    LaunchedEffect(Unit) {
        val extra = products.map { it.cat }.filter { it.isNotBlank() && it !in cats }.distinct()
        if (extra.isNotEmpty()) Store.setCats(cats + extra)
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(L("ক্যাটাগরি", "Categories")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newName, { newName = it }, label = { Text(L("নতুন ক্যাটাগরি (যেমন: সিগারেট)", "New category (e.g. Food)")) },
                        singleLine = true, modifier = Modifier.weight(1f))
                    Gap(w = 6.dp)
                    Button({
                        val n = newName.trim()
                        if (n.isNotEmpty() && n !in cats) Store.setCats(cats + n)
                        newName = ""
                    }, enabled = newName.isNotBlank(), shape = RoundedCornerShape(12.dp)) { Text("＋") }
                }
                Gap(h = 8.dp)
                if (cats.isEmpty()) Text(L("এখনো কোনো ক্যাটাগরি নেই।", "No categories yet."), color = C.sub)
                cats.forEachIndexed { i, c ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c, fontWeight = FontWeight.Bold)
                            Text(bn("${products.count { it.cat == c }}") + L("টি পণ্য", " products"), color = C.sub, fontSize = 12.sp)
                        }
                        if (i > 0) TextButton({ Store.setCats(cats.toMutableList().apply { add(i - 1, removeAt(i)) }) }) { Text("↑") }
                        IconButton({ renaming = c; renameTo = c }) { Icon(Icons.Filled.Edit, L("নাম বদলান", "Rename"), tint = C.sub) }
                        IconButton({
                            Guard.ask(L("“$c” ক্যাটাগরি মুছবেন? পণ্যগুলো থাকবে, শুধু ক্যাটাগরি ছাড়া।", "Delete “$c”? Its products stay, without a category.")) { Store.renameCat(c, "") }
                        }) { Icon(Icons.Filled.Delete, L("মুছুন", "Delete"), tint = C.red) }
                    }
                }
            }
        },
        confirmButton = { Button(onClose) { Text(L("ঠিক আছে", "Done")) } }
    )
    renaming?.let { old ->
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(L("নাম বদলান", "Rename")) },
            text = { OutlinedTextField(renameTo, { renameTo = it }, singleLine = true) },
            confirmButton = { Button({ val n = renameTo.trim(); if (n.isNotEmpty() && n != old) Store.renameCat(old, n); renaming = null }) { Text(L("সেভ", "Save")) } },
            dismissButton = { TextButton({ renaming = null }) { Text(L("বাতিল", "Cancel")) } }
        )
    }
}

@Composable
fun Chip(t: String, on: Boolean, color: Color = C.brand, onClick: () -> Unit) {
    Text(
        t, fontSize = 13.sp, color = if (on) Color.White else C.text,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) color else Color.White)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
private fun ProductCard(p: Product, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White)
            .border(if (p.low) 2.dp else 1.dp, if (p.low) C.red else C.line, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Box {
            BigPhoto(p.photo, p.name)
            Text(
                tk(p.sell) + if (p.isKg) "/" + L("কেজি", "kg") else "",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1,
                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).clip(RoundedCornerShape(10.dp))
                    .background(C.brandDark.copy(alpha = 0.88f)).padding(horizontal = 7.dp, vertical = 3.dp)
            )
        }
        Column(Modifier.padding(horizontal = 6.dp, vertical = 5.dp)) {
            Text(p.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(L("স্টক: ", "Stock: ") + stockText(p), fontSize = 11.sp, color = if (p.low) C.red else C.sub, maxLines = 1)
        }
    }
}

fun stockText(p: Product): String = when {
    p.isKg -> num(p.stock) + L(" কেজি", " kg")
    p.hasPack && p.stock >= p.packSize -> num(p.stock) + L(" পিস (", " pc (") + bn("${(p.stock / p.packSize).toInt()}") + L(" প্যাকেট)", " pack)")
    else -> num(p.stock) + L(" পিস", " pc")
}

/** Add or change a product. */
@Composable
fun ProductEditor(start: Product?, @Suppress("UNUSED_PARAMETER") scannedCode: String = "") {
    val ctx = LocalContext.current
    val owner = Access.can("products")
    val p0 = start ?: Product()
    var photo by remember { mutableStateOf(p0.photo) }
    var name by remember { mutableStateOf(p0.name) }
    var cat by remember { mutableStateOf(p0.cat) }
    var note by remember { mutableStateOf(p0.note) }
    var isKg by remember { mutableStateOf(p0.isKg) }
    var sell by remember { mutableStateOf(numIn(p0.sell)) }
    var buy by remember { mutableStateOf(numIn(p0.buy)) }
    var pack by remember { mutableStateOf(p0.packSize > 0) }
    var packSize by remember { mutableStateOf(if (p0.packSize > 0) p0.packSize.toString() else "") }
    var packSell by remember { mutableStateOf(numIn(p0.packSell)) }
    var packBuy by remember { mutableStateOf(numIn(p0.packBuy)) }
    var stock by remember { mutableStateOf(numIn(p0.stock)) }
    var lowAt by remember { mutableStateOf(numIn(p0.lowAt)) }
    var askDelete by remember { mutableStateOf(false) }
    var addStock by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val cats = (Store.cats.value + Store.products.value.map { it.cat }.filter { it.isNotBlank() }.sorted()).distinct()
    var newCat by remember { mutableStateOf(false) }

    val taker = rememberPhotoTaker { bm -> photo = Img.encode(bm, 400) }
    var viewPhoto by remember { mutableStateOf(false) }

    val sellN = parseNum(sell) ?: 0.0
    val packN = packSize.toIntOrNull() ?: 0
    val ok = name.isNotBlank() && sellN > 0 && (!pack || isKg || packN > 1)

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(if (start == null) L("নতুন পণ্য", "New product") else L("পণ্য বদলান", "Edit product")) {
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, L("পেছনে", "Back"), tint = Color.White) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(16.dp)) {
            // photo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable { if (photo.isNotEmpty()) viewPhoto = true }) { Thumb(photo, name.ifBlank { "+" }, 96.dp, 22.dp) }
                Gap(w = 14.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(taker.camera, shape = RoundedCornerShape(12.dp)) { Text(L("📷 ছবি তুলুন", "📷 Take photo")) }
                    OutlinedButton(taker.gallery, shape = RoundedCornerShape(12.dp)) { Text(L("🖼 গ্যালারি থেকে", "🖼 From gallery")) }
                }
            }
            Gap(h = 14.dp)
            Field(name, { name = it }, L("পণ্যের নাম *", "Product name *"))
            Text(L("ক্যাটাগরি", "Category"), fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(L("কোনোটা না", "None"), cat.isBlank()) { cat = "" }
                cats.forEach { c -> Chip(c, cat == c) { cat = c } }
                if (Access.isOwner) Chip(L("＋ নতুন", "＋ New"), false, C.brandDark) { newCat = true }
            }
            OutlinedTextField(
                note, { note = it }, label = { Text(L("নোট (বিক্রির সময় দেখাবে)", "Note (shown when selling)"), fontSize = 13.sp) },
                placeholder = { Text(L("যেমন: মূল দাম ১২০, ১৪০ এর কমে না", "e.g. cost 120, not less than 140"), fontSize = 13.sp) },
                minLines = 2, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            )
            // unit
            Text(L("কীভাবে বিক্রি হয়?", "How is it sold?"), fontWeight = FontWeight.Bold)
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(L("পিস / টি হিসেবে", "By piece"), !isKg) { isKg = false }
                Chip(L("কেজি / ওজনে", "By weight (kg)"), isKg) { isKg = true; pack = false }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(sell, { sell = it }, if (isKg) L("বেচা দাম / কেজি *", "Sell price / kg *") else L("বেচা দাম / পিস *", "Sell price / piece *"), Modifier.weight(1f), true)
                Field(buy, { buy = it }, if (isKg) L("কেনা দাম / কেজি", "Buy price / kg") else L("কেনা দাম / পিস", "Buy price / piece"), Modifier.weight(1f), true)
            }
            if (!isKg) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(L("প্যাকেটেও বিক্রি হয়?", "Also sold by the pack?"), fontWeight = FontWeight.Bold)
                        Text(L("যেমন সিগারেট: ১ প্যাকেট = ২০ পিস", "e.g. cigarettes: 1 pack = 20 pieces"), color = C.sub, fontSize = 12.sp)
                    }
                    Switch(pack, { pack = it })
                }
                if (pack) {
                    Field(packSize, { packSize = it }, L("এক প্যাকেটে কয় পিস *", "Pieces in one pack *"), number = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(packSell, { packSell = it }, L("বেচা দাম / প্যাকেট", "Sell price / pack"), Modifier.weight(1f), true)
                        Field(packBuy, { packBuy = it }, L("কেনা দাম / প্যাকেট", "Buy price / pack"), Modifier.weight(1f), true)
                    }
                    if (packN > 1 && sellN > 0 && parseNum(packSell) == null)
                        Text(L("প্যাকেটের দাম না দিলে ধরা হবে ${tk(sellN * packN)}", "If empty, the pack price is ${tk(sellN * packN)}"), color = C.sub, fontSize = 12.sp)
                }
            }
            Gap(h = 6.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(stock, { stock = it }, if (isKg) L("স্টকে আছে (কেজি)", "In stock (kg)") else L("স্টকে আছে (পিস)", "In stock (pieces)"), Modifier.weight(1f), true)
                Field(lowAt, { lowAt = it }, L("কত হলে সতর্ক করবে", "Warn when stock is"), Modifier.weight(1f), true)
            }
            if (!owner) Text(L("শুধু দোকানের মালিক পণ্য বদলাতে পারবেন।", "Only the shop owner can change products."), color = C.red, fontSize = 13.sp)
            if (start != null && owner) {
                OutlinedButton({ addStock = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text(L("＋ নতুন মাল এসেছে (স্টক বাড়ান)", "＋ New stock arrived")) }
                Gap(h = 8.dp)
                TextButton({ Guard.ask(L("“${start.name}” পণ্যটি মুছে ফেলবেন? আগের বিক্রির হিসাব থাকবে।", "Delete “${start.name}”? Past sales stay.")) { Store.deleteProduct(start); Nav.close() } }) { Text(L("🗑 পণ্যটি মুছে ফেলুন", "🗑 Delete this product"), color = C.red) }
            }
            Gap(h = 20.dp)
        }
        if (start != null && start.created > 0) Text(
            L("যোগ হয়েছে: ", "Added: ") + dateBn(start.created) + ", " + timeBn(start.created) +
                if (start.updated > 0) L(" · শেষ বদল: ", " · last change: ") + dateBn(start.updated) + ", " + timeBn(start.updated) else "",
            color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)
        )
        Button(
            onClick = {
                val save = {
                busy = true
                val ps = if (pack && !isKg) packN else 0
                val pSell = parseNum(packSell) ?: (sellN * ps)
                val pBuy = parseNum(packBuy) ?: ((parseNum(buy) ?: 0.0) * ps)
                val buyN = parseNum(buy) ?: if (ps > 0 && pBuy > 0) pBuy / ps else 0.0
                Store.saveProduct(
                    p0.copy(
                        name = name.trim(), cat = cat.trim(), note = note.trim(), unit = if (isKg) "kg" else "pcs",
                        packSize = ps, sell = sellN, buy = buyN, packSell = if (ps > 0) pSell else 0.0, packBuy = if (ps > 0) pBuy else 0.0,
                        stock = parseNum(stock) ?: 0.0, lowAt = parseNum(lowAt) ?: 0.0, photo = photo,
                    )
                ) { saved -> busy = false; if (saved) Nav.close() }
                }
                if (start == null) save() else Guard.ask(L("“${name.trim()}” পণ্যের তথ্য বদলাবেন?", "Save changes to “${name.trim()}”?"), danger = false) { save() }
            },
            enabled = ok && !busy && owner,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = C.brand),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(54.dp)
        ) { Text(if (busy) L("সেভ হচ্ছে…", "Saving…") else L("✓ সেভ করুন", "✓ Save"), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }

    if (viewPhoto) PhotoViewer(photo, name) { viewPhoto = false }
    if (newCat) {
        var n by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newCat = false },
            title = { Text(L("নতুন ক্যাটাগরি", "New category")) },
            text = { OutlinedTextField(n, { n = it }, label = { Text(L("নাম (যেমন: সিগারেট)", "Name (e.g. Food)")) }, singleLine = true) },
            confirmButton = { Button({
                val t = n.trim()
                if (t.isNotEmpty()) { if (t !in Store.cats.value) Store.setCats(Store.cats.value + t); cat = t }
                newCat = false
            }, enabled = n.isNotBlank()) { Text(L("যোগ করুন", "Add")) } },
            dismissButton = { TextButton({ newCat = false }) { Text(L("বাতিল", "Cancel")) } }
        )
    }
    if (askDelete && start != null) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text(L("মুছে ফেলবেন?", "Delete?")) },
            text = { Text(L("“${start.name}” পণ্যের তালিকা থেকে মুছে যাবে। আগের বিক্রির হিসাব থাকবে।", "“${start.name}” will be removed from the list. Past sales stay.")) },
            confirmButton = { Button({ Store.deleteProduct(start); askDelete = false; Nav.close() }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text(L("মুছুন", "Delete")) } },
            dismissButton = { TextButton({ askDelete = false }) { Text(L("না", "No")) } }
        )
    }
    if (addStock && start != null) {
        var amt by remember { mutableStateOf("") }
        var asPack by remember { mutableStateOf(start.hasPack) }
        AlertDialog(
            onDismissRequest = { addStock = false },
            title = { Text(L("নতুন মাল যোগ", "Add new stock")) },
            text = {
                Column {
                    if (start.hasPack) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                        Chip(L("প্যাকেট", "Pack"), asPack) { asPack = true }
                        Chip(L("পিস", "Piece"), !asPack) { asPack = false }
                    }
                    OutlinedTextField(amt, { amt = it }, label = { Text(if (start.isKg) L("কত কেজি", "How many kg") else if (asPack) L("কয় প্যাকেট", "How many packs") else L("কয় পিস", "How many pieces")) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            },
            confirmButton = {
                Button({
                    val a = parseNum(amt) ?: 0.0
                    if (a > 0) {
                        val add = if (asPack && start.hasPack) a * start.packSize else a
                        Store.addStock(start, add)
                        stock = numIn((parseNum(stock) ?: 0.0) + add)
                    }
                    addStock = false
                }) { Text(L("যোগ করুন", "Add")) }
            },
            dismissButton = { TextButton({ addStock = false }) { Text(L("বাতিল", "Cancel")) } }
        )
    }
}

private fun numIn(v: Double): String = if (v == 0.0) "" else if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

@Composable
private fun Field(v: String, on: (String) -> Unit, label: String, modifier: Modifier = Modifier.fillMaxWidth(), number: Boolean = false) {
    OutlinedTextField(
        v, on, label = { Text(label, fontSize = 13.sp) }, singleLine = true,
        keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        modifier = modifier.padding(bottom = 8.dp)
    )
}
