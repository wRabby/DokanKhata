package com.mobiletips.dokankhata.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store

@Composable
fun ProductsScreen() {
    val products by Store.products
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var onlyLow by remember { mutableStateOf(false) }
    val cats = remember(products) { products.map { it.cat }.filter { it.isNotBlank() }.distinct().sorted() }
    val lowCount = products.count { it.low }
    val shown = products.filter {
        (cat.isEmpty() || it.cat == cat) && (!onlyLow || it.low) &&
            (query.isBlank() || it.name.contains(query.trim(), true) || it.barcode == query.trim())
    }.sortedBy { it.name }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Header("আমার পণ্য", bn("${products.size}") + "টি পণ্য" + if (lowCount > 0) " · " + bn("$lowCount") + "টির স্টক কম" else "")
            OutlinedTextField(
                query, { query = it }, placeholder = { Text("পণ্য খুঁজুন…") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, null) } },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("সব", cat.isEmpty() && !onlyLow) { cat = ""; onlyLow = false }
                if (lowCount > 0) Chip("⚠ স্টক কম (${bn("$lowCount")})", onlyLow, C.red) { onlyLow = !onlyLow }
                cats.forEach { c -> Chip(c, cat == c) { cat = if (cat == c) "" else c } }
            }
            Gap(h = 8.dp)
            if (products.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📦", fontSize = 50.sp)
                    Text("এখনো কোনো পণ্য নেই", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("নিচের বাটনে চাপ দিয়ে প্রথম পণ্য যোগ করুন। বারকোড থাকলে স্ক্যান করে নিন।", color = C.sub)
                }
            }
            LazyVerticalGrid(
                GridCells.Fixed(3), Modifier.weight(1f).padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { p -> ProductCard(p) { Nav.open(Page.EditProduct(p)) } }
                item { Gap(h = 80.dp) }
            }
        }
        if (Access.isOwner) ExtendedFloatingActionButton(
            onClick = { Nav.open(Page.EditProduct(null)) },
            containerColor = C.brand, contentColor = Color.White,
            icon = { Icon(Icons.Filled.Add, null) }, text = { Text("নতুন পণ্য", fontWeight = FontWeight.Bold) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        )
    }
}

@Composable
fun Chip(t: String, on: Boolean, color: Color = C.brand, onClick: () -> Unit) {
    Text(
        t, fontSize = 13.sp, color = if (on) Color.White else C.text,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) color else Color.White)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)
    )
}

@Composable
private fun ProductCard(p: Product, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)
            .then(if (p.low) Modifier.border(2.dp, C.red, RoundedCornerShape(16.dp)) else Modifier)
            .clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Thumb(p.photo, p.name, 64.dp)
        Gap(h = 5.dp)
        Text(p.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(if (p.isKg) "${tk(p.sell)}/কেজি" else if (p.hasPack) "${tk(p.sell)}/পিস" else tk(p.sell),
            fontSize = 13.sp, fontWeight = FontWeight.Bold, color = C.green, maxLines = 1)
        Text("স্টক: " + stockText(p), fontSize = 11.sp, color = if (p.low) C.red else C.sub, maxLines = 1)
    }
}

fun stockText(p: Product): String = when {
    p.isKg -> num(p.stock) + " কেজি"
    p.hasPack && p.stock >= p.packSize -> num(p.stock) + " পিস (" + bn("${(p.stock / p.packSize).toInt()}") + " প্যাকেট)"
    else -> num(p.stock) + " পিস"
}

/** Add or change a product. */
@Composable
fun ProductEditor(start: Product?, scannedCode: String) {
    val ctx = LocalContext.current
    val owner = Access.isOwner
    val p0 = start ?: Product(barcode = scannedCode)
    var photo by remember { mutableStateOf(p0.photo) }
    var name by remember { mutableStateOf(p0.name) }
    var cat by remember { mutableStateOf(p0.cat) }
    var barcode by remember { mutableStateOf(p0.barcode) }
    var isKg by remember { mutableStateOf(p0.isKg) }
    var sell by remember { mutableStateOf(numIn(p0.sell)) }
    var buy by remember { mutableStateOf(numIn(p0.buy)) }
    var pack by remember { mutableStateOf(p0.packSize > 0) }
    var packSize by remember { mutableStateOf(if (p0.packSize > 0) p0.packSize.toString() else "") }
    var packSell by remember { mutableStateOf(numIn(p0.packSell)) }
    var packBuy by remember { mutableStateOf(numIn(p0.packBuy)) }
    var stock by remember { mutableStateOf(numIn(p0.stock)) }
    var lowAt by remember { mutableStateOf(numIn(p0.lowAt)) }
    var scanning by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    var addStock by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val cats = Store.products.value.map { it.cat }.filter { it.isNotBlank() }.distinct().sorted()

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bm: Bitmap? ->
        if (bm != null) photo = Img.encode(bm)
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.openInputStream(uri)?.use { s ->
                    val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                    BitmapFactory.decodeStream(s, null, o)?.let { photo = Img.encode(it) }
                }
            } catch (e: Exception) { }
        }
    }

    val sellN = parseNum(sell) ?: 0.0
    val packN = packSize.toIntOrNull() ?: 0
    val ok = name.isNotBlank() && sellN > 0 && (!pack || isKg || packN > 1)

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(if (start == null) "নতুন পণ্য" else "পণ্য বদলান") {
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, null, tint = Color.White) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(16.dp)) {
            // photo
            Row(verticalAlignment = Alignment.CenterVertically) {
                Thumb(photo, name.ifBlank { "+" }, 96.dp, 22.dp)
                Gap(w = 14.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ camera.launch(null) }, shape = RoundedCornerShape(12.dp)) { Text("📷 ছবি তুলুন") }
                    OutlinedButton({ gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, shape = RoundedCornerShape(12.dp)) { Text("🖼 গ্যালারি থেকে") }
                }
            }
            Gap(h = 14.dp)
            Field(name, { name = it }, "পণ্যের নাম *")
            Field(cat, { cat = it }, "ক্যাটাগরি (যেমন: সিগারেট, পানীয়)")
            if (cats.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { c -> Chip(c, cat == c) { cat = c } }
                }
            }
            // barcode
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(barcode, { barcode = it }, label = { Text("বারকোড") }, singleLine = true, modifier = Modifier.weight(1f))
                Gap(w = 8.dp)
                Button({ scanning = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.brandDark)) { Text("স্ক্যান") }
            }
            Text(if (barcode.isBlank()) "বারকোড না থাকলে খালি রাখুন — 'আরও' থেকে এই পণ্যের QR স্টিকার প্রিন্ট করতে পারবেন।" else "",
                color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            // unit
            Text("কীভাবে বিক্রি হয়?", fontWeight = FontWeight.Bold)
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("পিস / টি হিসেবে", !isKg) { isKg = false }
                Chip("কেজি / ওজনে", isKg) { isKg = true; pack = false }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(sell, { sell = it }, if (isKg) "বেচা দাম / কেজি *" else "বেচা দাম / পিস *", Modifier.weight(1f), true)
                Field(buy, { buy = it }, if (isKg) "কেনা দাম / কেজি" else "কেনা দাম / পিস", Modifier.weight(1f), true)
            }
            if (!isKg) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("প্যাকেটেও বিক্রি হয়?", fontWeight = FontWeight.Bold)
                        Text("যেমন সিগারেট: ১ প্যাকেট = ২০ পিস", color = C.sub, fontSize = 12.sp)
                    }
                    Switch(pack, { pack = it })
                }
                if (pack) {
                    Field(packSize, { packSize = it }, "এক প্যাকেটে কয় পিস *", number = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(packSell, { packSell = it }, "বেচা দাম / প্যাকেট", Modifier.weight(1f), true)
                        Field(packBuy, { packBuy = it }, "কেনা দাম / প্যাকেট", Modifier.weight(1f), true)
                    }
                    if (packN > 1 && sellN > 0 && parseNum(packSell) == null)
                        Text("প্যাকেটের দাম না দিলে ধরা হবে ${tk(sellN * packN)}", color = C.sub, fontSize = 12.sp)
                }
            }
            Gap(h = 6.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(stock, { stock = it }, if (isKg) "স্টকে আছে (কেজি)" else "স্টকে আছে (পিস)", Modifier.weight(1f), true)
                Field(lowAt, { lowAt = it }, "কত হলে সতর্ক করবে", Modifier.weight(1f), true)
            }
            if (!owner) Text("শুধু দোকানের মালিক পণ্য বদলাতে পারবেন।", color = C.red, fontSize = 13.sp)
            if (start != null && owner) {
                OutlinedButton({ addStock = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text("＋ নতুন মাল এসেছে (স্টক বাড়ান)") }
                Gap(h = 8.dp)
                TextButton({ askDelete = true }) { Text("🗑 পণ্যটি মুছে ফেলুন", color = C.red) }
            }
            Gap(h = 20.dp)
        }
        Button(
            onClick = {
                busy = true
                val ps = if (pack && !isKg) packN else 0
                val pSell = parseNum(packSell) ?: (sellN * ps)
                val pBuy = parseNum(packBuy) ?: ((parseNum(buy) ?: 0.0) * ps)
                val buyN = parseNum(buy) ?: if (ps > 0 && pBuy > 0) pBuy / ps else 0.0
                Store.saveProduct(
                    p0.copy(
                        name = name.trim(), cat = cat.trim(), barcode = barcode.trim(), unit = if (isKg) "kg" else "pcs",
                        packSize = ps, sell = sellN, buy = buyN, packSell = if (ps > 0) pSell else 0.0, packBuy = if (ps > 0) pBuy else 0.0,
                        stock = parseNum(stock) ?: 0.0, lowAt = parseNum(lowAt) ?: 0.0, photo = photo,
                    )
                ) { saved -> busy = false; if (saved) Nav.close() }
            },
            enabled = ok && !busy && owner,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = C.brand),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(54.dp)
        ) { Text(if (busy) "সেভ হচ্ছে…" else "✓ সেভ করুন", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
    }

    if (scanning) ScanDialog({ scanning = false }) { code -> barcode = code; scanning = false }
    if (askDelete && start != null) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("মুছে ফেলবেন?") },
            text = { Text("“${start.name}” পণ্যের তালিকা থেকে মুছে যাবে। আগের বিক্রির হিসাব থাকবে।") },
            confirmButton = { Button({ Store.deleteProduct(start); askDelete = false; Nav.close() }, colors = ButtonDefaults.buttonColors(containerColor = C.red)) { Text("মুছুন") } },
            dismissButton = { TextButton({ askDelete = false }) { Text("না") } }
        )
    }
    if (addStock && start != null) {
        var amt by remember { mutableStateOf("") }
        var asPack by remember { mutableStateOf(start.hasPack) }
        AlertDialog(
            onDismissRequest = { addStock = false },
            title = { Text("নতুন মাল যোগ") },
            text = {
                Column {
                    if (start.hasPack) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                        Chip("প্যাকেট", asPack) { asPack = true }
                        Chip("পিস", !asPack) { asPack = false }
                    }
                    OutlinedTextField(amt, { amt = it }, label = { Text(if (start.isKg) "কত কেজি" else if (asPack) "কয় প্যাকেট" else "কয় পিস") },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            },
            confirmButton = {
                Button({
                    val a = parseNum(amt) ?: 0.0
                    if (a > 0) {
                        val add = if (asPack && start.hasPack) a * start.packSize else a
                        Store.addStock(start, add)
                        stock = numIn((parseNum(stock) ?: 0.0) + add)
                    }
                    addStock = false
                }) { Text("যোগ করুন") }
            },
            dismissButton = { TextButton({ addStock = false }) { Text("বাতিল") } }
        )
    }
}

private fun numIn(v: Double): String = if (v == 0.0) "" else if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

@Composable
private fun Field(v: String, on: (String) -> Unit, label: String, modifier: Modifier = Modifier.fillMaxWidth(), number: Boolean = false) {
    OutlinedTextField(
        v, on, label = { Text(label, fontSize = 13.sp) }, singleLine = true,
        keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        modifier = modifier.padding(bottom = 8.dp)
    )
}

/** Full-screen camera that returns the first code it reads. */
@Composable
fun ScanDialog(onDismiss: () -> Unit, onCode: (String) -> Unit) {
    Dialog(onDismiss, DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(24.dp)).background(Color.White).padding(14.dp)) {
            Text("বারকোড / QR এর সামনে ধরুন", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Gap(h = 10.dp)
            CameraScanner(Modifier.fillMaxWidth().height(300.dp)) { onCode(it) }
            TextButton(onDismiss, Modifier.align(Alignment.End)) { Text("বন্ধ করুন") }
        }
    }
}

