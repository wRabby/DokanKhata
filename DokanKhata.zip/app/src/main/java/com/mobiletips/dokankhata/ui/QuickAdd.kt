package com.mobiletips.dokankhata.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.delay

/**
 * Fast stock-taking: scan → type name and price → Save → the camera is ready for the next one.
 * A product that already exists just gets "how many came in?".
 */
@Composable
fun QuickAddScreen() {
    val ctx = LocalContext.current
    var code by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var isKg by remember { mutableStateOf(false) }
    var photo by remember { mutableStateOf("") }
    var count by remember { mutableStateOf(0) }
    var last by remember { mutableStateOf<String?>(null) }
    val taker = rememberPhotoTaker { bm -> photo = Img.encode(bm, 400) }
    val focus = remember { FocusRequester() }
    val existing = code?.let { Store.productByCode(it) }

    fun reset() { code = null; name = ""; sell = ""; buy = ""; qty = "1"; isKg = false; photo = "" }

    LaunchedEffect(code) {
        if (code != null && existing == null) { delay(150); try { focus.requestFocus() } catch (e: Exception) { } }
    }
    LaunchedEffect(last) { if (last != null) { delay(2500); last = null } }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        Header(L("স্ক্যান করে পণ্য যোগ", "Scan to add products"), bn("$count") + L("টি যোগ হলো", " added")) {
            IconButton({ Nav.close() }) { Icon(Icons.Filled.ArrowBack, L("পেছনে", "Back"), tint = Color.White) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(12.dp)) {
            if (code == null) {
                CameraScanner(Modifier.fillMaxWidth().height(260.dp), barcode = true) { c -> code = c }
                Gap(h = 10.dp)
                last?.let {
                    Text("✓ $it", color = C.green, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)).background(Color(0xFFECFDF5)).padding(12.dp))
                    Gap(h = 10.dp)
                }
                Text(L("পণ্যের বারকোড ক্যামেরার সামনে ধরুন। বারকোড না থাকলে নিচের বাটনে চাপ দিন।",
                    "Hold the product's barcode to the camera. No barcode? Use the button below."), color = C.sub, fontSize = 14.sp)
                Gap(h = 10.dp)
                OutlinedButton({ code = "" }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text(L("⌨️ বারকোড ছাড়া যোগ করুন", "⌨️ Add without barcode"))
                }
            } else if (existing != null) {
                val p = existing
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(p.photo, p.name, 56.dp, 14.dp)
                    Gap(w = 12.dp)
                    Column(Modifier.weight(1f)) {
                        Text(L("আগে থেকেই আছে", "Already in the list"), color = C.sub, fontSize = 12.sp)
                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(tk(p.sell) + " · " + L("স্টক ", "stock ") + stockText(p), color = C.sub, fontSize = 13.sp)
                    }
                }
                Gap(h = 12.dp)
                OutlinedTextField(qty, { qty = it }, label = { Text(if (p.isKg) L("কত কেজি এলো?", "How many kg came in?") else L("কয় পিস এলো?", "How many pieces came in?")) },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                Gap(h = 12.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton({ reset() }, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) { Text(L("বাতিল", "Cancel")) }
                    Button({
                        val q = parseNum(qty) ?: 0.0
                        if (q > 0) Store.addStock(p, q)
                        last = p.name + L(" — স্টক বাড়ল ", " — stock +") + num(q)
                        Voice.say("${p.name} স্টকে ${sayNum(q)} যোগ হলো", "${sayNum(q)} added to ${p.name}")
                        reset()
                    }, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = C.brand)) {
                        Text(L("✓ স্টকে যোগ", "✓ Add to stock"), fontWeight = FontWeight.Bold)
                    }
                }
                TextButton({ val pp = p; reset(); Nav.open(Page.EditProduct(pp)) }) { Text(L("পুরো পণ্যটা খুলুন", "Open the full product")) }
            } else {
                if (code!!.isNotEmpty()) Text(L("বারকোড: ", "Barcode: ") + code, color = C.sub, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    Box(Modifier.clickable(onClick = taker.camera)) { Thumb(photo, name.ifBlank { "📷" }, 60.dp, 14.dp) }
                    Gap(w = 10.dp)
                    Column {
                        TextButton(taker.camera) { Text(L("📷 ছবি (ঐচ্ছিক)", "📷 Photo (optional)")) }
                    }
                    Box(Modifier.weight(1f))
                    Chip(L("পিস", "Piece"), !isKg) { isKg = false }
                    Gap(w = 6.dp)
                    Chip(L("কেজি", "kg"), isKg) { isKg = true }
                }
                OutlinedTextField(name, { name = it }, label = { Text(L("পণ্যের নাম", "Product name")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), modifier = Modifier.fillMaxWidth().focusRequester(focus))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedTextField(sell, { sell = it }, label = { Text(if (isKg) L("বেচা দাম/কেজি", "Sell/kg") else L("বেচা দাম", "Sell price")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), modifier = Modifier.weight(1f))
                    OutlinedTextField(buy, { buy = it }, label = { Text(L("কেনা দাম", "Buy price")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next), modifier = Modifier.weight(1f))
                    OutlinedTextField(qty, { qty = it }, label = { Text(L("স্টক", "Stock")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(0.8f))
                }
                Text("🕒 " + dateBn(System.currentTimeMillis()) + ", " + timeBn(System.currentTimeMillis()), color = C.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Gap(h = 12.dp)
                val s = parseNum(sell) ?: 0.0
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton({ reset() }, Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp)) { Text(L("বাতিল", "Cancel")) }
                    Button({
                        val now = System.currentTimeMillis()
                        Store.saveProduct(Product(
                            name = name.trim(), barcode = code ?: "", unit = if (isKg) "kg" else "pcs", sell = s, buy = parseNum(buy) ?: 0.0,
                            stock = parseNum(qty) ?: 0.0, photo = photo, created = now,
                        ))
                        count++
                        last = name.trim() + " — " + tk(s)
                        Voice.say("${name.trim()} সেভ হলো", "${name.trim()} saved")
                        Toast.makeText(ctx, L("সেভ হয়েছে ✓ পরেরটা স্ক্যান করুন", "Saved ✓ Scan the next one"), Toast.LENGTH_SHORT).show()
                        reset()
                    }, Modifier.weight(1.4f).height(54.dp), enabled = name.isNotBlank() && s > 0, shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = C.brand)) {
                        Text(L("✓ সেভ, পরেরটা", "✓ Save, next"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
