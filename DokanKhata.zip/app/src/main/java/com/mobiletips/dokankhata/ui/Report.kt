package com.mobiletips.dokankhata.ui

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Payment
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Sale
import com.mobiletips.dokankhata.data.Store
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Sends a file to WhatsApp / Drive / printer etc. */
fun shareFile(ctx: Context, f: File, mime: String, title: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, title))
    } catch (e: Exception) {
        Toast.makeText(ctx, L("শেয়ার করা গেল না", "Could not share"), Toast.LENGTH_SHORT).show()
    }
}

private fun outFile(ctx: Context, name: String): File = File(File(ctx.cacheDir, "share").apply { mkdirs() }, name)

/** One printed line of a table: texts per column; red/blue colour for due/paid. */
class PdfRow(val cells: List<String>, val color: Int = 0xFF0F172A.toInt())

/** A simple A4 table report (title, sub title, columns, rows, total line). */
fun makeTablePdf(ctx: Context, fileName: String, title: String, sub: String, cols: List<Pair<String, Float>>, rows: List<PdfRow>, footer: String): File {
    val doc = PdfDocument()
    val pw = 595; val ph = 842; val m = 32f
    val titleP = Paint().apply { isAntiAlias = true; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; color = 0xFF0F172A.toInt() }
    val subP = Paint().apply { isAntiAlias = true; textSize = 11f; color = 0xFF64748B.toInt() }
    val headP = Paint().apply { isAntiAlias = true; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; color = 0xFF115E59.toInt() }
    val cellP = Paint().apply { isAntiAlias = true; textSize = 11f }
    val lineP = Paint().apply { color = 0xFFE2E8F0.toInt(); strokeWidth = 1f }
    val width = pw - 2 * m
    val rowH = 20f
    val perPage = ((ph - 140f) / rowH).toInt()
    val pages = rows.chunked(perPage).ifEmpty { listOf(emptyList()) }
    pages.forEachIndexed { pi, part ->
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pi + 1).create())
        val c = page.canvas
        c.drawText(title, m, 44f, titleP)
        c.drawText(sub + "   (" + (pi + 1) + "/" + pages.size + ")", m, 62f, subP)
        var y = 90f
        var x = m
        cols.forEach { (h, w) -> c.drawText(h, x, y, headP); x += width * w }
        y += 6f
        c.drawLine(m, y, pw - m, y, lineP)
        part.forEach { r ->
            y += rowH
            x = m
            cellP.color = r.color
            r.cells.forEachIndexed { i, t ->
                val w = width * cols.getOrElse(i) { "" to 0.2f }.second
                var s = t
                while (s.isNotEmpty() && cellP.measureText(s) > w - 6) s = s.dropLast(1)
                c.drawText(if (s.length < t.length) s.dropLast(1) + "…" else s, x, y, cellP)
                x += w
            }
            c.drawLine(m, y + 6f, pw - m, y + 6f, lineP)
        }
        if (pi == pages.size - 1) c.drawText(footer, m, y + 30f, titleP.apply { textSize = 13f })
        doc.finishPage(page)
    }
    val f = outFile(ctx, fileName)
    FileOutputStream(f).use { doc.writeTo(it) }
    doc.close()
    return f
}

/** All customers and what they owe. */
fun customersPdf(ctx: Context, list: List<Customer>) {
    val shop = Store.shopName.value.ifBlank { L("দোকান খাতা", "Dokan Khata") }
    val rows = list.sortedByDescending { it.due }.map {
        PdfRow(listOf(it.name, it.phone, if (it.due >= 0) tk(it.due) else L("অগ্রিম ", "advance ") + tk(-it.due)), if (it.due > 0.001) 0xFFDC2626.toInt() else 0xFF047857.toInt())
    }
    val f = makeTablePdf(
        ctx, "baki-list.pdf", "$shop — " + L("বাকির খাতা", "Baki book"), dateBn(System.currentTimeMillis()),
        listOf(L("কাস্টমার", "Customer") to 0.45f, L("মোবাইল", "Mobile") to 0.3f, L("বাকি", "Due") to 0.25f),
        rows, L("মোট বাকি: ", "Total due: ") + tk(list.sumOf { it.due.coerceAtLeast(0.0) })
    )
    shareFile(ctx, f, "application/pdf", L("বাকির খাতা PDF", "Baki book PDF"))
}

/** One customer's statement. */
fun customerPdf(ctx: Context, c: Customer, rows: List<PdfRow>) {
    val shop = Store.shopName.value.ifBlank { L("দোকান খাতা", "Dokan Khata") }
    val f = makeTablePdf(
        ctx, "baki-${c.name.filter { it.isLetterOrDigit() }.take(20)}.pdf", "$shop — ${c.name}",
        (if (c.phone.isNotBlank()) c.phone + " · " else "") + dateBn(System.currentTimeMillis()),
        listOf(L("তারিখ", "Date") to 0.24f, L("বিবরণ", "Details") to 0.34f, L("বাকি", "Due") to 0.14f, L("জমা", "Paid") to 0.14f, L("মোট বাকি", "Balance") to 0.14f),
        rows, L("এখন মোট বাকি: ", "Balance now: ") + tk(c.due)
    )
    shareFile(ctx, f, "application/pdf", L("হিসাব PDF", "Statement PDF"))
}

// ---------------- Excel (.xlsx) ----------------

private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

private fun colName(i: Int): String {
    var n = i + 1
    val sb = StringBuilder()
    while (n > 0) { val r = (n - 1) % 26; sb.insert(0, ('A' + r)); n = (n - 1) / 26 }
    return sb.toString()
}

/** Writes a real .xlsx (several sheets). Numbers stay numbers, so Excel can add them up. */
fun makeXlsx(ctx: Context, fileName: String, sheets: List<Pair<String, List<List<Any?>>>>): File {
    val f = outFile(ctx, fileName)
    ZipOutputStream(FileOutputStream(f)).use { z ->
        fun put(path: String, text: String) { z.putNextEntry(ZipEntry(path)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        val xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>"""
        put("[Content_Types].xml", xml + """<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""" +
            """<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""" +
            """<Default Extension="xml" ContentType="application/xml"/>""" +
            """<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""" +
            sheets.indices.joinToString("") { """<Override PartName="/xl/worksheets/sheet${it + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""" } +
            "</Types>")
        put("_rels/.rels", xml + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        put("xl/workbook.xml", xml + """<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""" +
            sheets.mapIndexed { i, s -> """<sheet name="${esc(s.first)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>""" }.joinToString("") + "</sheets></workbook>")
        put("xl/_rels/workbook.xml.rels", xml + """<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""" +
            sheets.indices.joinToString("") { """<Relationship Id="rId${it + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${it + 1}.xml"/>""" } +
            "</Relationships>")
        sheets.forEachIndexed { si, (_, rows) ->
            val sb = StringBuilder(xml + """<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            rows.forEachIndexed { ri, row ->
                sb.append("""<row r="${ri + 1}">""")
                row.forEachIndexed { ci, v ->
                    val ref = colName(ci) + (ri + 1)
                    when (v) {
                        null -> {}
                        is Number -> sb.append("""<c r="$ref"><v>${v.toDouble().let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() }}</v></c>""")
                        else -> sb.append("""<c r="$ref" t="inlineStr"><is><t>${esc(v.toString())}</t></is></c>""")
                    }
                }
                sb.append("</row>")
            }
            sb.append("</sheetData></worksheet>")
            put("xl/worksheets/sheet${si + 1}.xml", sb.toString())
        }
    }
    return f
}

/** Everything of the shop in one Excel file: sales, items sold, products, customers, baki entries. */
fun exportExcel(ctx: Context) {
    Toast.makeText(ctx, L("Excel ফাইল তৈরি হচ্ছে…", "Making the Excel file…"), Toast.LENGTH_SHORT).show()
    Store.fetchAll { sales: List<Sale>, pays: List<Payment> ->
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
        val d = { t: Long -> fmt.format(Date(t)) }
        val products: List<Product> = Store.products.value
        val customers: List<Customer> = Store.customers.value
        val cname = customers.associate { it.id to it.name }
        val sheets = listOf(
            "Sales" to (listOf(listOf<Any?>("তারিখ", "পণ্য", "মোট", "লাভ", "নগদ", "বাকি", "কাস্টমার", "বিক্রেতা")) +
                sales.map { s -> listOf<Any?>(d(s.time), s.items.joinToString(", ") { it.name + " x" + sayNum(it.qty) }, s.total, s.profit, s.paid, s.due, s.customerName, s.byName) }),
            "Items" to (listOf(listOf<Any?>("তারিখ", "পণ্য", "পরিমাণ", "একক", "দাম", "কেনা দাম", "মোট", "লাভ")) +
                sales.flatMap { s -> s.items.map { i -> listOf<Any?>(d(s.time), i.name, i.qty, i.mode, i.price, i.cost, i.total, if (i.cost > 0 || i.pid.isNotEmpty()) i.total - i.cost * i.qty else 0.0) } }),
            "Products" to (listOf(listOf<Any?>("নাম", "ক্যাটাগরি", "বারকোড", "একক", "কেনা দাম", "বিক্রি দাম", "স্টক", "যোগ হয়েছে")) +
                products.sortedBy { it.name }.map { p -> listOf<Any?>(p.name, p.cat, p.barcode, p.unit, p.buy, p.sell, p.stock, if (p.created > 0) d(p.created) else "") }),
            "Customers" to (listOf(listOf<Any?>("নাম", "মোবাইল", "মোট বাকি")) +
                customers.sortedByDescending { it.due }.map { c -> listOf<Any?>(c.name, c.phone, c.due) }),
            "Baki" to (listOf(listOf<Any?>("তারিখ", "কাস্টমার", "ধরন", "টাকা", "নোট")) +
                (sales.filter { it.due > 0.001 }.map { s -> Triple(s.time, s.customerName, listOf<Any?>("বিক্রিতে বাকি", s.due, s.items.joinToString(", ") { it.name })) } +
                    pays.map { p -> Triple(p.time, cname[p.customerId] ?: "", listOf<Any?>(if (p.isDue) "বাকি লেখা" else "জমা", if (p.isDue) p.amount else -p.amount, p.note)) })
                    .sortedBy { it.first }.map { (t, n, rest) -> listOf<Any?>(d(t), n) + rest }),
        )
        val f = makeXlsx(ctx, "dokan-khata-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".xlsx", sheets)
        shareFile(ctx, f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", L("Excel ফাইল", "Excel file"))
    }
}
