package com.mobiletips.dokankhata.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.mobiletips.dokankhata.data.Recognizer
import java.util.concurrent.Executors

/**
 * Live camera. Reads barcodes / QR codes (ML Kit) when [barcode] is on, and when [onFrame] is given
 * hands over a square picture every [frameEveryMs] ms (on a background thread) for photo recognition.
 */
@Composable
fun CameraScanner(
    modifier: Modifier = Modifier,
    barcode: Boolean = true,
    frameEveryMs: Long = 700,
    onFrame: ((Bitmap) -> Unit)? = null,
    onCode: (String) -> Unit = {},
) {
    val ctx = LocalContext.current
    var allowed by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed = it }
    LaunchedEffect(Unit) { if (!allowed) ask.launch(Manifest.permission.CAMERA) }

    Box(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF1F2937))
            .semantics { contentDescription = L("ক্যামেরা", "Camera") },
        contentAlignment = Alignment.Center
    ) {
        if (allowed) {
            CameraView(barcode, frameEveryMs, onFrame, onCode)
            Box(Modifier.fillMaxWidth(0.62f).height(110.dp).border(3.dp, Color(0xFF34D399), RoundedCornerShape(14.dp)))
            if (barcode) Box(Modifier.fillMaxWidth(0.62f).height(2.dp).background(Color(0xFFF87171)))
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { ask.launch(Manifest.permission.CAMERA) }.padding(20.dp)) {
                Text("📷", fontSize = 34.sp)
                Text(L("ক্যামেরা চালু করতে এখানে চাপ দিন", "Tap here to turn on the camera"), color = Color.White, textAlign = TextAlign.Center)
            }
        }
    }
}

@androidx.annotation.OptIn(ExperimentalGetImage::class)
@Composable
private fun CameraView(barcode: Boolean, frameEveryMs: Long, onFrame: ((Bitmap) -> Unit)?, onCode: (String) -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latestCode by rememberUpdatedState(onCode)
    val latestFrame by rememberUpdatedState(onFrame)
    val latestBarcode by rememberUpdatedState(barcode)
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val exec = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember { BarcodeScanning.getClient() }
    val main = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        var lastCode = ""
        var lastTime = 0L
        var lastFrame = 0L
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(exec) { proxy ->
                    // photo recognition: a picture now and then
                    val f = latestFrame
                    val now = System.currentTimeMillis()
                    if (f != null && now - lastFrame >= frameEveryMs) {
                        lastFrame = now
                        try {
                            val bm = Recognizer.prepare(proxy.toBitmap(), proxy.imageInfo.rotationDegrees)
                            f(bm)
                        } catch (e: Throwable) { }
                    }
                    val media = proxy.image
                    if (!latestBarcode || media == null) { proxy.close(); return@setAnalyzer }
                    val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    scanner.process(img)
                        .addOnSuccessListener { codes ->
                            val v = codes.firstOrNull { !it.rawValue.isNullOrEmpty() }?.rawValue
                            if (v != null) {
                                val t = System.currentTimeMillis()
                                if (v != lastCode || t - lastTime > 1800) {
                                    lastCode = v; lastTime = t
                                    main.post { latestCode(v) }
                                } else lastTime = t
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            try { provider?.unbindAll() } catch (e: Exception) { }
        }
    }
    AndroidView({ previewView }, Modifier.fillMaxSize())
}
