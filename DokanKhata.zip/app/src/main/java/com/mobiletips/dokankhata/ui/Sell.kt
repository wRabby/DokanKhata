package com.mobiletips.dokankhata.ui

import android.media.AudioManager
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.aspectRatio
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.CartLine
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.delay

/** The cart (and the chosen customer) stay while you move between tabs. */
object Cart {
    val lines = mutableStateListOf<CartLine>()
    val customer = mutableStateOf<Customer?>(null)
    val total get() = lines.sumOf { it.total }

    private fun lineFor(p: Product, mode: String, qty: Double, key: String) = when (mode) {
        "pack" -> CartLine(key, p.id, p.name, "pack", qty, p.packSell, p.packBuy, p.packSize.toDouble())
        "kg" -> CartLine(key, p.id, p.name, "kg", qty, p.sell, p.buy, 1.0)
        else -> CartLine(key, p.id, p.name, "pc", qty, p.sell, p.buy, 1.0)
    }

    fun add(p: Product, mode: String, qty: Double = 1.0, price: Double? = null) {
        if (mode == "kg") {
            val l = lineFor(p, mode, qty, "${p.id}:kg:${System.nanoTime()}")
            lines.add(if (price != null) l.copy(price = price) else l); return
        }
        val base = lineFor(p, mode, qty, "")
        val pr = price ?: base.price
        val key = "${p.id}:$mode:$pr"
        val i = lines.indexOfFirst { it.key == key }
        if (i >= 0) lines[i] = lines[i].copy(qty = lines[i].qty + qty) else lines.add(base.copy(key = key, price = pr))
    }

    /** A typed item that is not in the product list. [cost] = buy price per one (0 = unknown, no profit counted). */
    fun addCustom(name: String, price: Double, qty: Double, cost: Double = 0.0) {
        lines.add(CartLine("c${System.nanoTime()}", "", name.ifBlank { L("অন্যান্য", "Other") }, "custom", qty, price, cost, 0.0))
    }

    fun setQty(i: Int, q: Double) {
        if (i !in lines.indices) return
        if (q <= 0.0001) lines.removeAt(i) else lines[i] = lines[i].copy(qty = q)
    }

    fun switchMode(i: Int) {
        val l = lines.getOrNull(i) ?: return
        val p = Store.products.value.firstOrNull { it.id == l.productId } ?: return
        if (!p.hasPack) return
        val to = if (l.mode == "pack") "pc" else "pack"
        lines.removeAt(i)
        add(p, to, l.qty)
    }

    fun clear() { lines.clear(); customer.value = null }
}

@Composable
fun SellScreen() {
    val ctx = LocalContext.current
    val products by Store.products
    val myCats by Store.cats
    var cat by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<Product?>(null) }
    var keypad by remember { mutableStateOf(false) }
    var checkout by remember { mutableStateOf(false) }
    var pickCustomer by remember { mutableStateOf(false) }
    LaunchedEffect(msg) { if (msg != null) { delay(2200); msg = null } }
    // the owner's categories first (in his order), then any other category written on a product
    val cats = remember(products, myCats) { (myCats + products.map { it.cat }.filter { it.isNotBlank() }.sorted()).distinct() }

    Column(Modifier.fillMaxSize()) {
        Header(L("নতুন বিক্রি", "New sale"), L("পণ্যের ছবিতে চাপ দিন", "Tap a product's picture")) {
            IconButton({ searching = !searching; query = "" }) {
                Icon(if (searching) Icons.Filled.Close else Icons.Filled.Search, L("খুঁজুন", "Search"), tint = Color.White)
            }
        }
        CustomerBar { pickCustomer = true }
        if (searching) OutlinedTextField(
            query, { query = it },
            placeholder = { Text(L("পণ্যের নাম লিখুন…", "Type a product name…")) },
            leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 6.dp)
        )
        if (cats.isNotEmpty()) Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CatChip(L("সব", "All"), cat.isEmpty()) { cat = "" }
            cats.forEach { c -> CatChip(c, cat == c) { cat = if (cat == c) "" else c } }
        } else Gap(h = 8.dp)
        val shown = remember(products, query, cat) {
            val q = query.trim()
            products.filter { (cat.isEmpty() || it.cat == cat) && (q.isEmpty() || it.name.contains(q, true)) }
        }
        Box(Modifier.weight(1f)) {
            LazyVerticalGrid(
                GridCells.Fixed(3), Modifier.fillMaxSize().padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { KeypadTile { keypad = true } }
                items(shown, key = { it.id }) { p -> SellTile(p) { picked = p } }
                if (products.isEmpty()) item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                    Text(L("এখনো কোনো পণ্য নেই। 'পণ্য' ট্যাবে গিয়ে ছবি তুলে যোগ করুন।", "No products yet. Add them with a photo in the 'Products' tab."), color = C.sub, fontSize = 13.sp)
                }
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) { Gap(h = 12.dp) }
            }
            msg?.let { t ->
                Text(
                    "✓ $t", color = C.green, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp)).background(Color(0xFFECFDF5)).border(1.dp, C.green, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                )
            }
        }
        CartPanel { checkout = true }
    }

    picked?.let { p ->
        PickDialog(p, { picked = null }) { mode, qty, price ->
            Cart.add(p, mode, qty, price)
            Beep.added()
            val total = qty * price
            msg = "${p.name} × ${qtyText(mode, qty)} = ${tk(total)}"
            Voice.say("${p.name}, ${sayNum(total)} টাকা", "")
            picked = null
        }
    }
    if (keypad) KeypadDialog { keypad = false }
    if (pickCustomer) CustomerPicker({ pickCustomer = false }) { Cart.customer.value = it; pickCustomer = false }
    if (checkout) CheckoutDialog({ checkout = false }) {
        checkout = false
        Toast.makeText(ctx, L("বিক্রি সেভ হয়েছে ✓", "Sale saved ✓"), Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun CatChip(t: String, on: Boolean, onClick: () -> Unit) {
    Text(
        t, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
        color = if (on) Color.White else C.text,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) C.brand else Color.White)
            .border(1.dp, if (on) C.brand else C.line, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)
    )
}

/**
 * Tapping a product: big picture, name, price (can be changed for this sale), the owner's note,
 * and how many (− / +, or weight for loose goods).
 */
@Composable
private fun PickDialog(p: Product, onDismiss: () -> Unit, onAdd: (mode: String, qty: Double, price: Double) -> Unit) {
    var mode by remember { mutableStateOf(if (p.isKg) "kg" else "pc") }
    var qty by remember { mutableStateOf(1.0) }
    var gram by remember { mutableStateOf("") }
    val baseFor = { m: String -> if (m == "pack") p.packSell else p.sell }
    var price by remember { mutableStateOf(priceIn(baseFor(mode))) }
    val priceN = parseNum(price) ?: 0.0
    val q = if (mode == "kg") (parseNum(gram)?.div(1000.0) ?: 0.0) else qty
    val ok = priceN > 0 && q > 0
    Dialog(onDismiss, DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().padding(18.dp).clip(RoundedCornerShape(26.dp)).background(Color.White)
                .verticalScroll(rememberScrollState())
        ) {
            Box {
                BigPhoto(p.photo, p.name, Modifier.heightIn(max = 260.dp))
                Text(
                    tk(baseFor(mode)) + if (mode == "kg") "/" + L("কেজি", "kg") else "",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).clip(RoundedCornerShape(12.dp))
                        .background(C.brandDark.copy(alpha = 0.9f)).padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
            Column(Modifier.padding(16.dp)) {
                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                if (p.cat.isNotBlank()) Text(p.cat, color = C.sub, fontSize = 13.sp)
                if (p.note.isNotBlank()) {
                    Gap(h = 10.dp)
                    Text(
                        "📝 " + p.note, fontSize = 15.sp, color = Color(0xFF78350F),
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.amberSoft)
                            .border(1.dp, C.amber, RoundedCornerShape(12.dp)).padding(12.dp)
                    )
                }
                if (p.hasPack) {
                    Gap(h = 12.dp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CatChip(L("পিস", "Piece") + " " + tk(p.sell), mode == "pc") { mode = "pc"; price = priceIn(p.sell) }
                        CatChip(L("প্যাকেট", "Pack") + " " + tk(p.packSell), mode == "pack") { mode = "pack"; price = priceIn(p.packSell) }
                    }
                }
                Gap(h = 12.dp)
                if (mode == "kg") {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(250, 500, 1000, 2000).forEach { g ->
                            CatChip(if (g < 1000) bn("$g") + L(" গ্রাম", " g") else bn("${g / 1000}") + L(" কেজি", " kg"), gram == g.toString()) { gram = g.toString() }
                        }
                    }
                    Gap(h = 8.dp)
                    OutlinedTextField(gram, { gram = it }, label = { Text(L("ওজন (গ্রাম)", "Weight (grams)")) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                } else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                    BigBtn("−", L("একটা কমান", "One less")) { if (qty > 1) qty -= 1 }
                    Text(num(qty), Modifier.width(80.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 30.sp)
                    BigBtn("+", L("একটা বাড়ান", "One more")) { qty += 1 }
                }
                Gap(h = 10.dp)
                OutlinedTextField(
                    price, { price = it }, singleLine = true,
                    label = { Text(if (mode == "kg") L("দাম / কেজি (দরকারে বদলান)", "Price / kg (change if needed)") else L("দাম / একটা (দরকারে বদলান)", "Price each (change if needed)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()
                )
                Gap(h = 10.dp)
                Text(L("মোট: ", "Total: ") + tk(q * priceN), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = C.green)
                Gap(h = 12.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onDismiss, Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) { Text(L("বাতিল", "Cancel")) }
                    Button({ if (ok) onAdd(mode, q, priceN) }, Modifier.weight(1.4f).height(52.dp), enabled = ok, shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = C.brand)) { Text(L("🛒 কার্টে যোগ", "🛒 Add to cart"), fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                }
            }
        }
    }
}

@Composable
private fun BigBtn(t: String, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(C.brandSoft).clickable(onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) { Text(t, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = C.brandDark) }
}

private fun priceIn(v: Double): String = if (v == 0.0) "" else if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

/** Shows who the sale is for (baki goes to this customer). */
@Composable
private fun CustomerBar(onPick: () -> Unit) {
    if (!Access.can("baki")) return
    val c by Cart.customer
    Row(
        Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (c != null) C.brandSoft else Color.White).clickable(onClick = onPick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cc = c
        if (cc != null) {
            Thumb(cc.photo, cc.name, 30.dp, 15.dp)
            Gap(w = 8.dp)
            Column(Modifier.weight(1f)) {
                Text(cc.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(L("আগের বাকি ", "Earlier baki ") + tk(cc.due), color = C.sub, fontSize = 12.sp)
            }
            Text(L("✕ সরান", "✕ Remove"), color = C.red, fontSize = 13.sp, modifier = Modifier.clickable { Cart.customer.value = null }.padding(4.dp))
        } else {
            Text("👤", fontSize = 18.sp)
            Gap(w = 8.dp)
            Text(L("কাস্টমার বাছুন (বাকির জন্য)", "Choose customer (for baki)"), color = C.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("›", fontSize = 20.sp, color = C.sub)
        }
    }
}

/** Search customers by name or phone, or add a new one right here. */
@Composable
fun CustomerPicker(onDismiss: () -> Unit, onPick: (Customer) -> Unit) {
    val customers by Store.customers
    var q by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("কাস্টমার বাছুন", "Choose customer")) },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, label = { Text(L("নাম বা মোবাইল লিখুন", "Name or mobile")) }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) })
                val list = customers.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.phone.contains(q.trim()) }.take(6)
                list.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(c.photo, c.name, 36.dp, 18.dp)
                        Gap(w = 10.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            if (c.phone.isNotBlank()) Text(bn(c.phone), color = C.sub, fontSize = 12.sp)
                        }
                        if (c.due > 0.001) Text(tk(c.due), color = C.red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                Text(
                    L("＋ নতুন কাস্টমার", "＋ New customer") + if (q.isNotBlank()) ": ${q.trim()}" else "",
                    color = C.brand, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clickable { adding = true }.padding(vertical = 10.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text(L("বন্ধ", "Close")) } }
    )
    if (adding) CustomerDialog(null, q.trim(), { adding = false }) { n, ph, photo ->
        val id = Store.addCustomer(n, ph, photo)
        adding = false
        onPick(Customer(id, n, ph, 0.0, photo))
    }
}

@Composable
private fun KeypadTile(onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(C.amberSoft).border(1.5.dp, C.amber, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp).aspectRatio(0.8f),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("🔢", fontSize = 28.sp)
        Text(L("দাম লিখুন", "Type price"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E), textAlign = TextAlign.Center)
    }
}

@Composable
private fun SellTile(p: Product, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White)
            .border(1.dp, if (p.low) C.red else C.line, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .semantics(mergeDescendants = true) { contentDescription = p.name + ", " + tk(p.sell) }
    ) {
        Box {
            BigPhoto(p.photo, p.name)
            Text(
                tk(p.sell) + if (p.isKg) "/" + L("কেজি", "kg") else "",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1,
                modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).clip(RoundedCornerShape(10.dp))
                    .background(C.brandDark.copy(alpha = 0.88f)).padding(horizontal = 7.dp, vertical = 3.dp)
            )
        }
        Text(
            p.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, color = C.text,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun CartPanel(onCheckout: () -> Unit) {
    if (Cart.lines.isEmpty()) return
    Surface(color = Color.White, shadowElevation = 14.dp, shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(L("কার্ট", "Cart") + " (${bn(Cart.lines.size.toString())})", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text(L("সব মুছুন", "Clear all"), color = C.red, fontSize = 13.sp, modifier = Modifier.clickable { Cart.lines.clear() }.padding(6.dp))
            }
            LazyColumn(Modifier.heightIn(max = 190.dp)) {
                itemsIndexed(Cart.lines, key = { _, l -> l.key }) { i, l -> CartRow(i, l) }
            }
            Gap(h = 8.dp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(L("মোট", "Total"), color = C.sub, fontSize = 13.sp)
                    Text(tk(Cart.total), color = C.green, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onCheckout, shape = RoundedCornerShape(16.dp), modifier = Modifier.height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.brand)
                ) { Text(L("✓ বিক্রি সম্পন্ন", "✓ Finish sale"), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CartRow(i: Int, l: CartLine) {
    val p = Store.products.value.firstOrNull { it.id == l.productId }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Thumb(p?.photo ?: "", l.name, 38.dp, 10.dp)
        Gap(w = 8.dp)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(l.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                if (p?.hasPack == true) {
                    Gap(w = 4.dp)
                    Box(Modifier.clickable { Cart.switchMode(i) }) {
                        Pill(if (l.mode == "pack") L("প্যাকেট ⇄", "Pack ⇄") else L("পিস ⇄", "Piece ⇄"), C.amberSoft, Color(0xFF92400E))
                    }
                }
            }
            Text("${tk(l.price)} × ${qtyText(l.mode, l.qty)}", color = C.sub, fontSize = 12.sp)
        }
        if (l.mode != "kg") {
            QtyBtn("−", L("একটা কমান", "One less")) { Cart.setQty(i, l.qty - 1) }
            Text(num(l.qty), Modifier.width(30.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            QtyBtn("+", L("একটা বাড়ান", "One more")) { Cart.setQty(i, l.qty + 1) }
        } else QtyBtn("✕", L("সরান", "Remove")) { Cart.setQty(i, 0.0) }
        Text(tk(l.total), Modifier.width(70.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun QtyBtn(t: String, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(C.line).clickable(onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) { Text(t, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

/** Loose goods: type the weight, or the money the customer wants to spend. */
@Composable
private fun WeightDialog(p: Product, onDismiss: () -> Unit, onAdd: (Double) -> Unit) {
    var gram by remember { mutableStateOf("") }
    var taka by remember { mutableStateOf("") }
    val kg = parseNum(gram)?.div(1000.0) ?: parseNum(taka)?.let { if (p.sell > 0) it / p.sell else null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${p.name} — ${tk(p.sell)}/" + L("কেজি", "kg")) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(250, 500, 1000, 2000).forEach { g ->
                        Text(
                            if (g < 1000) bn("$g") + L(" গ্রাম", " g") else bn("${g / 1000}") + L(" কেজি", " kg"),
                            fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                                .clickable { gram = g.toString(); taka = "" }.padding(horizontal = 9.dp, vertical = 7.dp)
                        )
                    }
                }
                Gap(h = 10.dp)
                OutlinedTextField(gram, { gram = it; taka = "" }, label = { Text(L("ওজন (গ্রাম)", "Weight (grams)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text(L("অথবা", "or"), color = C.sub, modifier = Modifier.padding(vertical = 4.dp))
                OutlinedTextField(taka, { taka = it; gram = "" }, label = { Text(L("কত টাকার দেবেন", "For how much money")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (kg != null && kg > 0) {
                    Gap(h = 10.dp)
                    Text("${qtyText("kg", kg)} = ${tk(kg * p.sell)}", fontWeight = FontWeight.Bold, color = C.green, fontSize = 17.sp)
                }
            }
        },
        confirmButton = { Button({ kg?.let { if (it > 0) onAdd(it) } }, enabled = kg != null && kg > 0) { Text(L("যোগ করুন", "Add")) } },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** Sell something by typing the price (it does not have to be in the product list). */
@Composable
private fun KeypadDialog(onDismiss: () -> Unit) {
    var row by remember { mutableStateOf(ItemRow()) }
    var save by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("দাম লিখে যোগ করুন", "Add by price")) },
        text = {
            Column {
                ItemRowEditor(row) { row = it }
                if (Access.can("products")) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { save = !save }) {
                    Checkbox(save, { save = it })
                    Text(L("পণ্যের তালিকায় সেভ করুন", "Save to product list"), fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Button({
                if (row.ok) {
                    Cart.addCustom(row.name.trim(), row.sellN, row.qtyN, row.buyN)
                    if (save && row.name.isNotBlank()) Store.saveProduct(Product(name = row.name.trim(), sell = row.sellN, buy = row.buyN))
                    Beep.added()
                    Voice.say("${row.name.trim()} ${sayNum(row.sellN * row.qtyN)} টাকা যোগ হলো", "${sayNum(row.sellN * row.qtyN)} taka added")
                    onDismiss()
                }
            }, enabled = row.ok) { Text(L("যোগ করুন", "Add")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** One typed item: name, buy price, sell price, how many. */
data class ItemRow(val name: String = "", val buy: String = "", val sell: String = "", val qty: String = "1") {
    val buyN get() = parseNum(buy) ?: 0.0
    val sellN get() = parseNum(sell) ?: 0.0
    val qtyN get() = (parseNum(qty) ?: 1.0).coerceAtLeast(0.0)
    val ok get() = sellN > 0 && qtyN > 0
    val total get() = sellN * qtyN
    val profit get() = if (buyN > 0) (sellN - buyN) * qtyN else 0.0
}

@Composable
fun ItemRowEditor(row: ItemRow, onChange: (ItemRow) -> Unit) {
    Column {
        OutlinedTextField(row.name, { onChange(row.copy(name = it)) }, label = { Text(L("জিনিসের নাম", "Item name")) }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
            OutlinedTextField(row.buy, { onChange(row.copy(buy = it)) }, label = { Text(L("কেনা দাম", "Buy"), fontSize = 12.sp) }, singleLine = true,
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(row.sell, { onChange(row.copy(sell = it)) }, label = { Text(L("বিক্রি দাম", "Sell"), fontSize = 12.sp) }, singleLine = true,
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(row.qty, { onChange(row.copy(qty = it)) }, label = { Text(L("কয়টা", "Qty"), fontSize = 12.sp) }, singleLine = true,
                modifier = Modifier.weight(0.7f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        if (row.ok) Text(
            L("মোট ", "Total ") + tk(row.total) + if (row.buyN > 0) L(" · লাভ ", " · profit ") + tk(row.profit) else L(" · (কেনা দাম না দিলে লাভ গোনা হবে না)", " · (no buy price, no profit counted)"),
            fontWeight = FontWeight.Bold, color = C.green, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

/** Payment: change to give back, or put the rest on the customer's baki. */
@Composable
private fun CheckoutDialog(onDismiss: () -> Unit, onDone: () -> Unit) {
    val total = Cart.total
    val canBaki = Access.can("baki")
    var customer by remember { mutableStateOf(Cart.customer.value) }
    var given by remember { mutableStateOf(if (Cart.customer.value != null) "0" else "") }
    var picking by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val g = parseNum(given)
    val paid = (g ?: total).coerceIn(0.0, total)
    val due = total - paid
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(L("মোট ", "Total ") + tk(total), fontWeight = FontWeight.Bold, color = C.green) },
        text = {
            Column {
                OutlinedTextField(given, { given = it }, label = { Text(L("কাস্টমার কত দিল? (খালি = পুরো টাকা)", "Money received (empty = full)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (canBaki) Text(L("পুরোটা বাকি", "All on baki"), fontSize = 13.sp, color = C.red, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.redSoft)
                        .clickable { given = "0" }.padding(horizontal = 10.dp, vertical = 6.dp))
                    Text(L("পুরো টাকা পেয়েছি", "Paid in full"), fontSize = 13.sp, color = C.green, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                        .clickable { given = "" }.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                if (g != null && g > total) {
                    Gap(h = 10.dp)
                    Text(L("ফেরত দিন: ", "Give back: ") + tk(g - total), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = C.brandDark)
                }
                if (due > 0.001) {
                    Gap(h = 10.dp)
                    if (!canBaki) Text(L("বাকি দেওয়ার অনুমতি নেই — পুরো টাকা নিন।", "You may not give baki — take the full amount."), color = C.red)
                    else {
                        Text(L("বাকি ", "Baki ") + tk(due) + L(" — কার নামে?", " — for whom?"), fontWeight = FontWeight.Bold, color = C.red)
                        val c = customer
                        Row(
                            Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.bg)
                                .clickable { picking = true }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (c != null) {
                                Thumb(c.photo, c.name, 32.dp, 16.dp)
                                Gap(w = 8.dp)
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, fontWeight = FontWeight.Bold)
                                    Text(L("নতুন মোট বাকি ", "New total baki ") + tk(c.due + due), color = C.red, fontSize = 12.sp)
                                }
                                Text(L("বদলান", "Change"), color = C.brand)
                            } else Text(L("👤 কাস্টমার বাছুন…", "👤 Choose customer…"), color = C.brand, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button({
                busy = true
                val c = if (due > 0.001) customer else null
                Store.checkout(Cart.lines.toList(), paid, c) { ok ->
                    busy = false
                    if (ok) {
                        if (c != null) Voice.say(
                            "${c.name}-এর নামে ${sayNum(due)} টাকা বাকি যোগ হলো, মোট বাকি ${sayNum(c.due + due)} টাকা",
                            "${sayNum(due)} taka added to ${c.name}'s baki. Total baki ${sayNum(c.due + due)} taka"
                        ) else Voice.say("মোট ${sayNum(total)} টাকা, বিক্রি সেভ হয়েছে", "Total ${sayNum(total)} taka. Sale saved")
                        Cart.clear(); onDone()
                    }
                }
            }, enabled = !busy && (due <= 0.001 || (canBaki && customer != null))) { Text(if (busy) L("সেভ হচ্ছে…", "Saving…") else L("বিক্রি সেভ করুন", "Save sale")) }
        },
        dismissButton = { TextButton({ if (!busy) onDismiss() }) { Text(L("বাতিল", "Cancel")) } }
    )
    if (picking) CustomerPicker({ picking = false }) { customer = it; Cart.customer.value = it; picking = false }
}
