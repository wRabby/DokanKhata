package com.mobiletips.dokankhata.ui

import android.media.AudioManager
import android.media.ToneGenerator
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.CartLine
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.delay

/** The cart stays while you move between tabs. */
object Cart {
    val lines = mutableStateListOf<CartLine>()
    val total get() = lines.sumOf { it.total }

    private fun lineFor(p: Product, mode: String, qty: Double, key: String) = when (mode) {
        "pack" -> CartLine(key, p.id, p.name, "pack", qty, p.packSell, p.packBuy, p.packSize.toDouble())
        "kg" -> CartLine(key, p.id, p.name, "kg", qty, p.sell, p.buy, 1.0)
        else -> CartLine(key, p.id, p.name, "pc", qty, p.sell, p.buy, 1.0)
    }

    fun add(p: Product, mode: String, qty: Double = 1.0) {
        if (mode == "kg") { lines.add(lineFor(p, mode, qty, "${p.id}:kg:${System.nanoTime()}")); return }
        val key = "${p.id}:$mode"
        val i = lines.indexOfFirst { it.key == key }
        if (i >= 0) lines[i] = lines[i].copy(qty = lines[i].qty + qty) else lines.add(lineFor(p, mode, qty, key))
    }

    fun addCustom(name: String, price: Double, qty: Double) {
        lines.add(CartLine("c${System.nanoTime()}", "", name.ifBlank { "অন্যান্য" }, "custom", qty, price, 0.0, 0.0))
    }

    fun setQty(i: Int, q: Double) {
        if (i !in lines.indices) return
        if (q <= 0.0001) lines.removeAt(i) else lines[i] = lines[i].copy(qty = q)
    }

    /** Packet <-> piece for products that come in packets. */
    fun switchMode(i: Int) {
        val l = lines.getOrNull(i) ?: return
        val p = Store.products.value.firstOrNull { it.id == l.productId } ?: return
        if (!p.hasPack) return
        val to = if (l.mode == "pack") "pc" else "pack"
        lines.removeAt(i)
        add(p, to, l.qty)
    }
}

@Composable
fun SellScreen() {
    val ctx = LocalContext.current
    val products by Store.products
    var scanOn by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var weighFor by remember { mutableStateOf<Product?>(null) }
    var unknownCode by remember { mutableStateOf<String?>(null) }
    var keypad by remember { mutableStateOf(false) }
    var checkout by remember { mutableStateOf(false) }
    val tone = remember { try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (e: Exception) { null } }
    DisposableEffect(Unit) { onDispose { tone?.release() } }
    LaunchedEffect(msg) { if (msg != null) { delay(2500); msg = null } }

    fun onScan(code: String) {
        val p = Store.productByCode(code)
        if (p == null) {
            tone?.startTone(ToneGenerator.TONE_PROP_NACK, 150)
            if (unknownCode == null) unknownCode = code
            return
        }
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        when {
            p.isKg -> weighFor = p
            p.hasPack && p.barcode == code -> { Cart.add(p, "pack"); msg = true to "${p.name} (প্যাকেট) — ${tk(p.packSell)}" }
            else -> { Cart.add(p, "pc"); msg = true to "${p.name} — ${tk(p.sell)}" }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header("নতুন বিক্রি", if (scanOn) "বারকোড / QR এর সামনে ধরুন" else "পণ্যে চাপ দিন বা নাম লিখুন") {
            Text(
                if (scanOn) "✕ ক্যামেরা বন্ধ" else "📷 স্ক্যান",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.22f))
                    .clickable { scanOn = !scanOn }.padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
        if (scanOn) {
            Box(Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp)) {
                CameraScanner(Modifier.fillMaxWidth().height(180.dp)) { onScan(it) }
                msg?.let { (ok, t) ->
                    Text(
                        (if (ok) "✓ " else "") + t,
                        color = if (ok) C.green else C.red, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp).fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp)).background(Color(0xFFECFDF5)).padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
        OutlinedTextField(
            query, { query = it },
            placeholder = { Text("পণ্যের নাম লিখুন…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, null) } },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
        )
        val shown = remember(products, query) {
            val q = query.trim()
            if (q.isEmpty()) products else products.filter { it.name.contains(q, true) || it.cat.contains(q, true) || it.barcode == q }
        }
        LazyVerticalGrid(
            GridCells.Fixed(4), Modifier.weight(1f).padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { KeypadTile { keypad = true } }
            items(shown, key = { it.id }) { p ->
                SellTile(p) {
                    if (p.isKg) weighFor = p else { Cart.add(p, "pc"); msg = true to "${p.name} — ${tk(p.sell)}" }
                }
            }
            if (products.isEmpty()) item {
                Text("এখনো কোনো পণ্য নেই। 'পণ্য' ট্যাবে গিয়ে যোগ করুন।", color = C.sub, fontSize = 13.sp)
            }
        }
        CartPanel { checkout = true }
    }

    weighFor?.let { p -> WeightDialog(p, { weighFor = null }) { kg -> Cart.add(p, "kg", kg); msg = true to "${p.name} — ${qtyText("kg", kg)}"; weighFor = null } }
    unknownCode?.let { code ->
        AlertDialog(
            onDismissRequest = { unknownCode = null },
            title = { Text("নতুন পণ্য?") },
            text = { Text("এই কোডের কোনো পণ্য তালিকায় নেই:\n${bn(code.take(40))}\n\n" +
                if (Access.isOwner) "নতুন পণ্য হিসেবে যোগ করবেন?" else "দোকানের মালিককে পণ্যটি যোগ করতে বলুন।") },
            confirmButton = {
                if (Access.isOwner) Button({ unknownCode = null; Nav.open(Page.EditProduct(null, code)) }) { Text("যোগ করুন") }
                else Button({ unknownCode = null }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton({ unknownCode = null }) { Text("না") } }
        )
    }
    if (keypad) KeypadDialog { keypad = false }
    if (checkout) CheckoutDialog({ checkout = false }) {
        checkout = false
        Toast.makeText(ctx, "বিক্রি সেভ হয়েছে ✓", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun KeypadTile(onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(C.amberSoft).border(1.5.dp, C.amber, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp).height(92.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("🔢", fontSize = 28.sp)
        Text("দাম লিখুন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E), textAlign = TextAlign.Center)
    }
}

@Composable
private fun SellTile(p: Product, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)
            .then(if (p.low) Modifier.border(1.5.dp, C.red, RoundedCornerShape(16.dp)) else Modifier)
            .clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 4.dp).height(96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Thumb(p.photo, p.name, 46.dp, 12.dp)
        Gap(h = 4.dp)
        Text(p.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = C.text)
        Text(if (p.isKg) "${tk(p.sell)}/কেজি" else tk(p.sell), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = C.green, maxLines = 1)
    }
}

@Composable
private fun CartPanel(onCheckout: () -> Unit) {
    if (Cart.lines.isEmpty()) return
    Surface(color = Color.White, shadowElevation = 14.dp, shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("কার্ট (${bn(Cart.lines.size.toString())})", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text("সব মুছুন", color = C.red, fontSize = 13.sp, modifier = Modifier.clickable { Cart.lines.clear() }.padding(6.dp))
            }
            LazyColumn(Modifier.heightIn(max = 200.dp)) {
                itemsIndexed(Cart.lines, key = { _, l -> l.key }) { i, l -> CartRow(i, l) }
            }
            Gap(h = 8.dp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("মোট", color = C.sub, fontSize = 13.sp)
                    Text(tk(Cart.total), color = C.green, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onCheckout, shape = RoundedCornerShape(16.dp), modifier = Modifier.height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.brand)
                ) { Text("✓ বিক্রি সম্পন্ন", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CartRow(i: Int, l: CartLine) {
    val p = Store.products.value.firstOrNull { it.id == l.productId }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Thumb(p?.photo ?: "", l.name, 38.dp, 10.dp)
        Gap(w = 8.dp)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(l.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                if (p?.hasPack == true) {
                    Gap(w = 4.dp)
                    Box(Modifier.clickable { Cart.switchMode(i) }) {
                        Pill(if (l.mode == "pack") "প্যাকেট ⇄" else "পিস ⇄", C.amberSoft, Color(0xFF92400E))
                    }
                }
            }
            Text("${tk(l.price)} × ${qtyText(l.mode, l.qty)}", color = C.sub, fontSize = 12.sp)
        }
        if (l.mode != "kg") {
            QtyBtn("−") { Cart.setQty(i, l.qty - 1) }
            Text(num(l.qty), Modifier.width(30.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            QtyBtn("+") { Cart.setQty(i, l.qty + 1) }
        } else QtyBtn("✕") { Cart.setQty(i, 0.0) }
        Text(tk(l.total), Modifier.width(70.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun QtyBtn(t: String, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(C.line).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(t, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

/** Loose goods: type the weight, or the money the customer wants to spend. */
@Composable
private fun WeightDialog(p: Product, onDismiss: () -> Unit, onAdd: (Double) -> Unit) {
    var gram by remember { mutableStateOf("") }
    var taka by remember { mutableStateOf("") }
    val kg = parseNum(gram)?.div(1000.0) ?: parseNum(taka)?.let { if (p.sell > 0) it / p.sell else null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${p.name} — ${tk(p.sell)}/কেজি") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(250, 500, 1000, 2000).forEach { g ->
                        Text(
                            if (g < 1000) bn("$g") + " গ্রাম" else bn("${g / 1000}") + " কেজি",
                            fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                                .clickable { gram = g.toString(); taka = "" }.padding(horizontal = 9.dp, vertical = 7.dp)
                        )
                    }
                }
                Gap(h = 10.dp)
                OutlinedTextField(gram, { gram = it; taka = "" }, label = { Text("ওজন (গ্রাম)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("অথবা", color = C.sub, modifier = Modifier.padding(vertical = 4.dp))
                OutlinedTextField(taka, { taka = it; gram = "" }, label = { Text("কত টাকার দেবেন") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (kg != null && kg > 0) {
                    Gap(h = 10.dp)
                    Text("${qtyText("kg", kg)} = ${tk(kg * p.sell)}", fontWeight = FontWeight.Bold, color = C.green, fontSize = 17.sp)
                }
            }
        },
        confirmButton = { Button({ kg?.let { if (it > 0) onAdd(it) } }, enabled = kg != null && kg > 0) { Text("যোগ করুন") } },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    )
}

/** Sell something by typing the price (it does not have to be in the product list). */
@Composable
private fun KeypadDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var save by remember { mutableStateOf(false) }
    val pr = parseNum(price)
    val q = parseNum(qty) ?: 1.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("দাম লিখে যোগ করুন") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("পণ্যের নাম (না দিলেও চলবে)") }, singleLine = true)
                Gap(h = 6.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(price, { price = it }, label = { Text("দাম ৳") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(qty, { qty = it }, label = { Text("কয়টা") }, singleLine = true, modifier = Modifier.weight(0.7f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                if (pr != null) Text("${tk(pr)} × ${num(q)} = ${tk(pr * q)}", fontWeight = FontWeight.Bold, color = C.green, modifier = Modifier.padding(top = 8.dp))
                if (Access.isOwner) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { save = !save }) {
                    Checkbox(save, { save = it })
                    Text("পণ্যের তালিকায় সেভ করুন", fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Button({
                if (pr != null && pr > 0) {
                    Cart.addCustom(name.trim(), pr, q)
                    if (save && name.isNotBlank()) Store.saveProduct(Product(name = name.trim(), sell = pr))
                    onDismiss()
                }
            }, enabled = pr != null && pr > 0) { Text("যোগ করুন") }
        },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    )
}

/** Payment: change to give back, or put the rest on a customer's baki. */
@Composable
private fun CheckoutDialog(onDismiss: () -> Unit, onDone: () -> Unit) {
    val total = Cart.total
    var given by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf<Customer?>(null) }
    var newName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val customers by Store.customers
    val g = parseNum(given)
    val paid = (g ?: total).coerceIn(0.0, total)
    val due = total - paid
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("মোট ${tk(total)}", fontWeight = FontWeight.Bold, color = C.green) },
        text = {
            Column {
                OutlinedTextField(given, { given = it }, label = { Text("কাস্টমার কত দিল? (খালি = পুরো টাকা)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("পুরোটা বাকি", fontSize = 13.sp, color = C.red, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.redSoft)
                        .clickable { given = "0" }.padding(horizontal = 10.dp, vertical = 6.dp))
                    Text("পুরো টাকা পেয়েছি", fontSize = 13.sp, color = C.green, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                        .clickable { given = "" }.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                if (g != null && g > total) {
                    Gap(h = 10.dp)
                    Text("ফেরত দিন: ${tk(g - total)}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = C.brandDark)
                }
                if (due > 0.001) {
                    Gap(h = 10.dp)
                    Text("বাকি ${tk(due)} — কার নামে?", fontWeight = FontWeight.Bold, color = C.red)
                    val c = customer
                    if (c != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                            Text("👤 ${c.name}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton({ customer = null }) { Text("বদলান") }
                        }
                    } else {
                        OutlinedTextField(newName, { newName = it }, label = { Text("কাস্টমারের নাম খুঁজুন / লিখুন") }, singleLine = true,
                            modifier = Modifier.padding(top = 6.dp))
                        val q = newName.trim()
                        val found = customers.filter { q.isEmpty() || it.name.contains(q, true) || it.phone.contains(q) }.take(4)
                        found.forEach { cu ->
                            Text("👤 ${cu.name}" + if (cu.due > 0) "  (বাকি ${tk(cu.due)})" else "",
                                modifier = Modifier.fillMaxWidth().clickable { customer = cu }.padding(vertical = 8.dp))
                        }
                        if (q.isNotEmpty() && customers.none { it.name.equals(q, true) }) {
                            Text("＋ নতুন কাস্টমার: $q", color = C.brand, fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val id = Store.addCustomer(q, "")
                                    customer = Customer(id, q, "", 0.0)
                                }.padding(vertical = 8.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button({
                busy = true
                Store.checkout(Cart.lines.toList(), paid, if (due > 0.001) customer else null) { ok ->
                    busy = false
                    if (ok) { Cart.lines.clear(); onDone() }
                }
            }, enabled = !busy && (due <= 0.001 || customer != null)) { Text(if (busy) "সেভ হচ্ছে…" else "বিক্রি সেভ করুন") }
        },
        dismissButton = { TextButton({ if (!busy) onDismiss() }) { Text("বাতিল") } }
    )
}
