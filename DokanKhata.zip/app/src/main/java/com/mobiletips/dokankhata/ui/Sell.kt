package com.mobiletips.dokankhata.ui

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mobiletips.dokankhata.data.Access
import com.mobiletips.dokankhata.data.CartLine
import com.mobiletips.dokankhata.data.Customer
import com.mobiletips.dokankhata.data.Product
import com.mobiletips.dokankhata.data.Recognizer
import com.mobiletips.dokankhata.data.Store
import kotlinx.coroutines.delay

/** The cart (and the chosen customer) stay while you move between tabs. */
object Cart {
    val lines = mutableStateListOf<CartLine>()
    val customer = mutableStateOf<Customer?>(null)
    val total get() = lines.sumOf { it.total }

    private fun lineFor(p: Product, mode: String, qty: Double, key: String) = when (mode) {
        "pack" -> CartLine(key, p.id, p.name, "pack", qty, p.packSell, p.packBuy, p.packSize.toDouble())
        "kg" -> CartLine(key, p.id, p.name, "kg", qty, p.sell, p.buy, 1.0)
        else -> CartLine(key, p.id, p.name, "pc", qty, p.sell, p.buy, 1.0)
    }

    fun add(p: Product, mode: String, qty: Double = 1.0) {
        if (mode == "kg") { lines.add(lineFor(p, mode, qty, "${p.id}:kg:${System.nanoTime()}")); return }
        val key = "${p.id}:$mode"
        val i = lines.indexOfFirst { it.key == key }
        if (i >= 0) lines[i] = lines[i].copy(qty = lines[i].qty + qty) else lines.add(lineFor(p, mode, qty, key))
    }

    fun addCustom(name: String, price: Double, qty: Double) {
        lines.add(CartLine("c${System.nanoTime()}", "", name.ifBlank { L("অন্যান্য", "Other") }, "custom", qty, price, 0.0, 0.0))
    }

    fun setQty(i: Int, q: Double) {
        if (i !in lines.indices) return
        if (q <= 0.0001) lines.removeAt(i) else lines[i] = lines[i].copy(qty = q)
    }

    fun switchMode(i: Int) {
        val l = lines.getOrNull(i) ?: return
        val p = Store.products.value.firstOrNull { it.id == l.productId } ?: return
        if (!p.hasPack) return
        val to = if (l.mode == "pack") "pc" else "pack"
        lines.removeAt(i)
        add(p, to, l.qty)
    }

    fun clear() { lines.clear(); customer.value = null }
}

@Composable
fun SellScreen() {
    val ctx = LocalContext.current
    val products by Store.products
    val canScan = Access.can("scan")
    val canPhoto = Access.can("photo") && Recognizer.available.value
    var camOn by remember { mutableStateOf(canScan || canPhoto) }
    var query by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var weighFor by remember { mutableStateOf<Product?>(null) }
    var unknownCode by remember { mutableStateOf<String?>(null) }
    var keypad by remember { mutableStateOf(false) }
    var checkout by remember { mutableStateOf(false) }
    var pickCustomer by remember { mutableStateOf(false) }
    val guesses = remember { mutableStateListOf<Pair<Product, Float>>() }
    val main = remember { Handler(Looper.getMainLooper()) }
    val tone = remember { try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (e: Exception) { null } }
    DisposableEffect(Unit) { onDispose { tone?.release() } }
    LaunchedEffect(msg) { if (msg != null) { delay(2500); msg = null } }

    fun added(p: Product, mode: String) {
        val price = if (mode == "pack") p.packSell else p.sell
        msg = "${p.name} — ${tk(price)}"
        Voice.say("${p.name}, ${sayNum(price)} টাকা", "${p.name}, ${sayNum(price)} taka")
    }

    fun addProduct(p: Product, fromCode: String? = null) {
        when {
            p.isKg -> weighFor = p
            p.hasPack && fromCode != null && p.barcode == fromCode -> { Cart.add(p, "pack"); added(p, "pack") }
            else -> { Cart.add(p, "pc"); added(p, "pc") }
        }
    }

    fun onScan(code: String) {
        val p = Store.productByCode(code)
        if (p == null) {
            tone?.startTone(ToneGenerator.TONE_PROP_NACK, 150)
            if (unknownCode == null) unknownCode = code
            return
        }
        tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
        addProduct(p, code)
    }

    val frameCb: ((android.graphics.Bitmap) -> Unit)? = if (canPhoto) fun(bm: android.graphics.Bitmap) {
        val v = Recognizer.embed(bm)
        val found = if (v != null) Recognizer.match(v, Store.products.value) else emptyList()
        main.post { guesses.clear(); guesses.addAll(found) }
    } else null

    Column(Modifier.fillMaxSize()) {
        Header(L("নতুন বিক্রি", "New sale"), when {
            !camOn -> L("পণ্যে চাপ দিন বা নাম লিখুন", "Tap a product or type its name")
            canScan && canPhoto -> L("বারকোড/QR বা পণ্যের সামনে ক্যামেরা ধরুন", "Point at a barcode/QR or the product")
            canPhoto -> L("পণ্যের সামনে ক্যামেরা ধরুন", "Point the camera at the product")
            else -> L("বারকোড / QR এর সামনে ধরুন", "Point at a barcode / QR")
        }) {
            if (canScan || canPhoto) Text(
                if (camOn) L("✕ ক্যামেরা বন্ধ", "✕ Camera off") else L("📷 ক্যামেরা", "📷 Camera"),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.22f))
                    .clickable { camOn = !camOn; guesses.clear() }.padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
        if (camOn && (canScan || canPhoto)) {
            Box(Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp)) {
                CameraScanner(
                    Modifier.fillMaxWidth().height(170.dp),
                    barcode = canScan,
                    onFrame = frameCb,
                    onCode = { onScan(it) }
                )
                msg?.let { t ->
                    Text(
                        "✓ $t", color = C.green, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp).fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp)).background(Color(0xFFECFDF5)).padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
            if (guesses.isNotEmpty()) GuessRow(guesses.toList()) { p -> addProduct(p); guesses.clear() }
        }
        CustomerBar { pickCustomer = true }
        OutlinedTextField(
            query, { query = it },
            placeholder = { Text(L("পণ্যের নাম লিখুন…", "Type a product name…")) },
            leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) },
            trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, L("মুছুন", "Clear")) } },
            singleLine = true, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
        )
        val shown = remember(products, query) {
            val q = query.trim()
            if (q.isEmpty()) products else products.filter { it.name.contains(q, true) || it.cat.contains(q, true) || it.barcode == q }
        }
        LazyVerticalGrid(
            GridCells.Fixed(4), Modifier.weight(1f).padding(horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { KeypadTile { keypad = true } }
            items(shown, key = { it.id }) { p -> SellTile(p) { addProduct(p) } }
            if (products.isEmpty()) item {
                Text(L("এখনো কোনো পণ্য নেই। 'পণ্য' ট্যাবে গিয়ে যোগ করুন।", "No products yet. Add them in the 'Products' tab."), color = C.sub, fontSize = 13.sp)
            }
        }
        CartPanel { checkout = true }
    }

    weighFor?.let { p ->
        WeightDialog(p, { weighFor = null }) { kg ->
            Cart.add(p, "kg", kg)
            msg = "${p.name} — ${qtyText("kg", kg)}"
            Voice.say("${p.name}, ${sayNum(kg * p.sell)} টাকা", "${p.name}, ${sayNum(kg * p.sell)} taka")
            weighFor = null
        }
    }
    unknownCode?.let { code ->
        val owner = Access.can("products")
        AlertDialog(
            onDismissRequest = { unknownCode = null },
            title = { Text(L("নতুন পণ্য?", "New product?")) },
            text = { Text(L("এই কোডের কোনো পণ্য তালিকায় নেই:", "No product has this code:") + "\n${bn(code.take(40))}\n\n" +
                if (owner) L("নতুন পণ্য হিসেবে যোগ করবেন?", "Add it as a new product?") else L("দোকানের মালিককে পণ্যটি যোগ করতে বলুন।", "Ask the shop owner to add it.")) },
            confirmButton = {
                if (owner) Button({ unknownCode = null; Nav.open(Page.EditProduct(null, code)) }) { Text(L("যোগ করুন", "Add")) }
                else Button({ unknownCode = null }) { Text(L("ঠিক আছে", "OK")) }
            },
            dismissButton = { TextButton({ unknownCode = null }) { Text(L("না", "No")) } }
        )
    }
    if (keypad) KeypadDialog { keypad = false }
    if (pickCustomer) CustomerPicker({ pickCustomer = false }) { Cart.customer.value = it; pickCustomer = false }
    if (checkout) CheckoutDialog({ checkout = false }) {
        checkout = false
        Toast.makeText(ctx, L("বিক্রি সেভ হয়েছে ✓", "Sale saved ✓"), Toast.LENGTH_SHORT).show()
    }
}

/** Photo-recognition suggestions under the camera: tap the right one. */
@Composable
private fun GuessRow(list: List<Pair<Product, Float>>, onPick: (Product) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(L("এটা কি?", "Is it?"), color = C.sub, fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterVertically))
        list.forEach { (p, s) ->
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White).border(1.5.dp, C.brand, RoundedCornerShape(14.dp))
                    .clickable { onPick(p) }.padding(6.dp)
                    .semantics(mergeDescendants = true) { contentDescription = L("${p.name}, যোগ করুন", "Add ${p.name}") },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Thumb(p.photo, p.name, 34.dp, 9.dp)
                Gap(w = 6.dp)
                Column {
                    Text(p.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(bn("${(s * 100).toInt()}%") + " · " + tk(p.sell), fontSize = 11.sp, color = C.sub)
                }
            }
        }
    }
}

/** Shows who the sale is for (baki goes to this customer). */
@Composable
private fun CustomerBar(onPick: () -> Unit) {
    if (!Access.can("baki")) return
    val c by Cart.customer
    Row(
        Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (c != null) C.brandSoft else Color.White).clickable(onClick = onPick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cc = c
        if (cc != null) {
            Thumb(cc.photo, cc.name, 30.dp, 15.dp)
            Gap(w = 8.dp)
            Column(Modifier.weight(1f)) {
                Text(cc.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(L("আগের বাকি ", "Earlier baki ") + tk(cc.due), color = C.sub, fontSize = 12.sp)
            }
            Text(L("✕ সরান", "✕ Remove"), color = C.red, fontSize = 13.sp, modifier = Modifier.clickable { Cart.customer.value = null }.padding(4.dp))
        } else {
            Text("👤", fontSize = 18.sp)
            Gap(w = 8.dp)
            Text(L("কাস্টমার বাছুন (বাকির জন্য)", "Choose customer (for baki)"), color = C.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("›", fontSize = 20.sp, color = C.sub)
        }
    }
}

/** Search customers by name or phone, or add a new one right here. */
@Composable
fun CustomerPicker(onDismiss: () -> Unit, onPick: (Customer) -> Unit) {
    val customers by Store.customers
    var q by remember { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("কাস্টমার বাছুন", "Choose customer")) },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, label = { Text(L("নাম বা মোবাইল লিখুন", "Name or mobile")) }, singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Search, L("খুঁজুন", "Search")) })
                val list = customers.filter { q.isBlank() || it.name.contains(q.trim(), true) || it.phone.contains(q.trim()) }.take(6)
                list.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(c) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Thumb(c.photo, c.name, 36.dp, 18.dp)
                        Gap(w = 10.dp)
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            if (c.phone.isNotBlank()) Text(bn(c.phone), color = C.sub, fontSize = 12.sp)
                        }
                        if (c.due > 0.001) Text(tk(c.due), color = C.red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                Text(
                    L("＋ নতুন কাস্টমার", "＋ New customer") + if (q.isNotBlank()) ": ${q.trim()}" else "",
                    color = C.brand, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clickable { adding = true }.padding(vertical = 10.dp)
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text(L("বন্ধ", "Close")) } }
    )
    if (adding) CustomerDialog(null, q.trim(), { adding = false }) { n, ph, photo ->
        val id = Store.addCustomer(n, ph, photo)
        adding = false
        onPick(Customer(id, n, ph, 0.0, photo))
    }
}

@Composable
private fun KeypadTile(onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(C.amberSoft).border(1.5.dp, C.amber, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp).height(92.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("🔢", fontSize = 28.sp)
        Text(L("দাম লিখুন", "Type price"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E), textAlign = TextAlign.Center)
    }
}

@Composable
private fun SellTile(p: Product, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)
            .then(if (p.low) Modifier.border(1.5.dp, C.red, RoundedCornerShape(16.dp)) else Modifier)
            .clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 4.dp).height(96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Thumb(p.photo, p.name, 46.dp, 12.dp)
        Gap(h = 4.dp)
        Text(p.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = C.text)
        Text(if (p.isKg) "${tk(p.sell)}/" + L("কেজি", "kg") else tk(p.sell), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = C.green, maxLines = 1)
    }
}

@Composable
private fun CartPanel(onCheckout: () -> Unit) {
    if (Cart.lines.isEmpty()) return
    Surface(color = Color.White, shadowElevation = 14.dp, shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(L("কার্ট", "Cart") + " (${bn(Cart.lines.size.toString())})", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text(L("সব মুছুন", "Clear all"), color = C.red, fontSize = 13.sp, modifier = Modifier.clickable { Cart.lines.clear() }.padding(6.dp))
            }
            LazyColumn(Modifier.heightIn(max = 190.dp)) {
                itemsIndexed(Cart.lines, key = { _, l -> l.key }) { i, l -> CartRow(i, l) }
            }
            Gap(h = 8.dp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(L("মোট", "Total"), color = C.sub, fontSize = 13.sp)
                    Text(tk(Cart.total), color = C.green, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onCheckout, shape = RoundedCornerShape(16.dp), modifier = Modifier.height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.brand)
                ) { Text(L("✓ বিক্রি সম্পন্ন", "✓ Finish sale"), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CartRow(i: Int, l: CartLine) {
    val p = Store.products.value.firstOrNull { it.id == l.productId }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Thumb(p?.photo ?: "", l.name, 38.dp, 10.dp)
        Gap(w = 8.dp)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(l.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                if (p?.hasPack == true) {
                    Gap(w = 4.dp)
                    Box(Modifier.clickable { Cart.switchMode(i) }) {
                        Pill(if (l.mode == "pack") L("প্যাকেট ⇄", "Pack ⇄") else L("পিস ⇄", "Piece ⇄"), C.amberSoft, Color(0xFF92400E))
                    }
                }
            }
            Text("${tk(l.price)} × ${qtyText(l.mode, l.qty)}", color = C.sub, fontSize = 12.sp)
        }
        if (l.mode != "kg") {
            QtyBtn("−", L("একটা কমান", "One less")) { Cart.setQty(i, l.qty - 1) }
            Text(num(l.qty), Modifier.width(30.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            QtyBtn("+", L("একটা বাড়ান", "One more")) { Cart.setQty(i, l.qty + 1) }
        } else QtyBtn("✕", L("সরান", "Remove")) { Cart.setQty(i, 0.0) }
        Text(tk(l.total), Modifier.width(70.dp), textAlign = TextAlign.End, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun QtyBtn(t: String, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(C.line).clickable(onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) { Text(t, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

/** Loose goods: type the weight, or the money the customer wants to spend. */
@Composable
private fun WeightDialog(p: Product, onDismiss: () -> Unit, onAdd: (Double) -> Unit) {
    var gram by remember { mutableStateOf("") }
    var taka by remember { mutableStateOf("") }
    val kg = parseNum(gram)?.div(1000.0) ?: parseNum(taka)?.let { if (p.sell > 0) it / p.sell else null }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${p.name} — ${tk(p.sell)}/" + L("কেজি", "kg")) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(250, 500, 1000, 2000).forEach { g ->
                        Text(
                            if (g < 1000) bn("$g") + L(" গ্রাম", " g") else bn("${g / 1000}") + L(" কেজি", " kg"),
                            fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                                .clickable { gram = g.toString(); taka = "" }.padding(horizontal = 9.dp, vertical = 7.dp)
                        )
                    }
                }
                Gap(h = 10.dp)
                OutlinedTextField(gram, { gram = it; taka = "" }, label = { Text(L("ওজন (গ্রাম)", "Weight (grams)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text(L("অথবা", "or"), color = C.sub, modifier = Modifier.padding(vertical = 4.dp))
                OutlinedTextField(taka, { taka = it; gram = "" }, label = { Text(L("কত টাকার দেবেন", "For how much money")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (kg != null && kg > 0) {
                    Gap(h = 10.dp)
                    Text("${qtyText("kg", kg)} = ${tk(kg * p.sell)}", fontWeight = FontWeight.Bold, color = C.green, fontSize = 17.sp)
                }
            }
        },
        confirmButton = { Button({ kg?.let { if (it > 0) onAdd(it) } }, enabled = kg != null && kg > 0) { Text(L("যোগ করুন", "Add")) } },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** Sell something by typing the price (it does not have to be in the product list). */
@Composable
private fun KeypadDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var save by remember { mutableStateOf(false) }
    val pr = parseNum(price)
    val q = parseNum(qty) ?: 1.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("দাম লিখে যোগ করুন", "Add by price")) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text(L("পণ্যের নাম (না দিলেও চলবে)", "Product name (optional)")) }, singleLine = true)
                Gap(h = 6.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(price, { price = it }, label = { Text(L("দাম ৳", "Price ৳")) }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(qty, { qty = it }, label = { Text(L("কয়টা", "Qty")) }, singleLine = true, modifier = Modifier.weight(0.7f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                if (pr != null) Text("${tk(pr)} × ${num(q)} = ${tk(pr * q)}", fontWeight = FontWeight.Bold, color = C.green, modifier = Modifier.padding(top = 8.dp))
                if (Access.can("products")) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { save = !save }) {
                    Checkbox(save, { save = it })
                    Text(L("পণ্যের তালিকায় সেভ করুন", "Save to product list"), fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Button({
                if (pr != null && pr > 0) {
                    Cart.addCustom(name.trim(), pr, q)
                    if (save && name.isNotBlank()) Store.saveProduct(Product(name = name.trim(), sell = pr))
                    Voice.say("${sayNum(pr * q)} টাকা যোগ হলো", "${sayNum(pr * q)} taka added")
                    onDismiss()
                }
            }, enabled = pr != null && pr > 0) { Text(L("যোগ করুন", "Add")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(L("বাতিল", "Cancel")) } }
    )
}

/** Payment: change to give back, or put the rest on the customer's baki. */
@Composable
private fun CheckoutDialog(onDismiss: () -> Unit, onDone: () -> Unit) {
    val total = Cart.total
    val canBaki = Access.can("baki")
    var customer by remember { mutableStateOf(Cart.customer.value) }
    var given by remember { mutableStateOf(if (Cart.customer.value != null) "0" else "") }
    var picking by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val g = parseNum(given)
    val paid = (g ?: total).coerceIn(0.0, total)
    val due = total - paid
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(L("মোট ", "Total ") + tk(total), fontWeight = FontWeight.Bold, color = C.green) },
        text = {
            Column {
                OutlinedTextField(given, { given = it }, label = { Text(L("কাস্টমার কত দিল? (খালি = পুরো টাকা)", "Money received (empty = full)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (canBaki) Text(L("পুরোটা বাকি", "All on baki"), fontSize = 13.sp, color = C.red, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.redSoft)
                        .clickable { given = "0" }.padding(horizontal = 10.dp, vertical = 6.dp))
                    Text(L("পুরো টাকা পেয়েছি", "Paid in full"), fontSize = 13.sp, color = C.green, modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(C.brandSoft)
                        .clickable { given = "" }.padding(horizontal = 10.dp, vertical = 6.dp))
                }
                if (g != null && g > total) {
                    Gap(h = 10.dp)
                    Text(L("ফেরত দিন: ", "Give back: ") + tk(g - total), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = C.brandDark)
                }
                if (due > 0.001) {
                    Gap(h = 10.dp)
                    if (!canBaki) Text(L("বাকি দেওয়ার অনুমতি নেই — পুরো টাকা নিন।", "You may not give baki — take the full amount."), color = C.red)
                    else {
                        Text(L("বাকি ", "Baki ") + tk(due) + L(" — কার নামে?", " — for whom?"), fontWeight = FontWeight.Bold, color = C.red)
                        val c = customer
                        Row(
                            Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.bg)
                                .clickable { picking = true }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (c != null) {
                                Thumb(c.photo, c.name, 32.dp, 16.dp)
                                Gap(w = 8.dp)
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, fontWeight = FontWeight.Bold)
                                    Text(L("নতুন মোট বাকি ", "New total baki ") + tk(c.due + due), color = C.red, fontSize = 12.sp)
                                }
                                Text(L("বদলান", "Change"), color = C.brand)
                            } else Text(L("👤 কাস্টমার বাছুন…", "👤 Choose customer…"), color = C.brand, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button({
                busy = true
                val c = if (due > 0.001) customer else null
                Store.checkout(Cart.lines.toList(), paid, c) { ok ->
                    busy = false
                    if (ok) {
                        if (c != null) Voice.say(
                            "${c.name}-এর নামে ${sayNum(due)} টাকা বাকি যোগ হলো, মোট বাকি ${sayNum(c.due + due)} টাকা",
                            "${sayNum(due)} taka added to ${c.name}'s baki. Total baki ${sayNum(c.due + due)} taka"
                        ) else Voice.say("মোট ${sayNum(total)} টাকা, বিক্রি সেভ হয়েছে", "Total ${sayNum(total)} taka. Sale saved")
                        Cart.clear(); onDone()
                    }
                }
            }, enabled = !busy && (due <= 0.001 || (canBaki && customer != null))) { Text(if (busy) L("সেভ হচ্ছে…", "Saving…") else L("বিক্রি সেভ করুন", "Save sale")) }
        },
        dismissButton = { TextButton({ if (!busy) onDismiss() }) { Text(L("বাতিল", "Cancel")) } }
    )
    if (picking) CustomerPicker({ picking = false }) { customer = it; Cart.customer.value = it; picking = false }
}
