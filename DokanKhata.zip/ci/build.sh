#!/usr/bin/env bash
# Build steps live here (inside the zip), so build.yml never needs editing again.
set -e
set +e
gradle assembleDebug --no-daemon --stacktrace > debug.log 2>&1
dcode=$?
set -e
cat debug.log
if [ $dcode -ne 0 ]; then
  reason=$(grep -E "^e: |What went wrong" -A3 debug.log | head -20 | tr '\n' ' ' | cut -c1-900)
  echo "::error::APK build failed: ${reason:-see the Build step log}"
  exit 1
fi
cp app/build/outputs/apk/debug/app-debug.apk DokanKhata.apk

# Password for the Play Store key: the secret (spaces / new lines removed), else the backup in ci/upload.pw.
opens() { keytool -list -keystore app/upload.jks -storepass "$1" >/dev/null 2>&1; }
PW=$(printf '%s' "$UPLOAD_PASSWORD" | tr -d '[:space:]')
if [ -z "$PW" ] || ! opens "$PW"; then
  if [ -n "$PW" ]; then echo "::warning::UPLOAD_PASSWORD secret does not open app/upload.jks - using ci/upload.pw instead."; fi
  PW=$(tr -d '[:space:]' < ci/upload.pw 2>/dev/null)
fi
if [ -z "$PW" ] || ! opens "$PW"; then
  echo "::error::No working password for app/upload.jks - Play Store bundle (.aab) skipped."
  exit 0
fi
export UPLOAD_PASSWORD="$PW"

# 2) Build the Play Store bundle. If it fails, show the reason but still publish the APK.
set +e
gradle bundleRelease --no-daemon --stacktrace > bundle.log 2>&1
code=$?
set -e
cat bundle.log
if [ $code -ne 0 ]; then
  reason=$(grep -A6 "What went wrong" bundle.log | tr '\n' ' ' | cut -c1-600)
  echo "::error::AAB build failed: ${reason:-see the Build step log}"
  exit 0
fi
cp app/build/outputs/bundle/release/app-release.aab DokanKhata.aab
echo "Play Store bundle ready: DokanKhata.aab"
